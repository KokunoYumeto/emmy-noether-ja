# CJK Noether shared PDF-extraction return — 2026-08-08

`CJK-NOETH-EXT-SYS-001` is one cross-lane build/extraction finding. It is not a Chinese, Japanese, or Korean translation defect and does not call for any target-text change.

The exact frozen PDFs independently examined were Chinese r7 `CCA7A94C795027378FB370D7E78977DEFA252CFA5115AD915B164013055369D4` (424 pages), Japanese r06 `1985EBEAE818D6DE2C20069B03BC0FD5272A2C263D901BF9B15A41C4D304F08F` (419 pages), and corrected Korean check11 `F00E73D2766A2817088338C453C61D9A09CF93FF1160FAD1DDF668D5EC72BF74` (517 pages). Their visual mathematics is intact, and all fonts are embedded and subset. The defect is machine-readable extraction: conventional embedded Type 1 math subsets lack `/ToUnicode`, so mathematical glyph positions become C0 control characters.

With Poppler 24.04 `pdftotext -layout -enc UTF-8`, excluding TAB/LF/CR and the deliberate inter-page form feeds, the exact totals are:

- Chinese: 559 controls on 100 pages; extraction 1,882,512 bytes / `DF323E480B8C721872FFD9227757B61D3998A410AAC0A5FC5BF6820703F1A11B`.
- Japanese: 591 controls on 104 pages; extraction 2,199,391 bytes / `D6B6E1FDE72285020B84098D1125F482584E82F24F1CC0EFE360C5C8839ECBF6`.
- Korean: 600 controls on 118 pages; extraction 2,121,686 bytes / `33393CB449DCC7EA731F37FCD98D7ACBA4A2BF298092577B101FAE9B4D6E967D`.

With Python 3.13.9 / pypdf 6.12.2 `page.extract_text()`, using deterministic form-feed joins and excluding only the join separators, the exact totals are:

- Chinese: 11,488 controls on 388 pages; 1,400,118 bytes / `4AACD912DC9541FD6E466E061E6C5115409C4DCADEA5C62EAFAC7BD948931E36`.
- Japanese: 8,690 controls on 378 pages; 1,734,864 bytes / `A8F8EA5254BA70F60649369021CF7F9D114C66E0927733A1A93BD7AE070B3722`.
- Korean: 9,670 controls on 452 pages; 1,677,895 bytes / `20DF97B6F8EFDB5AE914906185B97B0FD44195831F9F19D11936C0EDEB72F6D8`.

There is no U+FFFD in any extraction and no Poppler NUL. Japanese visitor tracing attributes every control to its six non-ToUnicode math subsets; Chinese and Korean use the analogous classic-math subsets. Representative pages were reopened at original detail: the affected glyphs render correctly, confirming that this is an extraction/accessibility defect rather than a visual one.

Exact scratch receipts are `control-scan-zh-ja.json`, 136,359 bytes / `507318CB9843016F3CCF9B952C9F0CE319B433DECB4FD9941B5909FFBAE32419`; `control-scan-ko.json`, 74,408 bytes / `97A05A3A4C8C1F055DAA911285294C0E36EEDEF6418A50F2078B3BA944B63B3C`; and `ja-font-controls.json`, 30,988 bytes / `9335F8FE3DF307DF0EA619A4D0D249F24A0B6BEE076F1DC6544A19BF820DB5F9`.

Disposition: `RETURN_REQUIRED_BUILD`. Supply ToUnicode-enabled math fonts/CMaps and rebuild, then require zero internal disallowed C0 controls in both extractors with no visual regression. Alternatively, governance may explicitly accept this conventional TeX limitation once as a cross-lane exception; absent such an exception, none of the three extractions is an unconditional clean pass. SGA remains held and nothing is publishable.
