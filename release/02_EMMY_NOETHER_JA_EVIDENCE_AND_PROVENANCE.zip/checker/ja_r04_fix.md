# Japanese r04 checker-ledger integrity correction — 2026-08-07

Preserve `ja_r04.csv`, 5,677 bytes, SHA-256 `98A7BF0CD9DA2E8AD9F30BD25B7AA2489AAABBA888900D969D40AC39EEF28EEF`, as the exact routed/frozen historical return consumed by the r05 producer.

One non-scope prose count in `JA-R04-FORM-001` is wrong: `reader.tex` lines 14121, 14123, 14125, and 14127 contain exactly four `\mo n` occurrences, not five. This was personally reproduced from frozen r04. The exact target loci, source loci, required `n` to `eta` delta, severity, and all other findings are unchanged. The r05 producer independently observed and changed exactly those four occurrences, so no successor target correction is required.

This separate note corrects the checker record without mutating the hash-pinned historical evidence referenced by r05 `freeze.csv`.
