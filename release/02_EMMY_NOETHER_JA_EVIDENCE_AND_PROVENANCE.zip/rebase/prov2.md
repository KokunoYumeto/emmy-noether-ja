# Japanese Noether rebase provenance — successor freeze

This supersedes the 2026-08-04 initial freeze for editable-target identity only. The German authority is unchanged: `NOETH-DE-AUTH-v019-20260804`, pointer SHA-256 `FDBE531AA5F2175AD23363FB4F05B357A5ECD8A72B022D7ED644E39DF0B3CA79`, resolving to exact ED0004 SHA-256 `0CB422ECD397DD392A8625297A508DAEE3A5A934EA19EEEF49B47B319EA4F2BB`.

The inherited Paper 31 unit contained a literal form-feed byte (`0x0C`) followed by `ootnote` at its line 21. It propagated to the candidate and the first rebase freeze at `reader.tex` line 14972. ED0004 line 16017 carries the corresponding note as `\srcfn{1)}`. The successor target changes only that corrupted control sequence to `\footnote`; exact evidence is in `fix.csv` and hunk 3 of `delta.csv`. A raw control-character census over the root and all eight components now finds zero disallowed control bytes.

The intake scripts now count physical LF lines only. Python `splitlines()` had treated the form feed as a synthetic line boundary, shifting Paper 31 and later target cursors by one. Corrected per-paper cursors are in `manifest.csv`; the full semantic boundary map is `cursor2.csv`.

The numbered Paper 43 text ends at ED0004 line 20984. Lines 20985--20987 are blank; lines 20988--21004 are the Deuring TeX wrapper; the Deuring title begins at line 21005. Thus the translated `t0.tex` start at line 20988 is structural coverage, not duplicate Paper 43 text. Deuring runs through 23740, the Kapferer separator/paper and Noether supplement through 23983, bibliography/terminal lists through 24145, and line 24146 closes the document.

Successor editable root: 1,926,162 bytes, SHA-256 `07504D989F691481B61A778D5364CD3705819A79A7B955B76464E5D0B1BE5BF7`. Domain-separated root-plus-components identity: `E7E5835388E220FAC4C40FA2676344AD3660B19F3D13E859264DDB180D6168C6`. Two serial XeLaTeX passes exited zero; mechanical PDF: 2,933,894 bytes, 420 pages, SHA-256 `B433DAF87DE8351153CFE5867D331C49E1122AF1A8650E3D5C331A6A5F9C610E`. No source, Japanese, formula, apparatus, PDF-text, rendered-page, or certification approval is claimed. Clean-day count remains 0/3; SGA remains held.
