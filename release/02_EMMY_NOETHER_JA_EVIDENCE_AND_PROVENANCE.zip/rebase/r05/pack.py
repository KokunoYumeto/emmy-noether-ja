from __future__ import annotations

import csv
import hashlib
import importlib.util
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
REBASE = HERE.parent
R04 = REBASE / "r04"
R03 = REBASE
ROOT = HERE.parents[6]
CANON = ROOT / "03_projects" / "noether" / "07_german_canon_control"
POINTER = CANON / "CURRENT_GERMAN_AUTHORITY_POINTER.json"

EXPECTED_POINTER_ID = "NOETH-DE-AUTH-v044-20260807"
EXPECTED_POINTER_SHA = "FF98F436CF8D38AA1D13CF1D969857CE277D02851CC79EFE521DFE1D0B45B98D"
EXPECTED_AUTHORITY_SHA = "C83A94D25DE8FD27C66E2C6C50BAB04AA875E6C0A6A87BDFCA202E69A8EA660D"
EXPECTED_R03_ROOT = "6D8A36F22F44052C7209DA9414EFFF31C78F7B6E29A11733D403776BBA5D4130"
EXPECTED_R03_SET = "AC0ABE6B7DB5989ED156AA7902096511A350DC0C47ACB4A37B06A225382D9FB7"
EXPECTED_R03_PDF = "19E7C42FF11ECF32B6753812E3F279262A4AACC321BF78B40F6CB92F99861B53"
EXPECTED_R04_FREEZE = "A37E6C40514BA9E30A0D4C375DF00ECB272FF894E88F9CEBE4E3A9562F1F5BBA"
EXPECTED_R04_ROOT = "2E2A927B1B498587A5F380E4307F9CB58BE32285969C0E625015B7528E9A56FE"
EXPECTED_R04_SET = "F144CD3845F9BCEF5527A035B941A71B5EA2417D3F1C1E1EA3601B4CFA8B34AF"
EXPECTED_R04_PDF = "9B19F92C8DE034826FD181826F48AFC53A8094773C35C8BBD9AB0B7E868042E5"
EXPECTED_R04_PACK = "15DBB2D3E9C050F822B5953797EDFCEE9BB55BCD8EA88054CBA730C5C5C98753"
EXPECTED_R05_ROOT = "9B3C37E0C91E7BF924B5F6738BF97CDD4AA62DC806DD5BCE0D8904931E3E6F87"
EXPECTED_R05_SET = "E4BB1BE344A7A6FA2D4515959A01F5D462ACB330E82390B6ABABA57E9B7D51BA"
EXPECTED_R05_PDF = "EAAC3E49289D52A249F6C5BAC3BCEACD0B40701957B5DD605A48D048FFAE7F5A"
EXPECTED_R05_LOG = "FEE675C4C6843C1015655759AAE93843099C89EC506140E2DD00136DF838A8B0"
EXPECTED_CHECK_CSV = "98A7BF0CD9DA2E8AD9F30BD25B7AA2489AAABBA888900D969D40AC39EEF28EEF"
EXPECTED_CHECK_MD = "DAC28ADC1E436690AC6BDB0BC461ED35020B8E47D2C80DF540811D40285255D1"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def assert_hash(path: Path, expected: str) -> None:
    actual = digest(path.read_bytes())
    if actual != expected:
        raise RuntimeError(f"identity changed: {path}: {actual} != {expected}")


def set_identity(directory: Path) -> tuple[int, str]:
    names = ["reader.tex", *(f"t{i}.tex" for i in range(8))]
    payload = "".join(
        f"{name}|{digest((directory / name).read_bytes())}\n" for name in names
    ).encode("utf-8")
    return sum((directory / name).stat().st_size for name in names), digest(payload)


def file_row(role: str, path: Path, shown: str, note: str) -> dict[str, object]:
    data = path.read_bytes()
    return {
        "role": role,
        "path": shown,
        "present": "true",
        "bytes": len(data),
        "sha256": digest(data),
        "note": note,
    }


def identity_row(role: str, path: str, size: int, sha: str, note: str) -> dict[str, object]:
    return {
        "role": role,
        "path": path,
        "present": "false",
        "bytes": size,
        "sha256": sha,
        "note": note,
    }


def set_row(role: str, directory: Path, shown: str, note: str) -> dict[str, object]:
    size, sha = set_identity(directory)
    return {
        "role": role,
        "path": shown,
        "present": "true",
        "bytes": size,
        "sha256": sha,
        "note": note,
    }


def load_r04_pack():
    assert_hash(R04 / "pack.py", EXPECTED_R04_PACK)
    spec = importlib.util.spec_from_file_location("ja_noether_r04_pack", R04 / "pack.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load inherited manifest generator")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.HERE = HERE
    return module


def validate_inputs(pointer: dict[str, object], authority: Path) -> None:
    if ROOT.name != "interlanguage":
        raise RuntimeError(f"unexpected workspace root: {ROOT}")
    assert_hash(POINTER, EXPECTED_POINTER_SHA)
    if pointer["pointer_id"] != EXPECTED_POINTER_ID:
        raise RuntimeError("pointer ID changed")
    authority_record = pointer["default_translation_authority"]
    raw = authority.read_bytes()
    if len(raw) != int(authority_record["raw_bytes"]):
        raise RuntimeError("authority byte count disagrees with pointer")
    if digest(raw) != EXPECTED_AUTHORITY_SHA:
        raise RuntimeError("authority body changed")
    if str(authority_record["raw_sha256"]) != EXPECTED_AUTHORITY_SHA:
        raise RuntimeError("pointer authority hash changed")
    if len(raw.split(b"\n")) - (1 if raw.endswith(b"\n") else 0) != 24146:
        raise RuntimeError("authority physical-line count changed")

    assert_hash(R03 / "reader.tex", EXPECTED_R03_ROOT)
    if set_identity(R03)[1] != EXPECTED_R03_SET:
        raise RuntimeError("r03 editable set changed")
    assert_hash(R03 / "reader.pdf", EXPECTED_R03_PDF)
    assert_hash(R04 / "freeze.csv", EXPECTED_R04_FREEZE)
    assert_hash(R04 / "reader.tex", EXPECTED_R04_ROOT)
    if set_identity(R04)[1] != EXPECTED_R04_SET:
        raise RuntimeError("r04 editable set changed")
    assert_hash(R04 / "reader.pdf", EXPECTED_R04_PDF)
    assert_hash(HERE / "reader.tex", EXPECTED_R05_ROOT)
    if set_identity(HERE)[1] != EXPECTED_R05_SET:
        raise RuntimeError("r05 editable set changed")
    assert_hash(HERE / "reader.pdf", EXPECTED_R05_PDF)
    assert_hash(HERE / "reader.log", EXPECTED_R05_LOG)


def write_freeze(pointer: dict[str, object], authority: Path) -> None:
    cjk = ROOT / "03_projects" / "language_management" / "cjk"
    ja = cjk / "03_working_translations" / "japanese"
    baseline = (
        cjk / "01_recovered_witnesses" / "noether_cjk_chinese_japanese_cumulative_20260702"
        / "translations" / "non_slavic" / "japanese" / "source_fidelity" / "v001"
        / "Noether_Japanese_Cumulative_SourceFidelity_v001.tex"
    )
    candidate = ja / "noether_ja" / "reader.tex"
    replay = REBASE / "replay" / "reader.tex"
    historical_public = ROOT / "03_projects" / "noether" / "08_zenodo" / "r6" / "20-ja.tex"
    checker = cjk / "05_independent_checking" / "cjk_r1"

    if historical_public.exists():
        raise RuntimeError("historical candidate_public_copy unexpectedly reappeared")
    assert_hash(baseline, "4A284DF3FAC4D53D305659B539AF2FEB17902BFB4C254A7DF62A155C6BC23131")
    for witness in (candidate, replay):
        assert_hash(witness, "47F8150D6750A02FF939C0E6CF4F07909858AB6DFEC8E511B047D4640BCFB235")
    assert_hash(checker / "ja_r04.csv", EXPECTED_CHECK_CSV)
    assert_hash(checker / "ja_r04.md", EXPECTED_CHECK_MD)

    rows: list[dict[str, object]] = [
        file_row("authority_pointer_current", POINTER, str(POINTER), EXPECTED_POINTER_ID),
        file_row("authority_pointer_versioned", CANON / "pointers" / "v044.json", str(CANON / "pointers" / "v044.json"), "immutable v044 pointer"),
        file_row("authority_body", authority, str(authority), "exact ED0008; 24146 physical LF lines"),
        file_row("baseline_tex", baseline, str(baseline), "inherited 1.79 MB source-fidelity baseline"),
        file_row("candidate_tex", candidate, str(candidate), "surviving candidate witness"),
        file_row("candidate_replay", replay, "../replay/reader.tex", "surviving exact candidate replay"),
        identity_row("candidate_public_copy_historical", str(historical_public), 1925975, "47F8150D6750A02FF939C0E6CF4F07909858AB6DFEC8E511B047D4640BCFB235", "historical identity only; path absent"),
        file_row("historical_r03_freeze", R03 / "freeze3.csv", "../freeze3.csv", "historical ED0005 freeze"),
        file_row("historical_r03_root", R03 / "reader.tex", "../reader.tex", "historical exact base"),
        file_row("historical_r03_pdf", R03 / "reader.pdf", "../reader.pdf", "historical mechanical output"),
        set_row("historical_r03_editable_set", R03, "../reader.tex+../t0.tex-../t7.tex", "domain-separated filename|file_sha256 LF records"),
        file_row("inherited_r04_freeze", R04 / "freeze.csv", "../r04/freeze.csv", "immediate inherited-base freeze"),
        file_row("inherited_r04_root", R04 / "reader.tex", "../r04/reader.tex", "immediate inherited root"),
        file_row("inherited_r04_pdf", R04 / "reader.pdf", "../r04/reader.pdf", "immediate inherited mechanical output"),
        set_row("inherited_r04_editable_set", R04, "../r04/reader.tex+../r04/t0.tex-../r04/t7.tex", "immediate inherited editable-set identity"),
        file_row("independent_return_ledger", checker / "ja_r04.csv", str(checker / "ja_r04.csv"), "immutable checker return evidence; not producer-owned"),
        file_row("independent_return_receipt", checker / "ja_r04.md", str(checker / "ja_r04.md"), "immutable checker return receipt; not producer-owned"),
        file_row("target_root", HERE / "reader.tex", "reader.tex", "ED0008 returned-target successor root"),
        set_row("target_editable_set", HERE, "reader.tex+t0.tex-t7.tex", "domain-separated filename|file_sha256 LF records"),
    ]
    for index in range(8):
        rows.append(file_row(f"target_t{index}", HERE / f"t{index}.tex", f"t{index}.tex", "r05 component"))
    for name, role, note in [
        ("reader.pdf", "target_pdf", "mechanical output only; 419 pages by final log"),
        ("reader.log", "build_log", "final serial XeLaTeX log"),
        ("build.json", "build_receipt", "mechanical build and diagnostic receipt"),
        ("terms.csv", "terminology", "producer terminology ledger; Japanese approval not claimed"),
        ("notes.csv", "note_map", "73-row P40-P43 one-to-one source-note custody; byte-identical to r04"),
        ("chg.csv", "change_ledger", "inherited base and every r04-to-r05 changed locus"),
        ("adv.csv", "adverse_ledger", "six authority-owner observations; target faithful"),
        ("manifest.csv", "coverage_manifest", "complete source and target cursors regenerated for r05"),
        ("prov.md", "provenance", "r04-to-r05 lineage"),
        ("return.md", "producer_return", "static returned-target successor return"),
        ("pack.py", "freeze_generator", "pinned r04-derived manifest and r05 freeze generator"),
    ]:
        rows.append(file_row(role, HERE / name, name, note))
    rows.extend(
        [
            file_row("multi_day_gate", REBASE / "gate.csv", "../gate.csv", "append-only r05 reset to zero on 2026-08-07"),
            file_row("canon_watch", REBASE / "watch.json", "../watch.json", "five-day monitor state advanced to r05"),
        ]
    )

    with (HERE / "freeze.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["role", "path", "present", "bytes", "sha256", "note"],
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    pointer_raw = POINTER.read_bytes()
    if digest(pointer_raw) != EXPECTED_POINTER_SHA:
        raise RuntimeError("current pointer changed before r05 freeze")
    pointer = json.loads(pointer_raw.decode("utf-8"))
    authority = Path(str(pointer["default_translation_authority"]["path"]))
    validate_inputs(pointer, authority)
    inherited = load_r04_pack()
    inherited.write_manifest(authority)
    write_freeze(pointer, authority)
    for name in ("manifest.csv", "freeze.csv"):
        path = HERE / name
        print(f"{name}: bytes={path.stat().st_size} sha256={digest(path.read_bytes())}")
    print(f"r04_set={set_identity(R04)[1]}")
    print(f"r05_set={set_identity(HERE)[1]}")


if __name__ == "__main__":
    main()
