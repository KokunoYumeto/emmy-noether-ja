# JA-NOETH-R05-ED8-20260807 — static producer return

Successor root: reader.tex / 9B3C37E0C91E7BF924B5F6738BF97CDD4AA62DC806DD5BCE0D8904931E3E6F87.

Inherited base: r04/reader.tex / 2E2A927B1B498587A5F380E4307F9CB58BE32285969C0E625015B7528E9A56FE; inherited editable set F144CD3845F9BCEF5527A035B941A71B5EA2417D3F1C1E1EA3601B4CFA8B34AF; inherited freeze A37E6C40514BA9E30A0D4C375DF00ECB272FF894E88F9CEBE4E3A9562F1F5BBA.

Authority: pointer v044 / FF98F436CF8D38AA1D13CF1D969857CE277D02851CC79EFE521DFE1D0B45B98D; ED0008 / C83A94D25DE8FD27C66E2C6C50BAB04AA875E6C0A6A87BDFCA202E69A8EA660D.

Resolved batch:

- JA-R04-FORM-001: four exact \mo n tokens changed to \mo\eta at reader.tex:14121,14123,14125,14127.
- JA-R04-TERM-001: Differente is 差積 at reader.tex:8030,8038; ganze Zahl delta is 代数的整数 delta at 8038.
- JA-R04-TERM-002: three P14 occurrences normalized to 補加群 at reader.tex:8030,8138.
- JA-R04-TERM-003: post-P43 representation terminology harmonized to 交叉表現 in t0.tex:72, t4.tex:836,848,859,861,890,905,907,928,930, and t5.tex:130,203,212,237,265,299,301,307,372; terms.csv:T011 scope widened and T016--T017 added. 接合積 remains distinct and unchanged.
- JA-R04-SRC-BIB-001 remains an authority-owner action in adv.csv; t7.tex:157 remains faithful to ED0008:24140.

Every changed locus and the inherited identity are frozen in chg.csv. Six authority-owner observations remain explicit in adv.csv.

Editable-set SHA-256: E4BB1BE344A7A6FA2D4515959A01F5D462ACB330E82390B6ABABA57E9B7D51BA. Mechanical PDF: 419 pages / EAAC3E49289D52A249F6C5BAC3BCEACD0B40701957B5DD605A48D048FFAE7F5A. Build and byte checks are mechanical only. Clean-day count is 0 after the 2026-08-07 target reset. SGA remains held; nothing is publishable.
