# JA-NOETH-R08-ED11-20260809 — static producer successor

Successor root: `reader.tex`, 1,927,250 bytes, SHA-256 `2BF635B2F9B5DD2D9E8D706F27CF7465AB20DF042677663B23A346CA279767DC`. Editable-set SHA-256: `A7C1CA1218E83C290B4882C5ED9D817F7C1DEE555C96F999289AD7AE46F6DEEF`.

Inherited base: exact frozen r07 root `F51C64849E1BCB328AD3A84C64365EA6BA94C67197DC6E968F3B896B6DB660C0`; editable set `1EB642A19AF47028B9C38D1221F7F969D29452D2E2089267FEB935F48DE93AA9`; PDF `5E91E7F0D1C8761937EC180B8B0912E87F62DC620A4F05175E3294C5909C8C50`; freeze `DDEC649AF697C9D1200CA736FC99EE172C2E473FD774BAE751EAB2E692979186`. Authority: pointer v047 / `0053EA0B7E44DDE7EA7DC285ABC115DFC43F4A74B34C54DE8F39DE4E445D5BEA`; ED0011 / `9E6BF2BC3155ECE3DF98CD8A408C23662BEFB047A1DDF200CA1DC8476A488BF3` / 24,146 lines.

The exact ED0010-to-ED0011 delta is three logical lines carrying four accepted defects. r08 changes only reader lines 3946, 5341, and 7301: the P04 lambda bound, the P06 terminal exponent condition, and the P12 rho-th homogeneity factor. The accepted P06 diagonal coefficient product was already present in r07 and is explicitly recorded as inherited-current. `notes.csv` retains all 73 mappings and changes only the source prefix to line-stable ED0011. `t0.tex` through `t7.tex` are byte-identical to r07.

`CJK-NOETH-EXT-SYS-001` remains open under the explicit cross-lane exception in `xext.csv`; no extraction-accessibility clean claim is made.

Three fixed-epoch serial XeLaTeX passes exited zero and produced byte-identical PDFs. Mechanical PDF: 2,935,071 bytes / 421 pages / SHA-256 `5399229D7D97CC273EE0A0743E1435D095E5035BEE485BD380FC0678FCD81316`. Final log: `5A8429FA785D8D3D777C689CE991B309364E0732279580CFB8333E2928354D15`.

This authority/target rebase resets the three-day gate to 0/3 on 2026-08-09. Mechanical compilation is not source-fidelity, Japanese-language, formula, apparatus, extraction, rendered-page, or certification approval. SGA remains held; nothing is publishable.
