# JA-NOETH-CUM-20260804-002 — independent checker handoff

This successor invalidates `handoff.md` because the editable target changed. The first handoff was not delivered: two thread-control calls returned no result, and transcript/queue inspection showed no custody. This is still a producer handoff, not approval. Clean-day count is 0/3; SGA is held.

## Authority

Reopen the then-newest pointer/body at intake. Frozen authority is `NOETH-DE-AUTH-v019-20260804`: pointer 39,367 bytes / `FDBE531AA5F2175AD23363FB4F05B357A5ECD8A72B022D7ED644E39DF0B3CA79`; exact ED0004 body 2,153,575 bytes, 24,146 physical LF lines / `0CB422ECD397DD392A8625297A508DAEE3A5A934EA19EEEF49B47B319EA4F2BB`.

## Editable target and mechanical output

Root directory: `C:/Users/Floris/Documents/interlanguage/03_projects/language_management/cjk/03_working_translations/japanese/rebase`

- `reader.tex`: 1,926,162 bytes / `07504D989F691481B61A778D5364CD3705819A79A7B955B76464E5D0B1BE5BF7`
- `t0.tex`--`t7.tex`: unchanged identities enumerated in `freeze2.csv`.
- Domain-separated editable-set SHA-256: `E7E5835388E220FAC4C40FA2676344AD3660B19F3D13E859264DDB180D6168C6`.
- `reader.pdf`: 2,933,894 bytes, 420 pages by metadata / `B433DAF87DE8351153CFE5867D331C49E1122AF1A8650E3D5C331A6A5F9C610E`.
- `build/reader.log`: 30,239 bytes / `83727A5048D4467DA50147EEB8F5F9C0285E6E28C339856363B64024E195EC98`.

Two serial XeLaTeX passes exited zero. The final log has zero fatal/error/undefined/missing-character/overfull/underfull matches. Font substitution warnings remain. The producer did not render or visually open pages.

## Exact producer delta from the proven candidate

`delta.csv` contains four root hunks:

1. P06 source line 5101 / target line 4900: `H(\xi)` to `H^*(\xi)`.
2. P06 source line 5105 / target line 4907: the same correction.
3. P31 source line 16017 / target line 14972: inherited bytes `0x0C + ootnote` repaired to `\footnote`; see `fix.csv`.
4. Root lines 20077--20086 bind the eight translated components covering ED0004 lines 20988--24145.

Numbered Paper 43 ends at source line 20984. Source lines 20988--21004 are a TeX wrapper and the Deuring title begins at 21005, so there is no Paper 43 duplication. Exact physical-LF spans and normalized hashes are in `cursor2.csv`; per-paper cursors are in corrected `manifest.csv`.

## Independent checker requirements

- Verify exact custody against `freeze2.csv` and the then-current German authority.
- Collate all bound spans: front matter, Papers 1--43, wrapper, Deuring lecture §§1--31, Kapferer paper and Noether supplement, bibliography/terminal lists, document close, component boundaries, and inherited RA10 apparatus.
- Independently assess semantic completeness, formulas/indices/environments, notes/apparatus/bibliography, `adverse.csv`, and the Paper 31 control repair.
- Independently review Japanese language and terminology.
- Compile independently, validate PDF text/metadata, freshly render and visually inspect all 420 pages.
- Return stable finding IDs and exact loci or a sealed disposition. Producer compilation and records are not approval.

Any pointer/body or editable-target change invalidates this freeze, resets the producer clean count to zero, and requires another rebuild and route. The producer must separately complete three clean audits on three later Europe/Berlin calendar days.
