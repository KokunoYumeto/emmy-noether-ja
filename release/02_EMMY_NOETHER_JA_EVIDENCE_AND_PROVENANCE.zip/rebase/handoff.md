# JA-NOETH-CUM-20260804-001 — independent checker handoff

This is a producer handoff, not an approval or certification. The cumulative Japanese target is unchecked and the producer's three-distinct-day gate is at 0/3. SGA is held and outside scope.

## Frozen authority

- Current pointer: `C:/Users/Floris/Documents/interlanguage/03_projects/noether/07_german_canon_control/CURRENT_GERMAN_AUTHORITY_POINTER.json`
- Pointer identity: `NOETH-DE-AUTH-v019-20260804`, 39,367 bytes, SHA-256 `FDBE531AA5F2175AD23363FB4F05B357A5ECD8A72B022D7ED644E39DF0B3CA79`
- Resolved body: `C:/Users/Floris/Documents/interlanguage/03_projects/noether/07_german_canon_control/candidates/ED0004/noether.tex`
- Body identity: 2,153,575 bytes, 24,146 lines, SHA-256 `0CB422ECD397DD392A8625297A508DAEE3A5A934EA19EEEF49B47B319EA4F2BB`
- v015 through v019 were independently observed as metadata-only successors resolving to these exact body bytes. Reopen the newest pointer and body at checker intake; do not inherit this freeze if either has advanced.

## Frozen editable target

Root: `C:/Users/Floris/Documents/interlanguage/03_projects/language_management/cjk/03_working_translations/japanese/rebase`

- `reader.tex`: 1,926,161 bytes; SHA-256 `566359146173A5CE12DC7A8FE4731819B29AAF555980771EC23DF97B3AF23D0C`
- `t0.tex`: 15,363 bytes; SHA-256 `1CC90D2C98E20D1C8E62CA5DABF147E9E4F42429704F2B66AA004674F7B25B35`
- `t1.tex`: 20,314 bytes; SHA-256 `25C00E25607CD572C714B65630321859CF74FB3165A50752186300E0DB060D45`
- `t2.tex`: 13,907 bytes; SHA-256 `9D0A29BB9657B85C35D79D7EC560E5CA4DEB8405551206AA03D1C7F65DCF8B1B`
- `t3.tex`: 34,147 bytes; SHA-256 `B3C9374DB2FEC2E1CB676A3C13D4330497121BEB9B1E4F15F4C8EE1AA2B6E495`
- `t4.tex`: 54,667 bytes; SHA-256 `CD43ABFDD496E70E1372C3DE014CE5441D1A2DF849D05D2E6C7531801F79FC86`
- `t5.tex`: 34,820 bytes; SHA-256 `D45B03F5AF6FC5F063D6C8B768252281BA9474D66BEEAFDFD5BA804CED03BE19`
- `t6.tex`: 23,680 bytes; SHA-256 `7527B0A7F75D011130A8D445757E8EAD619560673ED54F344535923B1328AC42`
- `t7.tex`: 7,658 bytes; SHA-256 `C4442FF7ACECA8A87308410695CD1BBB3B6D941623FE85BF43F7C82CD9EC84CB`
- Domain-separated editable-set identity: SHA-256 `CD941B8AEAAA1DC78F7107BE2A484E7908C60D75D5B2E45B70555344586B74E5`.

Mechanical output: `reader.pdf`, 2,933,899 bytes, 420 pages by metadata, SHA-256 `C617A6F6C197E5174D58BECE61883C0711A84775BCEB93EA2F538EB942769F17`. Build log: `build/reader.log`, 30,239 bytes, SHA-256 `AA45EADE4BF132317AEAF0241E9CA447F25B66CA4901ABD59FD191AE4141FC4F`.

## Scope and producer delta

The inherited cumulative candidate covers numbered Papers 1--43 and RA10 apparatus. Its ancestry was replayed exactly but none of its prior approvals were inherited. The producer changed only:

- P06 at German lines 5101 and 5105 / Japanese root lines 4900 and 4907: `H(\xi)` to `H^*(\xi)`.
- The omitted ED0004 tail, lines 20988--24145, translated into `t0.tex`--`t7.tex`: Deuring lecture §§1--31, Kapferer paper and joint Noether supplement, bibliography, and terminal lists.

`diff.json` and `diff.csv` establish baseline/candidate lineage. `delta.csv` enumerates the three root hunks. `manifest.csv` provides exact per-paper source/target cursors. `tail.csv` and `cursor.csv` bind every added component. `terms.csv` and `adverse.csv` are producer records, not checker conclusions.

## Producer actions completed

- Full governance/reset intake and independent corpus inventory.
- Baseline/candidate identities, exact candidate assembly replay, and baseline-versus-candidate diff intake.
- Complete reading and hash verification of the current pointer and resolved authority body.
- P06 rebase and post-P43 Japanese translation production.
- Two serial XeLaTeX passes, both exit zero; final diagnostic census found zero fatal/error/undefined/missing-character/overfull/underfull matches.

## Explicitly unperformed

- Independent German-to-Japanese source-fidelity or completeness verdict.
- Japanese language, style, historical terminology, or localization approval.
- Independent formula, index, note, bibliography, and RA10-apparatus audit.
- PDF text/semantic review, page rendering, visual inspection, or certification.
- Any SGA work.

## Required independent checker work

1. Reopen the then-newest German pointer and resolved body; verify exact custody and invalidate this handoff if authority or target identities have changed.
2. Collate all bound spans, not only the producer delta: front matter, Papers 1--43, the complete post-P43 tail, bibliography/terminal lists, input boundaries, and inherited RA10 apparatus.
3. Independently assess semantic completeness, formulas and indices, environments, footnotes/apparatus, bibliography, and the five adverse observations.
4. Independently review Japanese language and terminology, returning exact finding IDs and loci for every correction.
5. Compile independently in serial passes; validate PDF text and metadata; freshly render and visually inspect all 420 pages.
6. Return a sealed disposition without treating transport, mechanical compilation, or producer records as approval.

The producer will separately perform the mandatory three clean audits on three later calendar days. Any authority or editable-target change resets that count to zero and requires an updated Japanese freeze, rebuild, and checker route.
