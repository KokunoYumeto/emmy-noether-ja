from __future__ import annotations

import csv
import hashlib
import json
import re
from pathlib import Path


HERE = Path(__file__).resolve().parent
R03 = HERE.parent
ROOT = HERE.parents[6]
CANON = ROOT / "03_projects" / "noether" / "07_german_canon_control"
POINTER = CANON / "CURRENT_GERMAN_AUTHORITY_POINTER.json"

EXPECTED_POINTER_ID = "NOETH-DE-AUTH-v044-20260807"
EXPECTED_POINTER_SHA = "FF98F436CF8D38AA1D13CF1D969857CE277D02851CC79EFE521DFE1D0B45B98D"
EXPECTED_AUTHORITY_SHA = "C83A94D25DE8FD27C66E2C6C50BAB04AA875E6C0A6A87BDFCA202E69A8EA660D"
EXPECTED_R03_ROOT = "6D8A36F22F44052C7209DA9414EFFF31C78F7B6E29A11733D403776BBA5D4130"
EXPECTED_R03_SET = "AC0ABE6B7DB5989ED156AA7902096511A350DC0C47ACB4A37B06A225382D9FB7"
EXPECTED_R04_ROOT = "2E2A927B1B498587A5F380E4307F9CB58BE32285969C0E625015B7528E9A56FE"
EXPECTED_R04_SET = "F144CD3845F9BCEF5527A035B941A71B5EA2417D3F1C1E1EA3601B4CFA8B34AF"
EXPECTED_PDF = "9B19F92C8DE034826FD181826F48AFC53A8094773C35C8BBD9AB0B7E868042E5"
EXPECTED_LOG = "1A3981949FADE3C24020949DFA42E7458CE80CD914CC50E16B04C4941B421834"

PAPER_RE = re.compile(
    r"(?:\\section\*\{|\{\\Large\\bfseries\s+)"
    r"([1-9]|[1-3][0-9]|4[0-3])\."
)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def raw_lines(path: Path) -> list[bytes]:
    parts = path.read_bytes().split(b"\n")
    result = [part + b"\n" for part in parts[:-1]]
    if parts[-1]:
        result.append(parts[-1])
    return result


def markers(path: Path) -> dict[int, int]:
    found: dict[int, int] = {}
    for number, line in enumerate(raw_lines(path), start=1):
        text = line.decode("utf-8").rstrip("\r\n")
        match = PAPER_RE.search(text)
        if match:
            paper = int(match.group(1))
            if paper not in found and (not found or paper >= max(found)):
                found[paper] = number
    special = {
        4: (r"{\Large\bfseries Zur Invariantentheorie\\", -2),
        17: (r"{\Large\bfseries Moduln in nichtkommutativen Bereichen", -10),
        18: (r"% Paper 18: source-visible conference contribution begins here.", 0),
        19: (r"{\Large\bfseries Idealtheorie in Ringbereichen.}", -4),
    }
    decoded = [line.decode("utf-8").rstrip("\r\n") for line in raw_lines(path)]
    for paper, (needle, offset) in special.items():
        if paper in found:
            continue
        hits = [number for number, text in enumerate(decoded, start=1) if needle in text]
        if len(hits) == 1:
            found[paper] = hits[0] + offset
    found = dict(sorted(found.items()))
    if set(found) != set(range(1, 44)):
        raise RuntimeError(f"paper markers incomplete in {path}: {sorted(found)}")
    return found


def slice_stats(path: Path, first: int, last: int) -> dict[str, object]:
    lines = raw_lines(path)
    if first < 1 or last < first or last > len(lines):
        raise RuntimeError(f"invalid slice {path}:{first}-{last}; lines={len(lines)}")
    data = b"".join(lines[first - 1:last])
    return {"lines": last - first + 1, "bytes": len(data), "sha256": digest(data)}


def data_stats(data: bytes, lines: int) -> dict[str, object]:
    return {"lines": lines, "bytes": len(data), "sha256": digest(data)}


def manifest_row(
    unit: str,
    source_path: str,
    source_locus: str,
    source: dict[str, object] | None,
    target_path: str,
    target_locus: str,
    target: dict[str, object],
    state: str,
) -> dict[str, object]:
    return {
        "unit": unit,
        "source_path": source_path,
        "source_locus": source_locus,
        "source_lines": "" if source is None else source["lines"],
        "source_bytes": "" if source is None else source["bytes"],
        "source_sha256": "" if source is None else source["sha256"],
        "target_path": target_path,
        "target_locus": target_locus,
        "target_lines": target["lines"],
        "target_bytes": target["bytes"],
        "target_sha256": target["sha256"],
        "state": state,
    }


def write_manifest(authority: Path) -> None:
    root = HERE / "reader.tex"
    source_marks = markers(authority)
    target_marks = markers(root)
    if source_marks[43] != 20177 or target_marks[43] != 19266:
        raise RuntimeError("P43 start cursor changed")

    rows: list[dict[str, object]] = []
    state = "producer_bound_not_independently_approved"
    rows.append(
        manifest_row(
            "front",
            "ED0008/noether.tex",
            "1-381",
            slice_stats(authority, 1, 381),
            "reader.tex",
            "1-282",
            slice_stats(root, 1, 282),
            state,
        )
    )
    for paper in range(1, 43):
        sf = source_marks[paper]
        sl = source_marks[paper + 1] - 1
        tf = target_marks[paper]
        tl = target_marks[paper + 1] - 1
        rows.append(
            manifest_row(
                f"P{paper:02d}",
                "ED0008/noether.tex",
                f"{sf}-{sl}",
                slice_stats(authority, sf, sl),
                "reader.tex",
                f"{tf}-{tl}",
                slice_stats(root, tf, tl),
                state,
            )
        )
    rows.append(
        manifest_row(
            "P43",
            "ED0008/noether.tex",
            "20177-20984",
            slice_stats(authority, 20177, 20984),
            "reader.tex",
            "19266-20075",
            slice_stats(root, 19266, 20075),
            state,
        )
    )
    rows.append(
        manifest_row(
            "post_gap",
            "ED0008/noether.tex",
            "20985-20987",
            slice_stats(authority, 20985, 20987),
            "reader.tex",
            "20076-20077",
            slice_stats(root, 20076, 20077),
            "structural_boundary_plus_binding_comment",
        )
    )
    rows.append(
        manifest_row(
            "post_inputs",
            "",
            "target-only input bindings",
            None,
            "reader.tex",
            "20078-20086",
            slice_stats(root, 20078, 20086),
            "target_structure_not_additional_source_coverage",
        )
    )

    post = [
        ("post_wrapper", 20988, 21004, "t0.tex", 1, 20),
        ("t0_body", 21005, 21275, "t0.tex", 21, 297),
        ("t1", 21276, 21565, "t1.tex", 1, len(raw_lines(HERE / "t1.tex"))),
        ("t2", 21566, 21811, "t2.tex", 1, len(raw_lines(HERE / "t2.tex"))),
        ("t3", 21812, 22366, "t3.tex", 1, len(raw_lines(HERE / "t3.tex"))),
        ("t4", 22367, 23343, "t4.tex", 1, len(raw_lines(HERE / "t4.tex"))),
        ("t5", 23344, 23740, "t5.tex", 1, len(raw_lines(HERE / "t5.tex"))),
        ("t6", 23741, 23983, "t6.tex", 1, len(raw_lines(HERE / "t6.tex"))),
        ("t7", 23984, 24145, "t7.tex", 1, len(raw_lines(HERE / "t7.tex"))),
    ]
    for unit, sf, sl, target_name, tf, tl in post:
        target_path = HERE / target_name
        rows.append(
            manifest_row(
                unit,
                "ED0008/noether.tex",
                f"{sf}-{sl}",
                slice_stats(authority, sf, sl),
                target_name,
                f"{tf}-{tl}",
                slice_stats(target_path, tf, tl),
                state,
            )
        )

    note_lines = raw_lines(HERE / "notes.csv")
    ra_note_lines = [line for line in note_lines[1:] if b",RA10," in line]
    if len(ra_note_lines) != 26:
        raise RuntimeError(f"expected 26 RA note-map rows, got {len(ra_note_lines)}")
    ra_note_data = b"".join(ra_note_lines)
    rows.append(
        manifest_row(
            "RA10",
            "notes.csv",
            "placement=RA10; 26 unique source-note rows",
            data_stats(ra_note_data, 26),
            "reader.tex",
            "20087-20122",
            slice_stats(root, 20087, 20122),
            "derived_apparatus_no_additional_source_coverage",
        )
    )
    rows.append(
        manifest_row(
            "pre_close_blank",
            "",
            "target-only separator",
            None,
            "reader.tex",
            "20123",
            slice_stats(root, 20123, 20123),
            "target_structure_not_additional_source_coverage",
        )
    )
    rows.append(
        manifest_row(
            "document_close",
            "ED0008/noether.tex",
            "24146",
            slice_stats(authority, 24146, 24146),
            "reader.tex",
            "20124",
            slice_stats(root, 20124, 20124),
            "exact_structural_close",
        )
    )

    fields = [
        "unit", "source_path", "source_locus", "source_lines", "source_bytes",
        "source_sha256", "target_path", "target_locus", "target_lines",
        "target_bytes", "target_sha256", "state",
    ]
    with (HERE / "manifest.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def set_identity(directory: Path) -> tuple[int, str]:
    names = ["reader.tex", *(f"t{i}.tex" for i in range(8))]
    payload = "".join(
        f"{name}|{digest((directory / name).read_bytes())}\n" for name in names
    ).encode("utf-8")
    return sum((directory / name).stat().st_size for name in names), digest(payload)


def file_row(role: str, path: Path, shown: str, note: str) -> dict[str, object]:
    data = path.read_bytes()
    return {
        "role": role,
        "path": shown,
        "present": "true",
        "bytes": len(data),
        "sha256": digest(data),
        "note": note,
    }


def identity_row(role: str, path: str, size: int, sha: str, note: str) -> dict[str, object]:
    return {
        "role": role,
        "path": path,
        "present": "false",
        "bytes": size,
        "sha256": sha,
        "note": note,
    }


def set_row(role: str, directory: Path, shown: str, note: str) -> dict[str, object]:
    size, sha = set_identity(directory)
    return {
        "role": role,
        "path": shown,
        "present": "true",
        "bytes": size,
        "sha256": sha,
        "note": note,
    }


def write_freeze(pointer: dict[str, object], authority: Path) -> None:
    cjk = ROOT / "03_projects" / "language_management" / "cjk"
    ja = cjk / "03_working_translations" / "japanese"
    baseline = (
        cjk / "01_recovered_witnesses" / "noether_cjk_chinese_japanese_cumulative_20260702"
        / "translations" / "non_slavic" / "japanese" / "source_fidelity" / "v001"
        / "Noether_Japanese_Cumulative_SourceFidelity_v001.tex"
    )
    candidate = ja / "noether_ja" / "reader.tex"
    replay = R03 / "replay" / "reader.tex"
    historical_public = ROOT / "03_projects" / "noether" / "08_zenodo" / "r6" / "20-ja.tex"

    if historical_public.exists():
        raise RuntimeError("historical candidate_public_copy unexpectedly reappeared; re-audit presence state")
    if digest(baseline.read_bytes()) != "4A284DF3FAC4D53D305659B539AF2FEB17902BFB4C254A7DF62A155C6BC23131":
        raise RuntimeError("baseline changed")
    for witness in (candidate, replay):
        if digest(witness.read_bytes()) != "47F8150D6750A02FF939C0E6CF4F07909858AB6DFEC8E511B047D4640BCFB235":
            raise RuntimeError(f"candidate witness changed: {witness}")
    if digest((R03 / "reader.tex").read_bytes()) != EXPECTED_R03_ROOT:
        raise RuntimeError("r03 root changed")
    if set_identity(R03)[1] != EXPECTED_R03_SET:
        raise RuntimeError("r03 editable set changed")
    if digest((HERE / "reader.tex").read_bytes()) != EXPECTED_R04_ROOT:
        raise RuntimeError("r04 root changed before freeze")
    if set_identity(HERE)[1] != EXPECTED_R04_SET:
        raise RuntimeError("r04 editable set changed before freeze")
    if digest((HERE / "reader.pdf").read_bytes()) != EXPECTED_PDF:
        raise RuntimeError("r04 PDF changed before freeze")
    if digest((HERE / "reader.log").read_bytes()) != EXPECTED_LOG:
        raise RuntimeError("r04 log changed before freeze")

    rows: list[dict[str, object]] = [
        file_row("authority_pointer_current", POINTER, str(POINTER), EXPECTED_POINTER_ID),
        file_row("authority_pointer_versioned", CANON / "pointers" / "v044.json", str(CANON / "pointers" / "v044.json"), "immutable v044 pointer"),
        file_row("authority_body", authority, str(authority), "exact ED0008; 24146 physical LF lines"),
        file_row("inherited_authority_ed5", CANON / "candidates" / "ED0005" / "noether.tex", str(CANON / "candidates" / "ED0005" / "noether.tex"), "authority bound by inherited r03"),
        file_row("baseline_tex", baseline, str(baseline), "inherited 1.79 MB source-fidelity baseline"),
        file_row("candidate_tex", candidate, str(candidate), "surviving candidate witness"),
        file_row("candidate_replay", replay, "../replay/reader.tex", "surviving exact candidate replay"),
        identity_row("candidate_public_copy_historical", str(historical_public), 1925975, "47F8150D6750A02FF939C0E6CF4F07909858AB6DFEC8E511B047D4640BCFB235", "historical identity only; path absent and not claimed replayable-present"),
        file_row("inherited_r03_freeze", R03 / "freeze3.csv", "../freeze3.csv", "historical ED0005 freeze"),
        file_row("inherited_r03_root", R03 / "reader.tex", "../reader.tex", "exact inherited base"),
        file_row("inherited_r03_pdf", R03 / "reader.pdf", "../reader.pdf", "historical mechanical output"),
        set_row("inherited_r03_editable_set", R03, "../reader.tex+../t0.tex-../t7.tex", "domain-separated filename|file_sha256 LF records"),
        file_row("target_root", HERE / "reader.tex", "reader.tex", "ED0008 successor root"),
        set_row("target_editable_set", HERE, "reader.tex+t0.tex-t7.tex", "domain-separated filename|file_sha256 LF records"),
    ]
    for index in range(8):
        rows.append(file_row(f"target_t{index}", HERE / f"t{index}.tex", f"t{index}.tex", "r04 component"))
    for name, role, note in [
        ("reader.pdf", "target_pdf", "mechanical output only; 419 pages by final log"),
        ("reader.log", "build_log", "final serial XeLaTeX log"),
        ("build.json", "build_receipt", "mechanical build and diagnostic receipt"),
        ("terms.csv", "terminology", "producer terminology ledger; language approval not claimed"),
        ("notes.csv", "note_map", "73-row P40-P43 one-to-one source-note custody"),
        ("chg.csv", "change_ledger", "inherited and changed loci"),
        ("adv.csv", "adverse_ledger", "five authority-owner formula observations; target faithful"),
        ("manifest.csv", "coverage_manifest", "split complete source and target cursors"),
        ("prov.md", "provenance", "r03-to-r04 lineage"),
        ("return.md", "producer_return", "static ED0008 successor return"),
        ("pack.py", "freeze_generator", "pinned manifest/freeze generator"),
    ]:
        rows.append(file_row(role, HERE / name, name, note))
    rows.extend(
        [
            file_row("multi_day_gate", R03 / "gate.csv", "../gate.csv", "append-only reset to zero on 2026-08-07"),
            file_row("canon_watch", R03 / "watch.json", "../watch.json", "five-day monitor state advanced to v044/r04"),
        ]
    )

    with (HERE / "freeze.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["role", "path", "present", "bytes", "sha256", "note"],
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    if ROOT.name != "interlanguage":
        raise RuntimeError(f"unexpected workspace root: {ROOT}")
    pointer_raw = POINTER.read_bytes()
    if digest(pointer_raw) != EXPECTED_POINTER_SHA:
        raise RuntimeError("current pointer changed before r04 freeze")
    pointer = json.loads(pointer_raw.decode("utf-8"))
    if pointer["pointer_id"] != EXPECTED_POINTER_ID:
        raise RuntimeError("current pointer ID changed before r04 freeze")
    authority_record = pointer["default_translation_authority"]
    authority = Path(str(authority_record["path"]))
    authority_raw = authority.read_bytes()
    if len(authority_raw) != int(authority_record["raw_bytes"]):
        raise RuntimeError("authority byte count disagrees with pointer")
    if digest(authority_raw) != EXPECTED_AUTHORITY_SHA or str(authority_record["raw_sha256"]) != EXPECTED_AUTHORITY_SHA:
        raise RuntimeError("authority hash disagrees with pinned ED0008")

    write_manifest(authority)
    write_freeze(pointer, authority)
    for name in ("manifest.csv", "freeze.csv"):
        path = HERE / name
        print(f"{name}: bytes={path.stat().st_size} sha256={digest(path.read_bytes())}")
    print(f"r03_set={set_identity(R03)[1]}")
    print(f"r04_set={set_identity(HERE)[1]}")


if __name__ == "__main__":
    main()
