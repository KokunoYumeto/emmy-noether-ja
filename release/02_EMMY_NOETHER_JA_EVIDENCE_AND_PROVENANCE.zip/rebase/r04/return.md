# JA-NOETH-R04-ED8-20260807 — static producer return

Static successor root: `reader.tex` / `2E2A927B1B498587A5F380E4307F9CB58BE32285969C0E625015B7528E9A56FE`.

Inherited base: r03 `../reader.tex` / `6D8A36F22F44052C7209DA9414EFFF31C78F7B6E29A11733D403776BBA5D4130`; inherited editable set `AC0ABE6B7DB5989ED156AA7902096511A350DC0C47ACB4A37B06A225382D9FB7`.

Authority: pointer v044 / `FF98F436CF8D38AA1D13CF1D969857CE277D02851CC79EFE521DFE1D0B45B98D`; ED0008 / `C83A94D25DE8FD27C66E2C6C50BAB04AA875E6C0A6A87BDFCA202E69A8EA660D`.

Resolved batch:

- `JA-R03-ED8-001` through `-003`: corrected at `t1.tex:154`, `t1.tex:179`, and `t2.tex:73-74`.
- `JA-R03-TERM-001`: corrected at `reader.tex:8038,8103`.
- `JA-R03-APP-001`: duplicate RA notes removed; exact 73-note custody is in `notes.csv`.
- `JA-R03-TERM-002`: `terms.csv:T011` reconciled to `交叉表現`, scope P41; `T015` records `Ordnung=整環`.
- `JA-R03-PROV-001`: `manifest.csv` now separates numbered P43, gap, wrapper, post components, RA10, and close.
- `JA-R03-PROV-002`: the absent old public duplicate is marked historical, not replayable-present, in `freeze.csv`.
- `JA-R03-PROV-003`: this freeze is pinned to v044/ED0008 and `chg.csv` enumerates every inherited and changed locus.

Five authority-owner formula observations remain unchanged and explicit in `adv.csv`; no Japanese divergence was introduced.

Editable-set SHA-256: `F144CD3845F9BCEF5527A035B941A71B5EA2417D3F1C1E1EA3601B4CFA8B34AF`. Mechanical PDF: 419 pages / `9B19F92C8DE034826FD181826F48AFC53A8094773C35C8BBD9AB0B7E868042E5`. Build and byte checks are mechanical only. Clean-day count is 0 after the 2026-08-07 authority/target reset. SGA remains held; nothing is publishable.
