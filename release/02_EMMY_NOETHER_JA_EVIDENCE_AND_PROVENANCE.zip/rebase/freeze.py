from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
CJK = HERE.parents[2]
ROOT = CJK.parents[2]
JA = HERE.parent
CANON = ROOT / "03_projects" / "noether" / "07_german_canon_control"
POINTER = CANON / "CURRENT_GERMAN_AUTHORITY_POINTER.json"

EXPECTED_POINTER_ID = "NOETH-DE-AUTH-v033-20260805"
EXPECTED_POINTER_SHA = "816BE0E4F5821C5AFDFF744AFF98898C12D4EB3782A42900DA0C3BBE4C418BE0"
EXPECTED_AUTHORITY_SHA = "1A44F967B29972E8F99E5C323A479162AD82A23FC457395915A4BB9DDF51AD41"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def row(role: str, path: Path, note: str, shown_path: str | None = None) -> dict[str, object]:
    data = path.read_bytes()
    return {
        "role": role,
        "path": shown_path if shown_path is not None else str(path),
        "bytes": len(data),
        "sha256": digest(data),
        "note": note,
    }


def main() -> None:
    pointer_raw = POINTER.read_bytes()
    pointer = json.loads(pointer_raw.decode("utf-8"))
    authority = pointer["default_translation_authority"]
    authority_path = Path(str(authority["path"]))
    if pointer["pointer_id"] != EXPECTED_POINTER_ID or digest(pointer_raw) != EXPECTED_POINTER_SHA:
        raise RuntimeError("current pointer changed before ED0005 successor freeze")
    if digest(authority_path.read_bytes()) != EXPECTED_AUTHORITY_SHA:
        raise RuntimeError("current authority changed before ED0005 successor freeze")

    baseline = (
        CJK
        / "01_recovered_witnesses"
        / "noether_cjk_chinese_japanese_cumulative_20260702"
        / "translations"
        / "non_slavic"
        / "japanese"
        / "source_fidelity"
        / "v001"
        / "Noether_Japanese_Cumulative_SourceFidelity_v001.tex"
    )
    candidate = JA / "noether_ja" / "reader.tex"
    public_candidate = ROOT / "03_projects" / "noether" / "08_zenodo" / "r6" / "20-ja.tex"

    rows = [
        row("authority_pointer_current", POINTER, EXPECTED_POINTER_ID),
        row("authority_pointer_versioned", CANON / "pointers" / "v033.json", "byte-identical versioned pointer"),
        row("authority_body", authority_path, "resolved ED0005; 24146 physical LF lines"),
        row("baseline_tex", baseline, "inherited baseline preserved"),
        row("candidate_tex", candidate, "candidate witness preserved"),
        row("candidate_replay", HERE / "replay" / "reader.tex", "exact independent candidate replay", "replay/reader.tex"),
        row("candidate_public_copy", public_candidate, "exact candidate duplicate"),
        row("predecessor_root", HERE / "reader2.tex", "exact ED0004 successor target retained", "reader2.tex"),
        row("predecessor_pdf", HERE / "reader2.pdf", "exact predecessor mechanical PDF retained", "reader2.pdf"),
        row("predecessor_log", HERE / "log2.txt", "exact predecessor final build log retained", "log2.txt"),
        row("target_root", HERE / "reader.tex", "ED0005 successor editable root", "reader.tex"),
    ]

    target_names = ["reader.tex", *(f"t{i}.tex" for i in range(8))]
    set_payload = "".join(
        f"{name}|{digest((HERE / name).read_bytes())}\n" for name in target_names
    ).encode("utf-8")
    rows.append(
        {
            "role": "editable_set",
            "path": "+".join(target_names),
            "bytes": sum((HERE / name).stat().st_size for name in target_names),
            "sha256": digest(set_payload),
            "note": "domain-separated filename|file_sha256 LF records in listed order",
        }
    )

    spans = [(20988, 21275), (21276, 21565), (21566, 21811), (21812, 22366),
             (22367, 23343), (23344, 23740), (23741, 23983), (23984, 24145)]
    for index, (first, last) in enumerate(spans):
        rows.append(row(f"target_t{index}", HERE / f"t{index}.tex", f"ED0005 lines {first}-{last}", f"t{index}.tex"))
    for index, (first, last) in enumerate(spans):
        rows.append(row(f"source_t{index}", HERE / f"de{index}.tex", f"exact raw ED0005 extraction {first}-{last}", f"de{index}.tex"))

    rows.extend(
        [
            row("target_pdf", HERE / "reader.pdf", "mechanical output only; 420 pages by final log", "reader.pdf"),
            row("build_log", HERE / "build" / "reader.log", "second serial XeLaTeX pass", "build/reader.log"),
            row("lineage_summary", HERE / "diff.json", "baseline/candidate/current statistics", "diff.json"),
            row("lineage_diff", HERE / "diff.csv", "baseline-to-candidate exact LF hunks", "diff.csv"),
            row("rebase_delta", HERE / "delta.csv", "five candidate-to-current root hunks", "delta.csv"),
            row("paper_lineage", HERE / "papers.csv", "physical-LF per-paper identities", "papers.csv"),
            row("paper_cursor", HERE / "manifest.csv", "ED0005/current per-paper bindings", "manifest.csv"),
            row("source_delta_ed4", HERE / "source.csv", "ED0003-to-ED0004 changes retained", "source.csv"),
            row("source_delta_ed5", HERE / "source5.csv", "one-line ED0004-to-ED0005 change", "source5.csv"),
            row("tail_cursor", HERE / "tail.csv", "post-numbered raw ED0005 block map", "tail.csv"),
            row("intake_hashes", HERE / "hashes.csv", "primary lineage identities", "hashes.csv"),
            row("terminology", HERE / "terms.csv", "producer choices; approval pending", "terms.csv"),
            row("adverse_current", HERE / "adv3.csv", "current-source observations only", "adv3.csv"),
            row("multi_day_gate", HERE / "gate.csv", "append-only dated gate; clean days 0/3", "gate.csv"),
            row("p31_fix", HERE / "fix.csv", "predecessor proven control repair", "fix.csv"),
            row("ed5_change", HERE / "chg3.csv", "exact ED0005 target rebase record", "chg3.csv"),
            row("successor_cursor", HERE / "cursor3.csv", "semantic and physical-LF bindings", "cursor3.csv"),
            row("successor_provenance", HERE / "prov3.md", "ED0005 successor provenance", "prov3.md"),
            row("successor_handoff", HERE / "handoff3.md", "independent checker packet", "handoff3.md"),
            row("extract_script", HERE / "prep.py", "current-pointer exact source extraction", "prep.py"),
            row("intake_script", HERE / "mkdiff.py", "current-pointer lineage generation", "mkdiff.py"),
            row("personal_audit_script", HERE / "audit.py", "read-only bound-span replay; never logs or certifies", "audit.py"),
            row("freeze_script", HERE / "freeze.py", "ED0005 freeze generator", "freeze.py"),
            row("assembly_replay_script", HERE / "replay.ps1", "candidate ancestry replay preserved", "replay.ps1"),
            row("initial_freeze", HERE / "freeze.csv", "superseded; retained", "freeze.csv"),
            row("initial_handoff", HERE / "handoff.md", "superseded and undelivered; retained", "handoff.md"),
            row("predecessor_freeze", HERE / "freeze2.csv", "ED0004 successor freeze; superseded", "freeze2.csv"),
            row("predecessor_handoff", HERE / "handoff2.md", "ED0004 successor handoff; superseded", "handoff2.md"),
            row("predecessor_provenance", HERE / "prov2.md", "ED0004 successor provenance; retained", "prov2.md"),
            row("predecessor_cursor", HERE / "cursor2.csv", "ED0004 successor cursor; retained", "cursor2.csv"),
        ]
    )

    out = HERE / "freeze3.csv"
    with out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["role", "path", "bytes", "sha256", "note"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"rows={len(rows)}")
    print(f"bytes={out.stat().st_size}")
    print(f"sha256={digest(out.read_bytes())}")
    print(f"editable_set_sha256={digest(set_payload)}")


if __name__ == "__main__":
    main()
