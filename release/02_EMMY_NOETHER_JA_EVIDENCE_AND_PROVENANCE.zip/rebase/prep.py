from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
CANON = ROOT.parents[4] / "noether" / "07_german_canon_control"
POINTER = CANON / "CURRENT_GERMAN_AUTHORITY_POINTER.json"

# One-based, inclusive lines in the current German authority.  Boundaries
# follow source chapters and post-lecture units; they are deliberately
# independent of inherited Japanese paper labels.  Reconfirm them manually if
# a future authority changes line structure.
BLOCKS = (
    ("t0", 20988, 21275, "lecture title, contents, introduction, chapter I"),
    ("t1", 21276, 21565, "lecture chapter II"),
    ("t2", 21566, 21811, "lecture chapter III"),
    ("t3", 21812, 22366, "lecture chapter IV"),
    ("t4", 22367, 23343, "lecture chapter V"),
    ("t5", 23344, 23740, "lecture chapter VI"),
    ("t6", 23741, 23983, "Kapferer paper and joint Noether supplement"),
    ("t7", 23984, 24145, "bibliography and terminal lists"),
)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def current_source() -> tuple[Path, dict[str, object]]:
    pointer = json.loads(POINTER.read_text(encoding="utf-8"))
    authority = pointer["default_translation_authority"]
    source = Path(str(authority["path"]))
    raw = source.read_bytes()
    if len(raw) != int(authority["raw_bytes"]):
        raise RuntimeError("current authority byte count does not match pointer")
    if sha256(raw) != str(authority["raw_sha256"]):
        raise RuntimeError("current authority SHA-256 does not match pointer")
    return source, pointer


def main() -> None:
    source, pointer = current_source()
    raw = source.read_bytes()
    text = raw.decode("utf-8")
    # Authority cursors are physical LF lines.  Do not let other Unicode
    # control characters create synthetic line boundaries.
    parts = text.split("\n")
    lines = [part + "\n" for part in parts[:-1]]
    if parts[-1]:
        lines.append(parts[-1])
    rows: list[dict[str, str | int]] = []

    for stem, first, last, label in BLOCKS:
        payload = "".join(lines[first - 1 : last]).encode("utf-8")
        path = ROOT / f"de{stem[1:]}.tex"
        path.write_bytes(payload)
        rows.append(
            {
                "unit": stem,
                "source_first": first,
                "source_last": last,
                "source_lines": last - first + 1,
                "source_bytes": len(payload),
                "source_sha256": sha256(payload),
                "label": label,
            }
        )

    with (ROOT / "tail.csv").open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)

    print(f"pointer_id={pointer['pointer_id']}")
    print(f"authority={source}")
    print(f"authority_sha256={sha256(raw)}")
    for row in rows:
        print(
            f"{row['unit']}={row['source_first']}-{row['source_last']} "
            f"bytes={row['source_bytes']} sha256={row['source_sha256']}"
        )


if __name__ == "__main__":
    main()
