from __future__ import annotations

import csv
import difflib
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path


HERE = Path(__file__).resolve().parent
JA = HERE.parent
CJK = HERE.parents[2]
ROOT = CJK.parents[2]
CANON = ROOT / "03_projects" / "noether" / "07_german_canon_control"

BASE = (
    CJK
    / "01_recovered_witnesses"
    / "noether_cjk_chinese_japanese_cumulative_20260702"
    / "translations"
    / "non_slavic"
    / "japanese"
    / "source_fidelity"
    / "v001"
    / "Noether_Japanese_Cumulative_SourceFidelity_v001.tex"
)
CAND = JA / "noether_ja" / "reader.tex"
REPLAY = HERE / "replay" / "reader.tex"
CURRENT = HERE / "reader.tex"
POINTER = CANON / "CURRENT_GERMAN_AUTHORITY_POINTER.json"

PAPER_RE = re.compile(
    r"(?:\\section\*\{|\{\\Large\\bfseries\s+)"
    r"([1-9]|[1-3][0-9]|4[0-3])\."
)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def current_authority() -> tuple[Path, dict[str, object]]:
    pointer = json.loads(POINTER.read_text(encoding="utf-8"))
    authority = pointer["default_translation_authority"]
    path = Path(str(authority["path"]))
    raw = path.read_bytes()
    if len(raw) != int(authority["raw_bytes"]):
        raise RuntimeError("current authority byte count does not match pointer")
    if digest(raw) != str(authority["raw_sha256"]):
        raise RuntimeError("current authority SHA-256 does not match pointer")
    return path, pointer


def file_row(role: str, path: Path) -> dict[str, object]:
    data = path.read_bytes()
    return {
        "role": role,
        "path": str(path),
        "bytes": len(data),
        "sha256": digest(data),
    }


def lines(path: Path) -> list[str]:
    # TeX sources can contain control characters such as form feed inside a
    # physical line.  Python's str.splitlines() treats those characters as
    # line boundaries and therefore shifts logical LF cursors.  Normalize EOL
    # through text mode, then split on LF only.
    text = path.read_text(encoding="utf-8")
    parts = text.split("\n")
    result = [part + "\n" for part in parts[:-1]]
    if parts[-1]:
        result.append(parts[-1])
    return result


def markers(seq: list[str]) -> dict[int, int]:
    found: dict[int, int] = {}
    for index, line in enumerate(seq):
        match = PAPER_RE.search(line)
        if not match:
            continue
        paper = int(match.group(1))
        if paper not in found and (not found or paper >= max(found)):
            found[paper] = index
    special = {
        4: (r"{\Large\bfseries Zur Invariantentheorie\\", -2),
        17: (r"{\Large\bfseries Moduln in nichtkommutativen Bereichen", -10),
        18: (r"% Paper 18: source-visible conference contribution begins here.", 0),
        19: (r"{\Large\bfseries Idealtheorie in Ringbereichen.}", -4),
    }
    for paper, (needle, offset) in special.items():
        if paper in found:
            continue
        hits = [index for index, line in enumerate(seq) if needle in line]
        if len(hits) == 1:
            found[paper] = hits[0] + offset
    found = dict(sorted(found.items()))
    missing = sorted(set(range(1, 44)) - set(found))
    if missing:
        raise RuntimeError(f"missing paper markers: {missing}")
    return found


def paper_at(found: dict[int, int], index: int) -> int:
    result = 0
    for paper, start in found.items():
        if start <= index:
            result = paper
        else:
            break
    return result


def preview(block: list[str]) -> str:
    for line in block:
        clean = " ".join(line.strip().split())
        if clean:
            return clean[:180]
    return ""


def block_hash(block: list[str]) -> str:
    return digest("".join(block).encode("utf-8"))


def write_diff(old_path: Path, new_path: Path, out_path: Path) -> dict[str, object]:
    old = lines(old_path)
    new = lines(new_path)
    old_marks = markers(old)
    new_marks = markers(new)
    matcher = difflib.SequenceMatcher(None, old, new, autojunk=False)
    rows: list[dict[str, object]] = []
    paper_stats: dict[int, list[int]] = defaultdict(lambda: [0, 0, 0])
    for number, (tag, i1, i2, j1, j2) in enumerate(
        (op for op in matcher.get_opcodes() if op[0] != "equal"), start=1
    ):
        old_block = old[i1:i2]
        new_block = new[j1:j2]
        old_paper = paper_at(old_marks, min(i1, max(len(old) - 1, 0)))
        new_paper = paper_at(new_marks, min(j1, max(len(new) - 1, 0)))
        paper = new_paper or old_paper
        paper_stats[paper][0] += 1
        paper_stats[paper][1] += i2 - i1
        paper_stats[paper][2] += j2 - j1
        rows.append(
            {
                "hunk": number,
                "tag": tag,
                "paper_old": old_paper,
                "old_start_1": i1 + 1,
                "old_end_exclusive_1": i2 + 1,
                "old_lines": i2 - i1,
                "old_sha256": block_hash(old_block),
                "paper_new": new_paper,
                "new_start_1": j1 + 1,
                "new_end_exclusive_1": j2 + 1,
                "new_lines": j2 - j1,
                "new_sha256": block_hash(new_block),
                "old_preview": preview(old_block),
                "new_preview": preview(new_block),
            }
        )
    with out_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return {
        "old": str(old_path),
        "new": str(new_path),
        "hunks": len(rows),
        "deleted_lines": sum(int(row["old_lines"]) for row in rows),
        "inserted_lines": sum(int(row["new_lines"]) for row in rows),
        "sequence_ratio": matcher.ratio(),
        "by_paper": {
            str(paper): {
                "hunks": values[0],
                "old_lines": values[1],
                "new_lines": values[2],
            }
            for paper, values in sorted(paper_stats.items())
        },
    }


def paper_spans(path: Path) -> dict[int, dict[str, object]]:
    seq = lines(path)
    found = markers(seq)
    starts = {0: 0, **found}
    ordered = sorted(starts)
    result: dict[int, dict[str, object]] = {}
    for pos, paper in enumerate(ordered):
        start = starts[paper]
        end = starts[ordered[pos + 1]] if pos + 1 < len(ordered) else len(seq)
        block = seq[start:end]
        data = "".join(block).encode("utf-8")
        result[paper] = {
            "start_1": start + 1,
            "end_exclusive_1": end + 1,
            "lines": end - start,
            "bytes": len(data),
            "sha256": digest(data),
        }
    return result


def write_papers() -> None:
    editions = {
        "baseline": BASE,
        "candidate": CAND,
        "current": CURRENT,
    }
    spans = {name: paper_spans(path) for name, path in editions.items()}
    fields = ["paper"]
    for name in editions:
        fields.extend(
            [
                f"{name}_start_1",
                f"{name}_end_exclusive_1",
                f"{name}_lines",
                f"{name}_bytes",
                f"{name}_sha256",
            ]
        )
    with (HERE / "papers.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for paper in range(0, 44):
            row: dict[str, object] = {"paper": paper}
            for name in editions:
                for key, value in spans[name][paper].items():
                    row[f"{name}_{key}"] = value
            writer.writerow(row)


def structure(block: list[str]) -> dict[str, int]:
    text = "".join(block)
    return {
        "headings": len(re.findall(r"\\(?:section|subsection)\*|\\paragraph", text)),
        "notes": len(
            re.findall(r"\\(?:srcfn|srcfntext|footnote|footnotetext)\b", text)
        ),
        "displays": text.count("\\[")
        + len(
            re.findall(
                r"\\begin\{(?:equation\*?|align\*?|gather\*?|multline\*?|displaymath)\}",
                text,
            )
        ),
    }


def write_manifest(source_path: Path) -> None:
    source = lines(source_path)
    target = lines(CURRENT)
    source_marks = markers(source)
    target_marks = markers(target)
    source_starts = {0: 0, **source_marks}
    target_starts = {0: 0, **target_marks}
    fields = [
        "paper",
        "source_start_1",
        "source_end_exclusive_1",
        "source_lines",
        "source_bytes",
        "source_sha256",
        "source_headings",
        "source_notes",
        "source_displays",
        "target_start_1",
        "target_end_exclusive_1",
        "target_lines",
        "target_bytes",
        "target_sha256",
        "target_headings",
        "target_notes",
        "target_displays",
        "state",
    ]
    with (HERE / "manifest.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for paper in range(1, 44):
            source_start = source_starts[paper]
            source_end = (
                source_starts[paper + 1] if paper < 43 else len(source)
            )
            target_start = target_starts[paper]
            target_end = (
                target_starts[paper + 1] if paper < 43 else len(target)
            )
            source_block = source[source_start:source_end]
            target_block = target[target_start:target_end]
            source_data = "".join(source_block).encode("utf-8")
            target_data = "".join(target_block).encode("utf-8")
            source_counts = structure(source_block)
            target_counts = structure(target_block)
            writer.writerow(
                {
                    "paper": paper,
                    "source_start_1": source_start + 1,
                    "source_end_exclusive_1": source_end + 1,
                    "source_lines": source_end - source_start,
                    "source_bytes": len(source_data),
                    "source_sha256": digest(source_data),
                    "source_headings": source_counts["headings"],
                    "source_notes": source_counts["notes"],
                    "source_displays": source_counts["displays"],
                    "target_start_1": target_start + 1,
                    "target_end_exclusive_1": target_end + 1,
                    "target_lines": target_end - target_start,
                    "target_bytes": len(target_data),
                    "target_sha256": digest(target_data),
                    "target_headings": target_counts["headings"],
                    "target_notes": target_counts["notes"],
                    "target_displays": target_counts["displays"],
                    "state": "producer_bound_not_independently_checked",
                }
            )


def write_hashes() -> None:
    baseline_pdf = (
        CJK
        / "01_recovered_witnesses"
        / "noether_cjk_chinese_japanese_cumulative_20260702"
        / "renders"
        / "non_slavic"
        / "japanese_papers40_43_resync_20260629"
        / "Noether_Japanese_Cumulative_SourceFidelity_v001_localfont.pdf"
    )
    inputs = [
        ("baseline_tex", BASE),
        ("baseline_pdf", baseline_pdf),
        ("candidate_tex", CAND),
        ("candidate_pdf", JA / "noether_ja" / "output" / "pdf" / "reader.pdf"),
        ("assembly_original", JA / "noether_ja" / "assemble.ps1"),
        ("assembly_replay", HERE / "replay.ps1"),
        ("replay_tex", REPLAY),
        ("authority_pointer_v012", CANON / "pointers" / "v012.json"),
        ("authority_pointer_current", CANON / "CURRENT_GERMAN_AUTHORITY_POINTER.json"),
        ("authority_pointer_v032", CANON / "pointers" / "v032.json"),
        ("authority_pointer_v033", CANON / "pointers" / "v033.json"),
        ("authority_ed0002", CANON / "candidates" / "ED0002" / "noether.tex"),
        ("authority_ed0003", CANON / "candidates" / "ED0003" / "noether.tex"),
        ("authority_ed0004", CANON / "candidates" / "ED0004" / "noether.tex"),
        ("authority_ed0005", CANON / "candidates" / "ED0005" / "noether.tex"),
        (
            "input_p21",
            JA
            / "noether_paper21_ja_reconciliation_20260718"
            / "Noether_Paper21_Japanese_SourceReconciled_v001.tex",
        ),
        (
            "input_p22",
            JA
            / "noether_paper22_ja_reconciliation_20260718"
            / "Noether_Paper22_Japanese_SourceReconciled_v001.tex",
        ),
        (
            "input_p23",
            JA
            / "noether_paper23_ja_reconciliation_20260718"
            / "Noether_Paper23_Japanese_SourceReconciled_v001.tex",
        ),
        (
            "input_p24",
            JA
            / "noether_paper24_ja_reconciliation_20260718"
            / "Noether_Paper24_Japanese_SourceReconciled_v001.tex",
        ),
        (
            "input_p25",
            JA
            / "noether_paper25_ja_reconciliation_20260718"
            / "Noether_Paper25_Japanese_SourceReconciled_v001.tex",
        ),
        (
            "input_p26",
            CJK
            / "03_working_translations"
            / "noether_paper26_cjk_tranche_002_20260717"
            / "ja"
            / "Noether_Paper26_Japanese_SourceReconciled_v001.tex",
        ),
        (
            "input_p27",
            JA
            / "noether_paper27_ja_reconciliation_20260718"
            / "Noether_Paper27_Japanese_SourceReconciled_v001.tex",
        ),
        (
            "input_p28",
            CJK
            / "03_working_translations"
            / "noether_paper28_cjk_tranche_003_20260718"
            / "ja"
            / "Noether_Paper28_Japanese_SourceReconciled_v001.tex",
        ),
        ("input_p31", JA / "noether_paper31_ja_reconciliation_20260722" / "P31_JA.tex"),
        (
            "input_p36",
            CJK
            / "03_working_translations"
            / "noether_paper36_cjk_tranche_001_20260717"
            / "ja"
            / "Noether_Paper36_Japanese_SourceReconciled_v001.tex",
        ),
        ("input_p43", JA / "noether_ja" / "p43_src.tex"),
        ("current_tex", CURRENT),
        ("current_pdf", HERE / "reader.pdf"),
        ("build_log", HERE / "build" / "reader.log"),
    ]
    rows = [file_row(role, path) for role, path in inputs]
    with (HERE / "hashes.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    authority, pointer = current_authority()
    if CAND.read_bytes() != REPLAY.read_bytes():
        raise RuntimeError("candidate does not equal independent replay")
    baseline_candidate = write_diff(BASE, CAND, HERE / "diff.csv")
    candidate_current = write_diff(CAND, CURRENT, HERE / "delta.csv")
    source_delta = write_diff(
        CANON / "candidates" / "ED0003" / "noether.tex",
        CANON / "candidates" / "ED0004" / "noether.tex",
        HERE / "source.csv",
    )
    source_delta_5 = write_diff(
        CANON / "candidates" / "ED0004" / "noether.tex",
        CANON / "candidates" / "ED0005" / "noether.tex",
        HERE / "source5.csv",
    )
    write_papers()
    write_manifest(authority)
    write_hashes()
    summary = {
        "schema": "ja-noether-rebase-intake/1.0",
        "baseline_candidate": baseline_candidate,
        "candidate_current": candidate_current,
        "source_ed0003_ed0004": source_delta,
        "source_ed0004_ed0005": source_delta_5,
        "current_pointer_id": pointer["pointer_id"],
        "current_pointer_sha256": digest(POINTER.read_bytes()),
        "current_authority": str(authority),
        "current_authority_sha256": digest(authority.read_bytes()),
        "candidate_equals_replay": True,
        "candidate_sha256": digest(CAND.read_bytes()),
        "replay_sha256": digest(REPLAY.read_bytes()),
        "current_sha256": digest(CURRENT.read_bytes()),
    }
    (HERE / "diff.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
