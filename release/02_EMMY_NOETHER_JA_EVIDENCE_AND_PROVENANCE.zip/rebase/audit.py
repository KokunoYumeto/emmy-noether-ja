from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
CANON = HERE.parents[4] / "noether" / "07_german_canon_control"
POINTER = CANON / "CURRENT_GERMAN_AUTHORITY_POINTER.json"

SOURCE_BINDINGS = {
    "front": (1, 381),
    "papers_01_42": (382, 20176),
    "paper_43_numbered": (20177, 20984),
    "paper43_post_gap": (20985, 20987),
    "post_wrapper": (20988, 21004),
    "deuring_lecture": (21005, 23740),
    "kapferer_and_noether": (23741, 23983),
    "bibliography_and_lists": (23984, 24145),
    "document_close": (24146, 24146),
    "p06_hstar_1": (5101, 5101),
    "p06_hstar_2": (5105, 5105),
    "p06_exponents": (5383, 5383),
    "p31_footnote": (16017, 16017),
}

TARGET_ROOT_BINDINGS = {
    "front": (1, 282),
    "papers_01_42": (283, 19265),
    "paper_43_numbered": (19266, 20075),
    "paper43_post_gap": (20076, 20077),
    "document_close": (20172, 20172),
    "p06_hstar_1": (4900, 4900),
    "p06_hstar_2": (4907, 4907),
    "p06_exponents": (5203, 5203),
    "p31_footnote": (14972, 14972),
    "ra10": (20087, 20170),
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def lf_lines(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8")
    parts = text.split("\n")
    result = [part + "\n" for part in parts[:-1]]
    if parts[-1]:
        result.append(parts[-1])
    return result


def raw_lf_lines(path: Path) -> list[bytes]:
    raw = path.read_bytes()
    parts = raw.split(b"\n")
    result = [part + b"\n" for part in parts[:-1]]
    if parts[-1]:
        result.append(parts[-1])
    return result


def span(seq: list[str], first: int, last: int) -> bytes:
    return "".join(seq[first - 1 : last]).encode("utf-8")


def csv_rows(name: str, key: str) -> dict[str, dict[str, str]]:
    with (HERE / name).open(encoding="utf-8", newline="") as handle:
        return {row[key]: row for row in csv.DictReader(handle)}


def editable_set_sha() -> str:
    names = ["reader.tex", *(f"t{i}.tex" for i in range(8))]
    payload = "".join(
        f"{name}|{sha256((HERE / name).read_bytes())}\n" for name in names
    ).encode("utf-8")
    return sha256(payload)


def check_binding(
    unit: str,
    data: bytes,
    row: dict[str, str],
    prefix: str,
) -> dict[str, object] | None:
    expected_bytes = row[f"{prefix}_lf_bytes"]
    expected_sha = row[f"{prefix}_lf_sha256"]
    actual_sha = sha256(data)
    if expected_bytes and len(data) != int(expected_bytes):
        return {
            "unit": unit,
            "reason": "bytes",
            "expected": int(expected_bytes),
            "actual": len(data),
        }
    if expected_sha and actual_sha != expected_sha:
        return {
            "unit": unit,
            "reason": "sha256",
            "expected": expected_sha,
            "actual": actual_sha,
        }
    return None


def main() -> None:
    pointer_raw = POINTER.read_bytes()
    pointer = json.loads(pointer_raw.decode("utf-8"))
    authority = pointer["default_translation_authority"]
    source_path = Path(str(authority["path"]))
    source_raw = source_path.read_bytes()
    source = lf_lines(source_path)
    target_path = HERE / "reader.tex"
    target = lf_lines(target_path)
    cursor = csv_rows("cursor3.csv", "unit")
    freeze = csv_rows("freeze3.csv", "role")

    source_failures: list[dict[str, object]] = []
    for unit, (first, last) in SOURCE_BINDINGS.items():
        failure = check_binding(unit, span(source, first, last), cursor[unit], "source")
        if failure:
            source_failures.append(failure)

    target_failures: list[dict[str, object]] = []
    for unit, (first, last) in TARGET_ROOT_BINDINGS.items():
        failure = check_binding(unit, span(target, first, last), cursor[unit], "target")
        if failure:
            target_failures.append(failure)

    components = {f"t{i}": lf_lines(HERE / f"t{i}.tex") for i in range(8)}
    composites = {
        "post_wrapper": span(components["t0"], 1, 20),
        "deuring_lecture": (
            "".join(components["t0"][20:])
            + "".join(
                line
                for index in range(1, 6)
                for line in components[f"t{index}"]
            )
        ).encode("utf-8"),
        "kapferer_and_noether": "".join(components["t6"]).encode("utf-8"),
        "bibliography_and_lists": "".join(components["t7"]).encode("utf-8"),
    }
    for unit, data in composites.items():
        failure = check_binding(unit, data, cursor[unit], "target")
        if failure:
            target_failures.append(failure)

    manifest_failures: list[dict[str, object]] = []
    with (HERE / "manifest.csv").open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            paper = row["paper"]
            for kind, seq in (("source", source), ("target", target)):
                first = int(row[f"{kind}_start_1"])
                last = int(row[f"{kind}_end_exclusive_1"]) - 1
                data = span(seq, first, last)
                actual = sha256(data)
                if len(data) != int(row[f"{kind}_bytes"]) or actual != row[f"{kind}_sha256"]:
                    manifest_failures.append(
                        {
                            "paper": paper,
                            "kind": kind,
                            "actual_bytes": len(data),
                            "actual_sha256": actual,
                        }
                    )

    tail_failures: list[dict[str, object]] = []
    raw_source = raw_lf_lines(source_path)
    with (HERE / "tail.csv").open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            first = int(row["source_first"])
            last = int(row["source_last"])
            data = b"".join(raw_source[first - 1 : last])
            if len(data) != int(row["source_bytes"]) or sha256(data) != row["source_sha256"]:
                tail_failures.append(
                    {
                        "unit": row["unit"],
                        "actual_bytes": len(data),
                        "actual_sha256": sha256(data),
                    }
                )

    frozen_file_failures: list[dict[str, object]] = []
    for role in ["target_root", *(f"target_t{i}" for i in range(8)), "target_pdf", "build_log"]:
        row = freeze[role]
        path = HERE / row["path"]
        raw = path.read_bytes()
        if len(raw) != int(row["bytes"]) or sha256(raw) != row["sha256"]:
            frozen_file_failures.append(
                {"role": role, "actual_bytes": len(raw), "actual_sha256": sha256(raw)}
            )

    expected_set = freeze["editable_set"]["sha256"]
    actual_set = editable_set_sha()
    expected_authority = freeze["authority_body"]["sha256"]
    report = {
        "schema": "ja-noether-personal-audit/1.0",
        "pointer_id": pointer["pointer_id"],
        "pointer_bytes": len(pointer_raw),
        "pointer_sha256": sha256(pointer_raw),
        "frozen_pointer_sha256": freeze["authority_pointer_current"]["sha256"],
        "authority_id": authority["authority_id"],
        "authority_path": str(source_path),
        "authority_bytes": len(source_raw),
        "authority_sha256": sha256(source_raw),
        "authority_physical_lf_lines": len(source),
        "pointer_body_declaration_matches": (
            len(source_raw) == int(authority["raw_bytes"])
            and sha256(source_raw) == str(authority["raw_sha256"])
        ),
        "authority_matches_frozen_body": sha256(source_raw) == expected_authority,
        "source_binding_failures": source_failures,
        "target_binding_failures": target_failures,
        "paper_manifest_failures": manifest_failures,
        "tail_binding_failures": tail_failures,
        "frozen_file_failures": frozen_file_failures,
        "editable_set_sha256": actual_set,
        "editable_set_matches_frozen": actual_set == expected_set,
    }
    report["mechanically_clean"] = all(
        [
            report["pointer_body_declaration_matches"],
            report["authority_matches_frozen_body"],
            not source_failures,
            not target_failures,
            not manifest_failures,
            not tail_failures,
            not frozen_file_failures,
            report["editable_set_matches_frozen"],
        ]
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
