# JA-NOETH-R09-ED11-20260812 — static producer successor

Successor root: `reader.tex`, 1,930,190 bytes / SHA-256 `97414B06A835F105E46817208EC178A083C0C934A09DF38ECB12472F805A2049`. Editable set: 2,134,761 bytes / SHA-256 `DAAEEAD7CEE147EE806B9F80EE3791E556DD5B44499EF856E784DC497E2E8D66`.

Inherited base: exact frozen r08 root `2BF635B2F9B5DD2D9E8D706F27CF7465AB20DF042677663B23A346CA279767DC`; editable set `A7C1CA1218E83C290B4882C5ED9D817F7C1DEE555C96F999289AD7AE46F6DEEF`; PDF `5399229D7D97CC273EE0A0743E1435D095E5035BEE485BD380FC0678FCD81316`; manifest `F936DA75B698BC3718816D9CB653352B951F399DB0DB9926F3EC712CB962BF5E`; freeze `C6C9E9C051547129E088E48B8E75939DE680A54C8B08A6FD945891D146A22FB9`; pack `C38AB87E21237006E77B020DA03E632FA12878881C4B346C343B0DC3378A88F2`.

Authority: pointer v047 / `0053EA0B7E44DDE7EA7DC285ABC115DFC43F4A74B34C54DE8F39DE4E445D5BEA`; ED0011 / `9E6BF2BC3155ECE3DF98CD8A408C23662BEFB047A1DDF200CA1DC8476A488BF3` / 24,146 lines. Controlling return: `ja_r08.csv` / `1AA2F21489C249614FE69DAAB927AEA4CC3D54BDA813DDAA8C16C1F80FCA4A21` and `ja_r08.md` / `98BF064478AAD157899CBD388F0A399DC779F056FDB51C92E6D483EBE9E153EC`.

r09 implements exactly the 18 returned target findings across P02, P04, P09, P17, P30, P34, and P35. `chg.csv` records every exact old/new locus and append-corrects all seven inherited r06-to-r07 P19/P30 loci required by `JA-R08-PROV-001`. The 73 note-map target cursors advance by exactly 19 lines. `t0.tex` through `t7.tex` remain byte-identical to r08.

Two fixed-epoch serial XeLaTeX passes on final input exited zero and produced byte-identical PDFs. Mechanical PDF: 2,939,216 bytes / 421 pages / `B58E83BDD122FFFE1A3C97097C93D2F23810955AA7C44594E512C3A26349B8C4`. Final log: `2CAAFD12C1A5FF039371BF8F243891239E5AF7D41C64B7C0551D3DE71ED34CBB`.

The invalid `JA-GATE-0010` claim is append-retracted; target change resets the valid gate to 0/3. The external automation was deleted. `CJK-NOETH-EXT-SYS-001` remains open under the explicit cross-lane exception; no extraction-clean claim is made.

This is a producer return for independent checking. Mechanical compilation is not source-fidelity, Japanese-language, formula, apparatus, extraction, rendered-page, or certification approval. SGA remains held; nothing is publishable.
