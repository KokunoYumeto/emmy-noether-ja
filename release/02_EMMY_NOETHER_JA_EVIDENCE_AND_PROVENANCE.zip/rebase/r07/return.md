# JA-NOETH-R07-ED10-20260808 — static producer successor

Successor root: `reader.tex`, 1,927,243 bytes, SHA-256 `F51C64849E1BCB328AD3A84C64365EA6BA94C67197DC6E968F3B896B6DB660C0`. Editable-set SHA-256: `1EB642A19AF47028B9C38D1221F7F969D29452D2E2089267FEB935F48DE93AA9`.

Inherited base: exact frozen r06 root `ED18512FA4E52612E6C8E467E9051FC9F35AD1C1BFCF3C043D303F78A07FD9FA`; editable set `83E007650DF313CE0BE9E62EC06541C2ED47B1C49704B61FA000AEA3FC88451B`; PDF `1985EBEAE818D6DE2C20069B03BC0FD5272A2C263D901BF9B15A41C4D304F08F`; freeze `F9C1F32C900DEC43019EBAA3F597AB9304E55A6D1430A8C7ED8144F7EF76B63A`. Authority: pointer v046 / `A6BBCB8FF09FB3E2FCA8DD717E44BB6AECF93680D5819C2F00954E41EBE0AF7D`; ED0010 / `1AF3252486AC99399F95E21E4447D79C1D1206A050D26A91FE068499EE0D4563` / 24,146 lines.

The consolidated 28-row `ja_r06.csv` return is represented one-for-one in `chg.csv`. The bounded production changes cover systemic P02/P19 proof-formula restoration; returned P02/P08/P13/P15/P17/P30/P31/P34/P35/P40/P41 omissions, formulas, semantics, structure, and residues; and exactly the requested ten-note RA10 batch. `notes.csv` preserves all 73 source-note identities and advances only the target cursors required by the insertions. `t0.tex` through `t7.tex` are byte-identical to r06.

`CJK-NOETH-EXT-SYS-001` remains open under the explicit cross-lane exception in `xext.csv`: classic math subsets still lack ToUnicode, so no extraction-accessibility clean claim is made. A shared font/CMap remedy is deferred to cross-lane build governance.

Three fixed-epoch serial XeLaTeX passes exited zero; pass-two and pass-three PDFs are byte-identical. Mechanical PDF: 2,935,079 bytes / 421 pages / SHA-256 `5E91E7F0D1C8761937EC180B8B0912E87F62DC620A4F05175E3294C5909C8C50`. Final log: `5A8429FA785D8D3D777C689CE991B309364E0732279580CFB8333E2928354D15`.

This producer successor resets the three-day gate to 0/3 on 2026-08-08. Mechanical compilation is not source-fidelity, Japanese-language, formula, apparatus, extraction, rendered-page, or certification approval. SGA remains held; nothing is publishable.
