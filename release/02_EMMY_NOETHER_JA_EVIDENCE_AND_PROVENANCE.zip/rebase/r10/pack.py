from __future__ import annotations

import csv
import hashlib
import importlib.util
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
REBASE = HERE.parent
R09 = REBASE / "r09"
R08 = REBASE / "r08"
R07 = REBASE / "r07"
R06 = REBASE / "r06"
R05 = REBASE / "r05"
R04 = REBASE / "r04"
R03 = REBASE
ROOT = HERE.parents[6]
CANON = ROOT / "03_projects" / "noether" / "07_german_canon_control"
POINTER = CANON / "CURRENT_GERMAN_AUTHORITY_POINTER.json"

EXPECTED_POINTER_ID = "NOETH-DE-AUTH-v051-20260811"
EXPECTED_POINTER_SHA = "2B36556DCF123F19281AB6BF36CE6E46BEE8ADDBF37DA682032372306564D0DE"
EXPECTED_AUTHORITY_SHA = "EE226847656BC4D65EDDA9E9BF9BB1D25797C0C6D672D267D94A97FD88C7AD58"
EXPECTED_AUTHORITY_ASSET = "B2AF3955A8255B4A6D925E174B7B81311C64C669CE21B07E75002494E55F2FF5"
EXPECTED_R03_ROOT = "6D8A36F22F44052C7209DA9414EFFF31C78F7B6E29A11733D403776BBA5D4130"
EXPECTED_R03_SET = "AC0ABE6B7DB5989ED156AA7902096511A350DC0C47ACB4A37B06A225382D9FB7"
EXPECTED_R03_PDF = "19E7C42FF11ECF32B6753812E3F279262A4AACC321BF78B40F6CB92F99861B53"
EXPECTED_R04_FREEZE = "A37E6C40514BA9E30A0D4C375DF00ECB272FF894E88F9CEBE4E3A9562F1F5BBA"
EXPECTED_R04_ROOT = "2E2A927B1B498587A5F380E4307F9CB58BE32285969C0E625015B7528E9A56FE"
EXPECTED_R04_SET = "F144CD3845F9BCEF5527A035B941A71B5EA2417D3F1C1E1EA3601B4CFA8B34AF"
EXPECTED_R04_PDF = "9B19F92C8DE034826FD181826F48AFC53A8094773C35C8BBD9AB0B7E868042E5"
EXPECTED_R05_PACK = "23AF639ED3F912EA59CA4C79CDE3E67952E6FAE5ECFFF0C66BEA84196AA9683B"
EXPECTED_R05_FREEZE = "CCE6286F517CC59C8189D87AEB801E29D66C8B39466B049EF060B9A57098A1A0"
EXPECTED_R05_ROOT = "9B3C37E0C91E7BF924B5F6738BF97CDD4AA62DC806DD5BCE0D8904931E3E6F87"
EXPECTED_R05_SET = "E4BB1BE344A7A6FA2D4515959A01F5D462ACB330E82390B6ABABA57E9B7D51BA"
EXPECTED_R05_PDF = "EAAC3E49289D52A249F6C5BAC3BCEACD0B40701957B5DD605A48D048FFAE7F5A"
EXPECTED_R06_ROOT = "ED18512FA4E52612E6C8E467E9051FC9F35AD1C1BFCF3C043D303F78A07FD9FA"
EXPECTED_R06_SET = "83E007650DF313CE0BE9E62EC06541C2ED47B1C49704B61FA000AEA3FC88451B"
EXPECTED_R06_PDF = "1985EBEAE818D6DE2C20069B03BC0FD5272A2C263D901BF9B15A41C4D304F08F"
EXPECTED_R06_LOG = "FEE675C4C6843C1015655759AAE93843099C89EC506140E2DD00136DF838A8B0"
EXPECTED_R06_PACK = "8892CB20A16E0E82D9EF7E754A23B7EDCB6BBBB9DDE6C5C24F949AD1F0AA7E1E"
EXPECTED_R06_FREEZE = "F9C1F32C900DEC43019EBAA3F597AB9304E55A6D1430A8C7ED8144F7EF76B63A"
EXPECTED_R07_ROOT = "F51C64849E1BCB328AD3A84C64365EA6BA94C67197DC6E968F3B896B6DB660C0"
EXPECTED_R07_SET = "1EB642A19AF47028B9C38D1221F7F969D29452D2E2089267FEB935F48DE93AA9"
EXPECTED_R07_PDF = "5E91E7F0D1C8761937EC180B8B0912E87F62DC620A4F05175E3294C5909C8C50"
EXPECTED_R07_LOG = "5A8429FA785D8D3D777C689CE991B309364E0732279580CFB8333E2928354D15"
EXPECTED_R07_PACK = "F85B40F57C2DE54756BBE1EEED634F4FC8C113E447A0DF9E46BE212A3BFE5A13"
EXPECTED_R07_FREEZE = "DDEC649AF697C9D1200CA736FC99EE172C2E473FD774BAE751EAB2E692979186"
EXPECTED_R08_ROOT = "2BF635B2F9B5DD2D9E8D706F27CF7465AB20DF042677663B23A346CA279767DC"
EXPECTED_R08_SET = "A7C1CA1218E83C290B4882C5ED9D817F7C1DEE555C96F999289AD7AE46F6DEEF"
EXPECTED_R08_PDF = "5399229D7D97CC273EE0A0743E1435D095E5035BEE485BD380FC0678FCD81316"
EXPECTED_R08_LOG = "5A8429FA785D8D3D777C689CE991B309364E0732279580CFB8333E2928354D15"
EXPECTED_R08_PACK = "C38AB87E21237006E77B020DA03E632FA12878881C4B346C343B0DC3378A88F2"
EXPECTED_R08_FREEZE = "C6C9E9C051547129E088E48B8E75939DE680A54C8B08A6FD945891D146A22FB9"
EXPECTED_R08_MANIFEST = "F936DA75B698BC3718816D9CB653352B951F399DB0DB9926F3EC712CB962BF5E"
EXPECTED_R09_ROOT = "97414B06A835F105E46817208EC178A083C0C934A09DF38ECB12472F805A2049"
EXPECTED_R09_SET = "DAAEEAD7CEE147EE806B9F80EE3791E556DD5B44499EF856E784DC497E2E8D66"
EXPECTED_R09_PDF = "B58E83BDD122FFFE1A3C97097C93D2F23810955AA7C44594E512C3A26349B8C4"
EXPECTED_R09_LOG = "2CAAFD12C1A5FF039371BF8F243891239E5AF7D41C64B7C0551D3DE71ED34CBB"
EXPECTED_R09_PACK = "84E0E655CA219DFDA6A49968A1C1254037DBE14BEB0C80C23D1E8497DA170126"
EXPECTED_R09_FREEZE = "5ED904A4623F0EF5EAE914A25EC3525CD52BCC915273EADB855EF47AFBE38035"
EXPECTED_R09_MANIFEST = "D37DFD023709D3B9E7E4E2B9191E7BA313E42F5606C952F37BF699501E079BEB"
EXPECTED_R06_CHG = "E64030917C4CD23527736C0B4A55AAEE922A1E994B2981D9A49F830103EF9C1A"
EXPECTED_R07_CHG = "6A21626FA590B0D30B694F1AD9FF3F12A6CAB6715EAA8383121D6CF53BAC9F8C"
EXPECTED_CHECK_CSV = "1AA2F21489C249614FE69DAAB927AEA4CC3D54BDA813DDAA8C16C1F80FCA4A21"
EXPECTED_CHECK_MD = "98BF064478AAD157899CBD388F0A399DC779F056FDB51C92E6D483EBE9E153EC"
EXPECTED_EXT_CSV = "2F3738E2AABD7B585D474F8767F112E3D9D23AAECF2B8D66D85551F18FF00F31"
EXPECTED_EXT_MD = "6A48E98B660A308E164DDE821093AE640ED5F95AE466E9D39E8ED96472792887"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def assert_hash(path: Path, expected: str) -> None:
    actual = digest(path.read_bytes())
    if actual != expected:
        raise RuntimeError(f"identity changed: {path}: {actual} != {expected}")


def set_identity(directory: Path) -> tuple[int, str]:
    names = ["reader.tex", *(f"t{i}.tex" for i in range(8))]
    payload = "".join(
        f"{name}|{digest((directory / name).read_bytes())}\n" for name in names
    ).encode("utf-8")
    return sum((directory / name).stat().st_size for name in names), digest(payload)


def file_row(role: str, path: Path, shown: str, note: str) -> dict[str, object]:
    data = path.read_bytes()
    return {
        "role": role,
        "path": shown,
        "present": "true",
        "bytes": len(data),
        "sha256": digest(data),
        "note": note,
    }


def identity_row(role: str, path: str, size: int, sha: str, note: str) -> dict[str, object]:
    return {
        "role": role,
        "path": path,
        "present": "false",
        "bytes": size,
        "sha256": sha,
        "note": note,
    }


def set_row(role: str, directory: Path, shown: str, note: str) -> dict[str, object]:
    size, sha = set_identity(directory)
    return {
        "role": role,
        "path": shown,
        "present": "true",
        "bytes": size,
        "sha256": sha,
        "note": note,
    }


def load_manifest_generator():
    assert_hash(R08 / "pack.py", EXPECTED_R08_PACK)
    spec = importlib.util.spec_from_file_location("ja_noether_r08_pack", R08 / "pack.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load inherited r08 generator")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.HERE = HERE
    return module.load_manifest_generator()


def write_manifest(authority: Path) -> None:
    generator = load_manifest_generator()
    root = HERE / "reader.tex"
    source_marks = generator.markers(authority)
    target_marks = generator.markers(root)
    if source_marks[43] != 20177:
        raise RuntimeError("ED0014 P43 start cursor changed")

    target_line_count = len(generator.raw_lines(root))
    document_close = target_line_count
    pre_close_blank = document_close - 1
    ra_first, ra_last = document_close - 37, document_close - 2
    post_inputs_first, post_inputs_last = ra_first - 9, ra_first - 1
    post_gap_first, post_gap_last = post_inputs_first - 2, post_inputs_first - 1
    p43_first, p43_last = target_marks[43], post_gap_first - 1
    decoded = [line.decode("utf-8").rstrip("\r\n") for line in generator.raw_lines(root)]
    if decoded[document_close - 1] != r"\end{document}":
        raise RuntimeError("target document close changed")
    if not decoded[ra_first - 1].startswith(r"\section*{RA10"):
        raise RuntimeError("RA10 start cursor could not be derived")
    if [decoded[index - 1] for index in range(post_inputs_first, post_inputs_last)] != [
        rf"\input{{t{index}}}" for index in range(8)
    ]:
        raise RuntimeError("post-P43 input binding block changed")

    rows: list[dict[str, object]] = []
    state = "producer_bound_not_independently_approved"
    rows.append(
        generator.manifest_row(
            "front", "ED0014/noether.tex", "1-381",
            generator.slice_stats(authority, 1, 381),
            "reader.tex", "1-282", generator.slice_stats(root, 1, 282), state,
        )
    )
    for paper in range(1, 43):
        sf, sl = source_marks[paper], source_marks[paper + 1] - 1
        tf, tl = target_marks[paper], target_marks[paper + 1] - 1
        rows.append(
            generator.manifest_row(
                f"P{paper:02d}", "ED0014/noether.tex", f"{sf}-{sl}",
                generator.slice_stats(authority, sf, sl),
                "reader.tex", f"{tf}-{tl}", generator.slice_stats(root, tf, tl), state,
            )
        )
    rows.append(
        generator.manifest_row(
            "P43", "ED0014/noether.tex", "20177-20984",
            generator.slice_stats(authority, 20177, 20984),
            "reader.tex", f"{p43_first}-{p43_last}",
            generator.slice_stats(root, p43_first, p43_last), state,
        )
    )
    rows.append(
        generator.manifest_row(
            "post_gap", "ED0014/noether.tex", "20985-20987",
            generator.slice_stats(authority, 20985, 20987),
            "reader.tex", f"{post_gap_first}-{post_gap_last}",
            generator.slice_stats(root, post_gap_first, post_gap_last),
            "structural_boundary_plus_binding_comment",
        )
    )
    rows.append(
        generator.manifest_row(
            "post_inputs", "", "target-only input bindings", None,
            "reader.tex", f"{post_inputs_first}-{post_inputs_last}",
            generator.slice_stats(root, post_inputs_first, post_inputs_last),
            "target_structure_not_additional_source_coverage",
        )
    )

    post = [
        ("post_wrapper", 20988, 21004, "t0.tex", 1, 20),
        ("t0_body", 21005, 21275, "t0.tex", 21, 297),
        ("t1", 21276, 21565, "t1.tex", 1, len(generator.raw_lines(HERE / "t1.tex"))),
        ("t2", 21566, 21811, "t2.tex", 1, len(generator.raw_lines(HERE / "t2.tex"))),
        ("t3", 21812, 22366, "t3.tex", 1, len(generator.raw_lines(HERE / "t3.tex"))),
        ("t4", 22367, 23343, "t4.tex", 1, len(generator.raw_lines(HERE / "t4.tex"))),
        ("t5", 23344, 23740, "t5.tex", 1, len(generator.raw_lines(HERE / "t5.tex"))),
        ("t6", 23741, 23983, "t6.tex", 1, len(generator.raw_lines(HERE / "t6.tex"))),
        ("t7", 23984, 24145, "t7.tex", 1, len(generator.raw_lines(HERE / "t7.tex"))),
    ]
    for unit, sf, sl, target_name, tf, tl in post:
        rows.append(
            generator.manifest_row(
                unit, "ED0014/noether.tex", f"{sf}-{sl}",
                generator.slice_stats(authority, sf, sl),
                target_name, f"{tf}-{tl}",
                generator.slice_stats(HERE / target_name, tf, tl), state,
            )
        )

    note_lines = generator.raw_lines(HERE / "notes.csv")
    ra_note_lines = [line for line in note_lines[1:] if b",RA10," in line]
    if len(ra_note_lines) != 26:
        raise RuntimeError(f"expected 26 RA note-map rows, got {len(ra_note_lines)}")
    rows.append(
        generator.manifest_row(
            "RA10", "notes.csv", "placement=RA10; 26 unique source-note rows",
            generator.data_stats(b"".join(ra_note_lines), 26),
            "reader.tex", f"{ra_first}-{ra_last}",
            generator.slice_stats(root, ra_first, ra_last),
            "derived_apparatus_no_additional_source_coverage",
        )
    )
    rows.append(
        generator.manifest_row(
            "pre_close_blank", "", "target-only separator", None,
            "reader.tex", str(pre_close_blank),
            generator.slice_stats(root, pre_close_blank, pre_close_blank),
            "target_structure_not_additional_source_coverage",
        )
    )
    rows.append(
        generator.manifest_row(
            "document_close", "ED0014/noether.tex", "24146",
            generator.slice_stats(authority, 24146, 24146),
            "reader.tex", str(document_close),
            generator.slice_stats(root, document_close, document_close),
            "exact_structural_close",
        )
    )

    fields = [
        "unit", "source_path", "source_locus", "source_lines", "source_bytes",
        "source_sha256", "target_path", "target_locus", "target_lines",
        "target_bytes", "target_sha256", "state",
    ]
    with (HERE / "manifest.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def validate_inputs(pointer: dict[str, object], authority: Path) -> None:
    if ROOT.name != "interlanguage":
        raise RuntimeError(f"unexpected workspace root: {ROOT}")
    assert_hash(POINTER, EXPECTED_POINTER_SHA)
    if pointer["pointer_id"] != EXPECTED_POINTER_ID:
        raise RuntimeError("pointer ID changed")
    record = pointer["default_translation_authority"]
    raw = authority.read_bytes()
    if len(raw) != int(record["raw_bytes"]):
        raise RuntimeError("authority byte count disagrees with pointer")
    if digest(raw) != EXPECTED_AUTHORITY_SHA or str(record["raw_sha256"]) != EXPECTED_AUTHORITY_SHA:
        raise RuntimeError("authority body changed")
    if len(raw.split(b"\n")) - (1 if raw.endswith(b"\n") else 0) != 24146:
        raise RuntimeError("authority physical-line count changed")

    assert_hash(R03 / "reader.tex", EXPECTED_R03_ROOT)
    if set_identity(R03)[1] != EXPECTED_R03_SET:
        raise RuntimeError("r03 editable set changed")
    assert_hash(R03 / "reader.pdf", EXPECTED_R03_PDF)
    assert_hash(R04 / "freeze.csv", EXPECTED_R04_FREEZE)
    assert_hash(R04 / "reader.tex", EXPECTED_R04_ROOT)
    if set_identity(R04)[1] != EXPECTED_R04_SET:
        raise RuntimeError("r04 editable set changed")
    assert_hash(R04 / "reader.pdf", EXPECTED_R04_PDF)
    assert_hash(R05 / "freeze.csv", EXPECTED_R05_FREEZE)
    assert_hash(R05 / "reader.tex", EXPECTED_R05_ROOT)
    if set_identity(R05)[1] != EXPECTED_R05_SET:
        raise RuntimeError("r05 editable set changed")
    assert_hash(R05 / "reader.pdf", EXPECTED_R05_PDF)
    assert_hash(R06 / "pack.py", EXPECTED_R06_PACK)
    assert_hash(R06 / "freeze.csv", EXPECTED_R06_FREEZE)
    assert_hash(R06 / "reader.tex", EXPECTED_R06_ROOT)
    if set_identity(R06)[1] != EXPECTED_R06_SET:
        raise RuntimeError("r06 editable set changed")
    assert_hash(R06 / "reader.pdf", EXPECTED_R06_PDF)
    assert_hash(R06 / "reader.log", EXPECTED_R06_LOG)
    assert_hash(R07 / "pack.py", EXPECTED_R07_PACK)
    assert_hash(R07 / "freeze.csv", EXPECTED_R07_FREEZE)
    assert_hash(R07 / "reader.tex", EXPECTED_R07_ROOT)
    if set_identity(R07)[1] != EXPECTED_R07_SET:
        raise RuntimeError("r07 editable set changed")
    assert_hash(R07 / "reader.pdf", EXPECTED_R07_PDF)
    assert_hash(R07 / "reader.log", EXPECTED_R07_LOG)
    assert_hash(R06 / "chg.csv", EXPECTED_R06_CHG)
    assert_hash(R07 / "chg.csv", EXPECTED_R07_CHG)
    assert_hash(R08 / "pack.py", EXPECTED_R08_PACK)
    assert_hash(R08 / "freeze.csv", EXPECTED_R08_FREEZE)
    assert_hash(R08 / "manifest.csv", EXPECTED_R08_MANIFEST)
    assert_hash(R08 / "reader.tex", EXPECTED_R08_ROOT)
    if set_identity(R08)[1] != EXPECTED_R08_SET:
        raise RuntimeError("r08 editable set changed")
    assert_hash(R08 / "reader.pdf", EXPECTED_R08_PDF)
    assert_hash(R08 / "reader.log", EXPECTED_R08_LOG)
    assert_hash(R09 / "pack.py", EXPECTED_R09_PACK)
    assert_hash(R09 / "freeze.csv", EXPECTED_R09_FREEZE)
    assert_hash(R09 / "manifest.csv", EXPECTED_R09_MANIFEST)
    assert_hash(R09 / "reader.tex", EXPECTED_R09_ROOT)
    if set_identity(R09)[1] != EXPECTED_R09_SET:
        raise RuntimeError("r09 editable set changed")
    assert_hash(R09 / "reader.pdf", EXPECTED_R09_PDF)
    assert_hash(R09 / "reader.log", EXPECTED_R09_LOG)
    authority_asset = authority.parent / "authority_rosette_native_supported_mask.png"
    assert_hash(authority_asset, EXPECTED_AUTHORITY_ASSET)
    assert_hash(HERE / "authority_rosette_native_supported_mask.png", EXPECTED_AUTHORITY_ASSET)
    for index in range(8):
        if (HERE / f"t{index}.tex").read_bytes() != (R09 / f"t{index}.tex").read_bytes():
            raise RuntimeError(f"r10 component t{index}.tex diverges from r09")


def write_freeze(pointer: dict[str, object], authority: Path) -> None:
    cjk = ROOT / "03_projects" / "language_management" / "cjk"
    ja = cjk / "03_working_translations" / "japanese"
    baseline = (
        cjk / "01_recovered_witnesses" / "noether_cjk_chinese_japanese_cumulative_20260702"
        / "translations" / "non_slavic" / "japanese" / "source_fidelity" / "v001"
        / "Noether_Japanese_Cumulative_SourceFidelity_v001.tex"
    )
    candidate = ja / "noether_ja" / "reader.tex"
    replay = REBASE / "replay" / "reader.tex"
    historical_public = ROOT / "03_projects" / "noether" / "08_zenodo" / "r6" / "20-ja.tex"
    checker = cjk / "05_independent_checking" / "cjk_r1"

    if historical_public.exists():
        raise RuntimeError("historical candidate_public_copy unexpectedly reappeared")
    assert_hash(baseline, "4A284DF3FAC4D53D305659B539AF2FEB17902BFB4C254A7DF62A155C6BC23131")
    for witness in (candidate, replay):
        assert_hash(witness, "47F8150D6750A02FF939C0E6CF4F07909858AB6DFEC8E511B047D4640BCFB235")
    assert_hash(checker / "ja_r08.csv", EXPECTED_CHECK_CSV)
    assert_hash(checker / "ja_r08.md", EXPECTED_CHECK_MD)
    assert_hash(checker / "ext_sys.csv", EXPECTED_EXT_CSV)
    assert_hash(checker / "ext_sys.md", EXPECTED_EXT_MD)

    rows: list[dict[str, object]] = [
        file_row("authority_pointer_current", POINTER, str(POINTER), EXPECTED_POINTER_ID),
        file_row("authority_pointer_versioned", CANON / "pointers" / "v051.json", str(CANON / "pointers" / "v051.json"), "immutable v051 pointer"),
        file_row("authority_body", authority, str(authority), "exact ED0014; 24146 physical LF lines"),
        file_row("authority_rosette_asset", authority.parent / "authority_rosette_native_supported_mask.png", str(authority.parent / "authority_rosette_native_supported_mask.png"), "exact ED0014 graphic build input"),
        file_row("baseline_tex", baseline, str(baseline), "inherited 1.79 MB source-fidelity baseline"),
        file_row("candidate_tex", candidate, str(candidate), "surviving candidate witness"),
        file_row("candidate_replay", replay, "../replay/reader.tex", "surviving exact candidate replay"),
        identity_row("candidate_public_copy_historical", str(historical_public), 1925975, "47F8150D6750A02FF939C0E6CF4F07909858AB6DFEC8E511B047D4640BCFB235", "historical identity only; path absent"),
        file_row("historical_r03_freeze", R03 / "freeze3.csv", "../freeze3.csv", "historical ED0005 freeze"),
        file_row("historical_r03_root", R03 / "reader.tex", "../reader.tex", "historical exact base"),
        file_row("historical_r03_pdf", R03 / "reader.pdf", "../reader.pdf", "historical mechanical output"),
        set_row("historical_r03_editable_set", R03, "../reader.tex+../t0.tex-../t7.tex", "historical editable-set identity"),
        file_row("historical_r04_freeze", R04 / "freeze.csv", "../r04/freeze.csv", "historical ED0008 freeze"),
        file_row("historical_r04_root", R04 / "reader.tex", "../r04/reader.tex", "historical root"),
        file_row("historical_r04_pdf", R04 / "reader.pdf", "../r04/reader.pdf", "historical mechanical output"),
        set_row("historical_r04_editable_set", R04, "../r04/reader.tex+../r04/t0.tex-../r04/t7.tex", "historical editable-set identity"),
        file_row("historical_r05_freeze", R05 / "freeze.csv", "../r05/freeze.csv", "historical r05 freeze"),
        file_row("historical_r05_root", R05 / "reader.tex", "../r05/reader.tex", "historical r05 root"),
        file_row("historical_r05_pdf", R05 / "reader.pdf", "../r05/reader.pdf", "historical r05 mechanical output"),
        set_row("historical_r05_editable_set", R05, "../r05/reader.tex+../r05/t0.tex-../r05/t7.tex", "historical r05 editable-set identity"),
        file_row("historical_r06_pack", R06 / "pack.py", "../r06/pack.py", "historical r06 generator"),
        file_row("historical_r06_freeze", R06 / "freeze.csv", "../r06/freeze.csv", "historical r06 freeze"),
        file_row("historical_r06_root", R06 / "reader.tex", "../r06/reader.tex", "historical r06 root"),
        file_row("historical_r06_pdf", R06 / "reader.pdf", "../r06/reader.pdf", "historical r06 mechanical output"),
        file_row("historical_r06_log", R06 / "reader.log", "../r06/reader.log", "historical r06 final build log"),
        set_row("historical_r06_editable_set", R06, "../r06/reader.tex+../r06/t0.tex-../r06/t7.tex", "historical r06 editable-set identity"),
        file_row("historical_r06_change_ledger", R06 / "chg.csv", "../r06/chg.csv", "historical producer ledger reopened for omitted-locus provenance"),
        file_row("historical_r07_change_ledger", R07 / "chg.csv", "../r07/chg.csv", "historical producer ledger containing the provenance omission"),
        file_row("historical_r08_pack", R08 / "pack.py", "../r08/pack.py", "historical r08 generator"),
        file_row("historical_r08_freeze", R08 / "freeze.csv", "../r08/freeze.csv", "historical r08 freeze"),
        file_row("historical_r08_manifest", R08 / "manifest.csv", "../r08/manifest.csv", "historical r08 coverage manifest"),
        file_row("historical_r08_root", R08 / "reader.tex", "../r08/reader.tex", "historical r08 root"),
        file_row("historical_r08_pdf", R08 / "reader.pdf", "../r08/reader.pdf", "historical r08 mechanical output"),
        file_row("historical_r08_log", R08 / "reader.log", "../r08/reader.log", "historical r08 final build log"),
        set_row("historical_r08_editable_set", R08, "../r08/reader.tex+../r08/t0.tex-../r08/t7.tex", "historical r08 editable-set identity"),
        file_row("inherited_r09_pack", R09 / "pack.py", "../r09/pack.py", "immediate inherited generator"),
        file_row("inherited_r09_freeze", R09 / "freeze.csv", "../r09/freeze.csv", "immediate inherited-base freeze"),
        file_row("inherited_r09_manifest", R09 / "manifest.csv", "../r09/manifest.csv", "immediate inherited coverage manifest"),
        file_row("inherited_r09_root", R09 / "reader.tex", "../r09/reader.tex", "immediate inherited root"),
        file_row("inherited_r09_pdf", R09 / "reader.pdf", "../r09/reader.pdf", "immediate inherited mechanical output"),
        file_row("inherited_r09_log", R09 / "reader.log", "../r09/reader.log", "immediate inherited final build log"),
        set_row("inherited_r09_editable_set", R09, "../r09/reader.tex+../r09/t0.tex-../r09/t7.tex", "immediate inherited editable-set identity"),
        file_row("independent_return_ledger", checker / "ja_r08.csv", str(checker / "ja_r08.csv"), "immutable 21-row checker return evidence; not producer-owned"),
        file_row("independent_return_receipt", checker / "ja_r08.md", str(checker / "ja_r08.md"), "immutable checker return receipt; not producer-owned"),
        file_row("shared_extraction_ledger", checker / "ext_sys.csv", str(checker / "ext_sys.csv"), "immutable shared extraction evidence; not producer-owned"),
        file_row("shared_extraction_receipt", checker / "ext_sys.md", str(checker / "ext_sys.md"), "immutable shared extraction receipt; not producer-owned"),
        file_row("target_root", HERE / "reader.tex", "reader.tex", "ED0014 bounded r09 successor root"),
        set_row("target_editable_set", HERE, "reader.tex+t0.tex-t7.tex", "domain-separated filename|file_sha256 LF records"),
        file_row("target_rosette_asset", HERE / "authority_rosette_native_supported_mask.png", "authority_rosette_native_supported_mask.png", "exact authority build input outside editable-TeX identity"),
    ]
    for index in range(8):
        rows.append(file_row(f"target_t{index}", HERE / f"t{index}.tex", f"t{index}.tex", "r10 component byte-identical to r09"))
    for name, role, note in [
        ("reader.pdf", "target_pdf", "mechanical output only; page count by final log"),
        ("reader.log", "build_log", "final serial XeLaTeX log"),
        ("build.json", "build_receipt", "mechanical build and diagnostic receipt"),
        ("terms.csv", "terminology", "producer terminology ledger; Japanese approval not claimed"),
        ("notes.csv", "note_map", "73-row note custody rebound to ED0014; target cursors unchanged"),
        ("chg.csv", "change_ledger", "exact r09 base and every ED0014 mapped target locus"),
        ("adv.csv", "adverse_ledger", "four authority-owner observations plus shared extraction defect"),
        ("xext.csv", "extraction_exception", "explicit cross-lane governance exception; no extraction-clean claim"),
        ("manifest.csv", "coverage_manifest", "complete ED0014 source and r10 target cursors regenerated"),
        ("prov.md", "provenance", "r09-to-r10 lineage and exact ED0011-to-ED0014 diff intake"),
        ("return.md", "producer_return", "static ED0014 bounded-rebase successor"),
        ("gate.csv", "multi_day_gate", "append-only reset to 0/3 after authority and target change"),
        ("watch.json", "canon_watch", "static same-session checker-gated watch snapshot without automation ownership"),
        ("state.md", "durable_state", "static compaction-hard recovery state for this freeze"),
        ("pack.py", "freeze_generator", "pinned inherited manifest and r10 freeze generator"),
    ]:
        rows.append(file_row(role, HERE / name, name, note))
    with (HERE / "freeze.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["role", "path", "present", "bytes", "sha256", "note"],
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    pointer_raw = POINTER.read_bytes()
    if digest(pointer_raw) != EXPECTED_POINTER_SHA:
        raise RuntimeError("current pointer changed before r10 freeze")
    pointer = json.loads(pointer_raw.decode("utf-8"))
    authority = Path(str(pointer["default_translation_authority"]["path"]))
    validate_inputs(pointer, authority)
    write_manifest(authority)
    write_freeze(pointer, authority)
    for name in ("manifest.csv", "freeze.csv"):
        path = HERE / name
        print(f"{name}: bytes={path.stat().st_size} sha256={digest(path.read_bytes())}")
    print(f"r09_set={set_identity(R09)[1]}")
    print(f"r10_set={set_identity(HERE)[1]}")


if __name__ == "__main__":
    main()
