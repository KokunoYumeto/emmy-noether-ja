$ErrorActionPreference = 'Stop'

$utf8 = [System.Text.UTF8Encoding]::new($false)
$root = 'C:\Users\Floris\Documents\interlanguage\03_projects\language_management\cjk'
$ja = Join-Path $root '03_working_translations\japanese'
$orig = Join-Path $ja 'noether_ja'
$out = Join-Path $ja 'rebase\replay'
New-Item -ItemType Directory -Path $out -Force | Out-Null
$witness = Join-Path $root '01_recovered_witnesses\noether_cjk_chinese_japanese_cumulative_20260702\translations\non_slavic\japanese\source_fidelity\v001\Noether_Japanese_Cumulative_SourceFidelity_v001.tex'

$docs = [ordered]@{
    21 = Join-Path $ja 'noether_paper21_ja_reconciliation_20260718\Noether_Paper21_Japanese_SourceReconciled_v001.tex'
    22 = Join-Path $ja 'noether_paper22_ja_reconciliation_20260718\Noether_Paper22_Japanese_SourceReconciled_v001.tex'
    23 = Join-Path $ja 'noether_paper23_ja_reconciliation_20260718\Noether_Paper23_Japanese_SourceReconciled_v001.tex'
    24 = Join-Path $ja 'noether_paper24_ja_reconciliation_20260718\Noether_Paper24_Japanese_SourceReconciled_v001.tex'
    25 = Join-Path $ja 'noether_paper25_ja_reconciliation_20260718\Noether_Paper25_Japanese_SourceReconciled_v001.tex'
    26 = Join-Path $root '03_working_translations\noether_paper26_cjk_tranche_002_20260717\ja\Noether_Paper26_Japanese_SourceReconciled_v001.tex'
    27 = Join-Path $ja 'noether_paper27_ja_reconciliation_20260718\Noether_Paper27_Japanese_SourceReconciled_v001.tex'
    28 = Join-Path $root '03_working_translations\noether_paper28_cjk_tranche_003_20260718\ja\Noether_Paper28_Japanese_SourceReconciled_v001.tex'
    31 = Join-Path $ja 'noether_paper31_ja_reconciliation_20260722\P31_JA.tex'
    36 = Join-Path $root '03_working_translations\noether_paper36_cjk_tranche_001_20260717\ja\Noether_Paper36_Japanese_SourceReconciled_v001.tex'
    43 = Join-Path $orig 'p43_src.tex'
}

function Read-Lf([string]$path) {
    return [System.IO.File]::ReadAllText($path).Replace("`r`n", "`n").Replace("`r", "`n")
}

function Get-Body([string]$path) {
    $text = Read-Lf $path
    $begin = $text.IndexOf('\begin{document}')
    $end = $text.LastIndexOf('\end{document}')
    if ($begin -lt 0 -or $end -le $begin) {
        throw "Document bounds not found: $path"
    }
    $body = $text.Substring($begin + '\begin{document}'.Length, $end - ($begin + '\begin{document}'.Length))
    $dir = Split-Path -Parent $path
    $lines = $body -split "`n"
    $expanded = [System.Collections.Generic.List[string]]::new()
    foreach ($line in $lines) {
        if ($line -match '^\s*\\input\{([^}]+)\}\s*$') {
            $child = $matches[1]
            if (-not [System.IO.Path]::HasExtension($child)) { $child += '.tex' }
            $childPath = Join-Path $dir $child
            $expanded.Add((Get-Body $childPath).Trim("`n"))
        } else {
            $expanded.Add($line)
        }
    }
    return ($expanded -join "`n").Trim("`n") + "`n"
}

function Replace-Once([string]$text, [string]$pattern, [string]$replacement, [string]$label) {
    $rx = [regex]::new($pattern, [System.Text.RegularExpressions.RegexOptions]::Multiline -bor [System.Text.RegularExpressions.RegexOptions]::Singleline)
    $count = $rx.Matches($text).Count
    if ($count -ne 1) { throw "$label span count is $count, expected 1" }
    return $rx.Replace($text, { param($m) $replacement.Trim("`n") + "`n`n" }, 1)
}

function Replace-Exact([string]$text, [string]$old, [string]$new, [string]$label, [int]$expected = 1) {
    $count = [regex]::Matches($text, [regex]::Escape($old)).Count
    if ($count -ne $expected) { throw "$label exact count is $count, expected $expected" }
    return $text.Replace($old, $new)
}

function Replace-ExactInSpan([string]$text, [string]$start, [string]$end, [string]$old, [string]$new, [string]$label, [int]$expected = 1) {
    $a = $text.IndexOf($start, [StringComparison]::Ordinal)
    if ($a -lt 0) { throw "$label start marker not found" }
    $b = $text.IndexOf($end, $a + $start.Length, [StringComparison]::Ordinal)
    if ($b -lt 0) { throw "$label end marker not found" }
    $span = $text.Substring($a, $b - $a)
    $count = [regex]::Matches($span, [regex]::Escape($old)).Count
    if ($count -ne $expected) { throw "$label span count is $count, expected $expected" }
    $span = $span.Replace($old, $new)
    return $text.Substring(0, $a) + $span + $text.Substring($b)
}

function Replace-RegexInSpan([string]$text, [string]$start, [string]$end, [string]$pattern, [string]$new, [string]$label, [int]$expected = 1) {
    $a = $text.IndexOf($start, [StringComparison]::Ordinal)
    if ($a -lt 0) { throw "$label start marker not found" }
    $b = $text.IndexOf($end, $a + $start.Length, [StringComparison]::Ordinal)
    if ($b -lt 0) { throw "$label end marker not found" }
    $span = $text.Substring($a, $b - $a)
    $rx = [regex]::new($pattern, [System.Text.RegularExpressions.RegexOptions]::Singleline -bor [System.Text.RegularExpressions.RegexOptions]::Multiline)
    $count = $rx.Matches($span).Count
    if ($count -ne $expected) { throw "$label regex span count is $count, expected $expected" }
    $span = $rx.Replace($span, { param($m) $new })
    return $text.Substring(0, $a) + $span + $text.Substring($b)
}

function Get-LineBlock([string[]]$lines, [int]$first, [int]$last) {
    return ($lines[($first - 1)..($last - 1)] -join "`n").Trim("`r", "`n")
}

$bodies = @{}
foreach ($entry in $docs.GetEnumerator()) {
    $body = if ([int]$entry.Key -eq 43) { (Read-Lf $entry.Value).Trim("`n") + "`n" } else { Get-Body $entry.Value }
    $bodies[$entry.Key] = $body
    [System.IO.File]::WriteAllText((Join-Path $out ("p{0:D2}.tex" -f [int]$entry.Key)), $body, $utf8)
}

$canon = 'C:\Users\Floris\Documents\interlanguage\03_projects\noether\07_german_canon_control'
$pointerPath = Join-Path $canon 'pointers\v012.json'
$pointerHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $pointerPath).Hash
if ($pointerHash -ne 'E6AB9ECD14353A6AF3ADA9DFDA405A21DA1D3C8E4192248089DFF4716E509F77') {
    throw "German authority pointer changed: $pointerHash"
}
$pointer = Get-Content -Raw -LiteralPath $pointerPath | ConvertFrom-Json
if ($pointer.pointer_id -ne 'NOETH-DE-AUTH-v012-20260804') {
    throw "Unexpected German authority pointer: $($pointer.pointer_id)"
}
$authorityPath = Join-Path $canon 'candidates\ED0003\noether.tex'
$authorityHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $authorityPath).Hash
if ($authorityHash -ne '4A568FA0818D52EFE6CC75BBE092ABE40097365590B72496CB7C02A7C50C8AA5') {
    throw "ED0003 authority hash changed: $authorityHash"
}

# Exact line locators used by the bounded repair replay predate ED0003's
# output-only P02 line insertion. Their semantic parent remains hash-pinned.
$dePath = Join-Path $canon 'candidates\ED0002\noether.tex'
$deHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $dePath).Hash
if ($deHash -ne 'C9A125167ACB33D914EE4374B65AE7CDF0052F568371B8B77B720EA178ABF0E3') {
    throw "ED0002 locator parent hash changed: $deHash"
}
$deLines = (Read-Lf $dePath) -split "`n"

$reader = Read-Lf $witness
$reader = $reader.Replace('\setCJKmainfont{Noto Serif CJK JP}', '\setCJKmainfont[AutoFakeSlant=0.15]{Yu Gothic}')
$reader = $reader.Replace('\setCJKsansfont{Noto Sans CJK JP}', '\setCJKsansfont{Yu Gothic}')

$helpers = @'
% Consolidated commands required by the reconciled Paper 23 body.
\providecommand{\mJ}{\mathfrak J}
\providecommand{\srcnumdisplay}[2]{\begin{equation*}\tag*{#1}\begin{aligned}#2\end{aligned}\end{equation*}}
\providecommand{\PXXIIIitem}[2]{\par\noindent\hangindent=2.2em\hangafter=1\makebox[2.2em][l]{#1.}#2\par}
\makeatletter
\providecommand{\srcfn}[2]{%
  \begingroup
  \renewcommand{\thefootnote}{#1}%
  \footnote{#2}%
  \addtocounter{footnote}{-1}%
  \endgroup}
\providecommand{\srcfnmark}[1]{%
  \begingroup
  \renewcommand{\thefootnote}{#1}%
  \footnotemark%
  \addtocounter{footnote}{-1}%
  \endgroup}
\providecommand{\srcfntext}[2]{%
  \begingroup
  \renewcommand{\thefootnote}{#1}%
  \footnotetext{#2}%
  \endgroup}
\makeatother
'@
$reader = $reader.Replace('\begin{document}', $helpers.TrimEnd() + "`n`n\begin{document}")

foreach ($p in 21,22,23,24,25,26,27,28) {
    $next = $p + 1
    $pattern = "^\\section\*\{$p\..*?(?=^\\section\*\{$next\.)"
    $reader = Replace-Once $reader $pattern $bodies[$p] "P$p"
}
$reader = Replace-Once $reader '^\\section\*\{31\..*?(?=^\\section\*\{32\.)' $bodies[31] 'P31'
$reader = Replace-Once $reader '^\\section\*\{36\..*?(?=^\\section\*\{37\.)' $bodies[36] 'P36'
$reader = Replace-Once $reader '^\\section\*\{43\..*?(?=^\\section\*\{RA10)' $bodies[43] 'P43'

$oldP08 = '$K$ としても $R$ を取らねばならない。なぜなら、有理整数の $\theta_1,\theta_2$ についてだけ $c_1P_1+c_2P_2$ が再び過程 $P$ になるからである。'
$newP08 = '$K$ としても $R$ を取らねばならない。なぜなら、$c_1,c_2$ が有理数である場合にのみ、$c_1P_1+c_2P_2$ も再び過程 $P$ になるからである。'
if (-not $reader.Contains($oldP08)) { throw 'P08 stale coefficient reading not found exactly' }
$reader = $reader.Replace($oldP08, $newP08)

$oldAxiom3 = '$\mo\equiv0\pmod{\mo^2}$ だが $\mo^2\not\equiv0\pmod{\mo^2}$'
$newAxiom3 = '$\mo\not\equiv0\pmod{\mo^2}$ だが $\mo^2\equiv0\pmod{\mo^2}$'
if (-not $reader.Contains($oldAxiom3)) { throw 'P30 Axiom III stale reading not found exactly once' }
$reader = $reader.Replace($oldAxiom3, $newAxiom3)

$oldAxiom4 = @'
2. \emph{公理 IV、零因子がないことの証明。} $a$ が零因子で、$a\ne0$, $b\ne0$ かつ $ab=0$ であるとする。すると $a$ と $b$ によって生成される主イデアルの積表示を掛け合わせて
\[
        (0)=\mpideal_1^{\varrho_1}\cdots\mpideal_r^{\varrho_r}
\]
を得る。ここで $\mpideal_i$ は零イデアルおよび単位イデアルと異なる。後者は、単位元の存在がすでに証明されているからである。表示は最短、すなわちどの因子を削除しても零イデアルの真の約イデアルを与えるものとして取る。零イデアルについては一意性を仮定していないので、これは自動的ではない。一つの素イデアルだけが現れるなら、$(0)=\mpideal^\varrho=\mpideal^{\varrho+1}$ となり、鋭い一意性要求に反する。複数の素イデアルが現れるなら、
\[
\begin{aligned}
\mpideal_1^{\varrho_1}
 &= (\mpideal_1^{\varrho_1},\mpideal_2^{\varrho_2}\cdots\mpideal_r^{\varrho_r})\mpideal_1^{\varrho_1}  \\
 &= \mpideal_1^{\varrho_1}\mpideal_2^{\varrho_2}\cdots\mpideal_r^{\varrho_r},
\end{aligned}
\]
である。なぜなら単位元の存在により、$\mpideal_1$ は他のすべての素イデアルと互いに素だからである。これも再び鋭い一意性条件に矛盾する。
'@
$newAxiom4 = @'
2. \emph{公理 IV、零因子がないことの証明。} $a$ が零因子で、$a\ne0$, $b\ne0$ かつ $ab=0$ であるとする。すると $a$ と $b$ によって生成される主イデアルの積表示を掛け合わせて
\[
        (0)=\mpideal_1^{\varrho_1}\cdots\mpideal_k^{\varrho_k}
\]
を得る。ここで $\mpideal_i$ は零イデアルおよび単位イデアルと異なる。後者は、単位元の存在がすでに証明されているからである。表示は最短、すなわちどの因子を削除しても零イデアルの真の約イデアルを与えるものとして取る。零イデアルについては一意性を仮定していないので、これは自動的ではない。一つの素イデアルだけが現れるなら、$(0)=\mpideal^\varrho=\mpideal^{\varrho+1}$ となり、鋭い一意性要求に反する。複数の素イデアルが現れるなら、
\[
\begin{aligned}
\mpideal_1^{\varrho_1+1}
 &= (\mpideal_1^{\varrho_1+1},\mpideal_1^{\varrho_1}\cdots\mpideal_k^{\varrho_k}) \\
 &= \mpideal_1^{\varrho_1}(\mpideal_1,\mpideal_2^{\varrho_2}\cdots\mpideal_k^{\varrho_k}) \\
 &= \mpideal_1^{\varrho_1}.
\end{aligned}
\]
となる。なぜなら単位元の存在により、$\mpideal_1$ は他のすべての素イデアルと互いに素だからである。これも再び鋭い一意性条件に矛盾する。
'@
if (-not $reader.Contains($oldAxiom4.Trim("`r", "`n"))) { throw 'P30 Axiom IV stale block not found exactly' }
$reader = $reader.Replace($oldAxiom4.Trim("`r", "`n"), $newAxiom4.Trim("`r", "`n"))

$oldP34 = @'
\setcounter{footnote}{0}
\section*{34. 超複素量と表現論}
\emph{続きおよび完結：第III章 §§15--19 および第IV章 §§20--26。}
'@
$newP34 = '\subsection*{続き：第III章 §§15--19 および第IV章 §§20--26}'
if (-not $reader.Contains($oldP34.Trim("`r", "`n"))) { throw 'P34 continuation heading not found exactly' }
$reader = $reader.Replace($oldP34.Trim("`r", "`n"), $newP34)

# Independent Japanese checker return: source-visible mathematical repairs.
$reader = Replace-Exact $reader '数 $\lambda$ は、$\sigma>\tau$ の場合' '数 $\lambda$ は、$\sigma\ge\tau$ の場合' 'P04-01'
$reader = Replace-Exact $reader '$\rho$ 個（$\rho<n$）の式 $(a^{(i)}' '$\rho$ 個（$\rho\le n$）の式 $(a^{(i)}' 'P04-02'
$reader = Replace-Exact $reader 'q_\rho^{(1)}A^\sigma' 'q_{\rho-1}^{(1)}A^\sigma' 'P04-03'
$reader = Replace-Exact $reader 'q_\rho^{(\sigma+1\ldots\tau)}' 'q_{\rho-(\tau-\sigma)}^{(\sigma+1\ldots\tau)}' 'P04-04a'
$reader = Replace-Exact $reader 'p_{\tau-\sigma}^{(\sigma+1\ldots\tau)}' 'p_{\tau-(\tau-\sigma)}^{(\sigma+1\ldots\tau)}' 'P04-04b'
$reader = Replace-Exact $reader '=\pair{R_{\rho-\alpha}p_{n-\rho+\alpha}}{R^{\tau-\alpha}p_{\tau-\alpha}}' '=(R_{\rho-\alpha}p_{n-\rho+\alpha})\pair{R^{\tau-\alpha}}{p_{\tau-\alpha}}' 'P04-05'
$reader = Replace-Exact $reader 'R_{\rho+\sigma_1-\alpha-\lambda}' 'R_{\rho_1+\sigma_1-\alpha-\lambda}' 'P04-06'
$reader = Replace-Exact $reader '\pair{q_{n-\mu-\lambda}P^\mu}{Q_{\nu_1}p_{n-\mu-\nu_1-\lambda}}=\pair{R_\lambda Q_{\nu_1}}{p_{n-\mu-\nu_1-\lambda}}' '\pair{q_{n-\mu-\lambda}P^\mu}{Q_{\nu_1}p_{n-\nu_1-\lambda}}=(R_\lambda Q_{\nu_1}p_{n-\nu_1-\lambda})' 'P04-07a'
$reader = Replace-Exact $reader 'p_{n-\mu-\nu_1-\nu_2-\lambda}' 'p_{n-\nu_1-\nu_2-\lambda}' 'P04-07b' 2
$reader = Replace-Exact $reader "\qquad(\sigma\ge\tau,\ \lambda=1,2,\ldots,\min(\tau,n-\sigma))`n\tag{45}" "\qquad(\sigma\ge\tau,\ \lambda=1,2,\ldots,\min(\sigma,n-\tau))`n\tag{45}" 'P04-08'
$reader = Replace-Exact $reader ' f=\pair{S^1}{p_1}^{m_1}' ' f\equiv\pair{S^1}{p_1}^{m_1}' 'P04-09'
$reader = Replace-Exact $reader ',\qquad (\sigma>\tau)' ',\qquad (\sigma\ge\tau)' 'P04-10'
$reader = Replace-Exact $reader 'q_{\sigma-\beta}^{(i_1\ldots i_\beta)}q_{n-\tau+\lambda}' '\dot{q}_{\sigma-\beta}^{(i_1\ldots i_\beta)}q_{n-\tau+\lambda}' 'P04-11a'
$reader = Replace-Exact $reader 'p_{n-\tau-\beta}^{(i_1\ldots i_\beta)}' '\dot{p}_{n-\tau-\beta}^{(i_1\ldots i_\beta)}' 'P04-11b' 3
$reader = Replace-Exact $reader '個々の列 $p_\rho$ を $\xi^{(1)},\ldots,\xi^{(\rho)}$ で置き換え' '個々の列 $p_\sigma$ を $\xi^{(1)},\ldots,\xi^{(\sigma)}$ で置き換え' 'P04-12'
$reader = Replace-Exact $reader '(\xi^{(1)}\xi^{(2)}\cdots\xi^{(n)})\sim\Delta;' '(\xi^{(1)}\xi^{(2)}\cdots\xi^{(n)})=\Delta;' 'P04-13'

$reader = Replace-Exact $reader "h'(x)" 'k(x)' 'P06-01' 2
$reader = Replace-Exact $reader "F^*(x^{(k)})H^*(\xi)-H^*(x^{(k)})F^*(\xi)=0;`n  \qquad H^*(\xi)\ne0" "F^*(x^{(k)})H^*(\xi)-H^*(x^{(k)})F^*(\xi)=0;`n  \qquad H(\xi)\ne0" 'P06-02a'
$reader = Replace-Exact $reader "F^*(x)H^*(\xi)-H^*(x)F^*(\xi)=0;`n  \qquad H^*(\xi)\ne0" "F^*(x)H^*(\xi)-H^*(x)F^*(\xi)=0;`n  \qquad H(\xi)\ne0" 'P06-02b'
$reader = Replace-Exact $reader 'x_1^2z^2-x_1^4u_1^2-2x_1^3x_2u_1u_2' 'x_1^2z^2-x_1^2u_1^2-2x_1^2x_2u_1u_2' 'P06-03'
$reader = Replace-Exact $reader '\Gdom_{22}$ では、許容される特殊化' '\Gdom_{32}$ では、許容される特殊化' 'P06-04a'
$reader = Replace-Exact $reader '\Gdom_{22}$ は第一種' '\Gdom_{32}$ は第一種' 'P06-04b'
$reader = Replace-Exact $reader '1=i_0+i_1+\cdots+i_\nu,' '1=i_0+i_1+i_2+\cdots+i_\nu,' 'P06-05'
$reader = Replace-Exact $reader 'F(x)=\frac{\Gamma(H(x),H_1(x),\ldots,H_s(x))}{i\cdot H(x)^i}' 'F(x)=\frac{\Gamma(H(x),H_1(x),\ldots,H_\sigma(x))}{i\cdot H(x)^k}' 'P06-06'

$reader = Replace-Exact $reader '=\varkappa^\rho\varphi_\rho^{(i)}' '=\varkappa\varphi_\rho^{(i)}' 'P12-01'
$reader = Replace-Exact $reader 'R^{(m)}(x_n)=0(\mathfrak M)' 'R^{(n)}(x_n)\equiv0(\mathfrak M)' 'P18-01'
$reader = Replace-Exact $reader '剰余類系 $(\mR)$ が体 $P(\sqrt\lambda,\sqrt\mu)$ と同型だからである。体 $(\mR)$ は' '剰余類系 $(\bar{\mR})$ が体 $P(\sqrt\lambda,\sqrt\mu)$ と同型だからである。体 $(\bar{\mR})$ は' 'P24-01'
$p24BreakOld = @'
はイデアルの意味での最大公約因子として $\frakp$ の真の因子となるので、
\[
'@
$p24BreakNew = @'
はイデアルの意味での最大公約因子として $\frakp$ の真の因子となるので、
\pagebreak[4]
\[
'@
$reader = Replace-Exact $reader $p24BreakOld.Trim("`r", "`n") $p24BreakNew.Trim("`r", "`n") 'P24-layout-01'
$reader = Replace-ExactInSpan $reader '{\Large\bfseries 4.' '{\Large\bfseries 5.' '&\quad\cdot\pair{s^{(1)}}{\xi^{(1)}}' '&=\pair{s^{(1)}}{\xi^{(1)}}' 'P04-14'

$p33Open = @'
\begingroup
\renewcommand{\thefootnote}{(\arabic{footnote})}

\begin{center}
\textsc{Emmy Noether}（Göttingen -- Germania）\\[-0.1em]
\rule{3em}{0.4pt}\\[0.8em]
\textsc{超複素量と表現論}\\
\textsc{算術的立場から}\footnote{詳しい叙述は \emph{Mathematische Zeitschrift} に掲載される予定であり、その続編では非可換ガロア理論も論じられる。分解体については R. Brauer--E. Noether, \emph{Berichte der Berliner Akademie} 1927 を、一般構造定理については本論集所収の G. Köthe の講演をも参照。}
\end{center}

ここでは、表現論、とりわけ群の表現論を、加群類およびイデアル類の理論として捉えられること、さらに後二者が、作用素をもつ群という一般化された群概念のもとに再び組み込まれることを示したい。\footnote{作用素をもつ群は W. Krull（\emph{Math. Z.} 23）および O. Schmidt（\emph{Math. Z.} 29）に遡る。与えられた表現の簡約問題をここで扱う方法も、可換な表現体に限れば、W. Krull, \emph{Theorie und Anwendung der verallgemeinerten Abelschen Gruppen}, \emph{Heidelberger Berichte} 1926 に由来する。}

あらかじめ指定された体 $P$ における\emph{群の表現}とは、周知のように次のものをいう。群 $\mathfrak G$ の元 $a,b,\ldots$ に、$P$ の係数をもつ行列 $A,B,\ldots$ を対応させ、積 $ab$ に積 $AB$ が対応するようにする。この行列系は群の準同型像となる。この表現と同時に、「群数」、すなわち線型結合
\[
        a\alpha+b\beta+\cdots+c\gamma
\]
の全体からなる「群環」の表現も与えられる。ここで $a,b,\ldots,c$ はその都度有限個の群元を、$\alpha,\beta,\ldots,\gamma$ はそれぞれ有限個の $P$ の元を走り、群元は線型独立とみなし、乗法は群の乗法と演算法則によって定義する。群環の表現は加法についても準同型である。こうして群の表現は、加法と乗法の双方に関する準同型を要求する一般の\emph{環の表現}問題に含まれる。

ここで本質的な問題は二つある。第一は、\emph{与えられた表現の簡約}と、その際に現れる既約成分の一意性である。第二は、与えられた環を、与えられた必ずしも可換でない体に表現する仕方の全体、あるいはそのうち既約表現だけの全体を問う問題である。
'@
$reader = Replace-Once $reader '^\\subsection\*\{序論\}\n\n超複素系に関する最も重要な一般定理.*?(?=^第一の問題は)' $p33Open 'P33 opening'
$reader = Replace-ExactInSpan $reader '\section*{33.' '\section*{34.' '\mathfrak{M}' '\mathfrak{B}' 'P33 group symbol' 3
$p33Last = '最も一般的な作用素をもつ群へ拡張された群論は、ここでも再び秩序づけの原理であることを示している。'
$reader = Replace-ExactInSpan $reader '\section*{33.' '\section*{34.' $p33Last ($p33Last + "`n`n\endgroup") 'P33 group close'

$p13a = '{\Large\bfseries 13.'
$p13b = '\section*{14.'
$reader = Replace-ExactInSpan $reader $p13a $p13b '\frac{\p p}{\p x}=\sum_k\frac{\p g}{\p y_k}\frac{\p y_k}{\p x}' '\frac{\p p}{\p x}=\sum\frac{\p g}{\p y_\varkappa}\frac{\p y_\varkappa}{\p x}' 'P13-01'
$reader = Replace-ExactInSpan $reader $p13a $p13b '\frac{\p g}{\p y},\ldots,\frac{\p^\sigma g}{\p y^\sigma},\ldots,\frac{\p^\sigma x}{\p y^\sigma}' '\frac{\p g}{\p y},\ldots,\frac{\p x}{\p y},\ldots,\frac{\p^\sigma x}{\p y^\sigma}' 'P13-02'
$reader = Replace-ExactInSpan $reader $p13a $p13b '\left|\frac{\p y_i}{\p x_k}\right|' '\left|\frac{\p y_i}{\p x_\varkappa}\right|' 'P13-03' 2
$reader = Replace-ExactInSpan $reader $p13a $p13b '\Div B^{(\lambda)}=\Div\left(\sum \alpha_\mu\chi^{(\mu)}\right),' '\Div B^{(\lambda)}=\Div\left(\sum \alpha\cdot\chi^{(\varkappa)}\right);' 'P13-04'
$p13s = '\section*{\S{}5. 関係の各成分の不変性}'
$reader = Replace-ExactInSpan $reader $p13s $p13b '\int\!\cdots\!\int\left(\sum_i\psi_i\delta u_i\right)\dd x' '\int\!\cdots\!\int\left(\sum\psi_i\delta u_i\right)\dd x' 'P13-s01' 2
$reader = Replace-ExactInSpan $reader $p13s $p13b '\sum_i\psi_i(u,\ldots)\delta u_i' '\sum\psi_i(u,\ldots)\delta u_i' 'P13-s02' 3
$reader = Replace-ExactInSpan $reader $p13s $p13b '\sum_i\psi_i(v,\ldots)\delta v_i' '\sum\psi_i(v,\ldots)\delta v_i' 'P13-s03' 4
$reader = Replace-ExactInSpan $reader $p13s $p13b '\sum_i\psi_i\delta u_i' '\sum\psi_i\delta u_i' 'P13-s04' 2
$reader = Replace-ExactInSpan $reader $p13s $p13b '\sum_i\psi_i\bd u_i' '\sum\psi_i\bd u_i' 'P13-s05' 2
$reader = Replace-ExactInSpan $reader $p13s $p13b '\sum_i\psi_i a_i^{(\lambda)}' '\sum\psi_i a_i^{(\lambda)}' 'P13-s06'
$reader = Replace-ExactInSpan $reader $p13s $p13b '\sum_i\psi_i\frac{\p u_i}{\p x_\lambda}' '\sum\psi_i\frac{\p u_i}{\p x_\lambda}' 'P13-s07'
$reader = Replace-ExactInSpan $reader $p13s $p13b "\sum_i\left(\psi_i u_i'+\frac{\dd\psi_i}{\dd x}\right)=0" "\sum\left(\psi_i u_i'+\frac{\dd\psi_i}{\dd x}\right)=0" 'P13-s08'
$reader = Replace-ExactInSpan $reader $p13s $p13b '\left\{\sum_i\frac{\p f}{\p u_i}' '\left\{\sum\frac{\p f}{\p u_i}' 'P13-s09'
$reader = Replace-ExactInSpan $reader $p13s $p13b "\left\{\sum_i\frac{\p f}{\p u_i'}\right\}p''(x)=0" "\left\{\sum\frac{\p f}{\p u_i'}\right\}p''(x)=0" 'P13-s10'
$p13NoteOld = 'の不変性が得られ、したがって \(\sum\psi_i\delta u_i\) の相対不変性が得られる。ここで'
$p13NoteNew = 'の不変性が得られ、したがって \(\sum\psi_i\delta u_i\) の相対不変性が得られる。\footnote{すなわち、\(\sum\psi_i\delta u_i\) は変換のもとで因子を受け取り、代数的不変式論でつねにいう相対不変性を表す。}ここで'
$reader = Replace-ExactInSpan $reader $p13a $p13b $p13NoteOld $p13NoteNew 'P13-note'

# Further independent checker returns, applied only in their paper spans.
$reader = Replace-Exact $reader "q'_{n-1}" "q'_{\lambda-1}" 'P04-15'
$reader = Replace-Exact $reader "q''_{n-\sigma-1}" "q''_{n-\rho-1}" 'P04-16'
$reader = Replace-Exact $reader 'S^\rho T^\rho,\quad T^{\rho-1},\ldots,T^{\rho-\lambda+1};' 'S^\rho T^\rho,\quad T^{\rho+1},\ldots,T^{\rho+\lambda-1};' 'P04-17'

$p15a = '{\Large\bfseries 15.'
$p15b = '{\Large\bfseries 16.'
$reader = Replace-ExactInSpan $reader $p15a $p15b '\rho' '\varrho' 'P15-01' 49
$reader = Replace-ExactInSpan $reader $p15a $p15b 'F=c\,\xi_{12}^\nu.' 'F=c\,\xi_{12}^x.' 'P15-02'
$reader = Replace-ExactInSpan $reader $p15a $p15b 'c\,(12)^\nu\equiv0' 'c\,(12)^x\equiv0' 'P15-03'
$reader = Replace-ExactInSpan $reader $p15a $p15b '\xi_{34}F_1' '\xi_{34}\cdot F_1' 'P15-04' 2
$p15Old = @'
        F(\xi_{ik})
        =
        \sum \xi_{i_1n}\cdots\xi_{i_\nu n}P^{(1)}
        \equiv
        \sum \xi_{j_1n}\cdots\xi_{j_\sigma n}S_0^{(j)}
        =
        F_0(\xi_{ik})\pmod{\frN},
'@
$p15New = @'
        F(\xi_{ik})=\sum \xi_{i_1n}\cdots\xi_{i_\sigma n}P^{(\nu)}
        \equiv\sum \xi_{j_1n}\cdots\xi_{j_\sigma n}S_0^{(\nu)}
        =F_0(\xi_{ik})\pmod{\frN},
'@
$reader = Replace-ExactInSpan $reader $p15a $p15b $p15Old.Trim("`r", "`n") $p15New.Trim("`r", "`n") 'P15-05'

$p16a = '{\Large\bfseries 16.'
$p16b = '{\Large\bfseries 17.'
$reader = Replace-ExactInSpan $reader $p16a $p16b 'F_1=(c_1\Omega+c_2\Omega\Delta\Omega+\cdots+c_i\Omega\Delta\Omega\cdots\Delta\Omega)F' 'F_1=(\alpha_1\Omega+\alpha_2\Omega\Delta\Omega+\cdots+\alpha_\lambda\Omega\Delta\Omega\cdots\Delta\Omega)F' 'P16-01'
$reader = Replace-ExactInSpan $reader $p16a $p16b 'ここで \(c_i\) もまた' 'ここで \(\alpha_i\) もまた' 'P16-02'

$reader = Replace-Exact $reader 'Math. Ann. 77, p. 103 (1915)' 'Math. Ann. 77, p. 103 (1916)' 'P10-01'
$p14a = '\section*{14.'
$p14b = '{\Large\bfseries 15.'
$reader = Replace-ExactInSpan $reader $p14a $p14b 'g_1(\eta,\tau_1)=0,\qquad g_2(\eta,\tau_1,\tau_2)=0,\ldots .' 'g(\eta,\tau_1)=0;\qquad g_2(\eta\tau_1\tau_2)=0\ldots .' 'P14-01'
$reader = Replace-ExactInSpan $reader $p14a $p14b 'g_2(\eta,\tau_1,\tau_2)=0,\ldots' 'g_2(\eta,\tau_1,\tau_2)=0\ldots' 'P14-02'
$reader = Replace-ExactInSpan $reader $p14a $p14b 'Fueter' 'Fuëter' 'P14-03'

$p17a = '{\Large\bfseries 17.'
$p17b = '{\Large\bfseries 18.'
$p17Old = '(11) により、$\mL$ の任意の多項式 $F$ は、$\bara$ を $\mL$ を法とする $N$ の剰余類、したがって $\mbarA$ の単位類とするとき、剰余類 $F\ma$ に属する。'
$p17New = '(11) により、任意の多項式 $F$ は、$\bara$ を $\mL$ を法とする $N$ の剰余類、したがって $\mbarA$ の単位類とするとき、$\mbarA$ において剰余類 $F\ma$ に属する。'
$reader = Replace-ExactInSpan $reader $p17a $p17b $p17Old $p17New 'P17-01'

$p32a = '\section*{32.'
$p32b = '\section*{33.'
$reader = Replace-ExactInSpan $reader $p32a $p32b '$a_i c=\gamma_{i1}a_1+\cdots+\gamma_{im}a_m$ とすれば、$(\gamma_{ik})$' '$a_i c=\gamma^i_1a_1+\cdots+\gamma^i_ma_m$ とすれば、$(\gamma^i_k)$' 'P32-01'
$reader = Replace-ExactInSpan $reader $p32a $p32b '\Pi\varepsilon=-1' '\Pi\cdot\varepsilon=-1' 'P32-02'

$p35a = '\section*{35.'
$p35b = '\section*{36.'
$reader = Replace-ExactInSpan $reader $p35a $p35b '$1/e$' '$1/c$' 'P35-01'
$reader = Replace-ExactInSpan $reader $p35a $p35b '領域 $\mathfrak{I}$ を定義する関数 $f_i(x)$ が' '領域 $\mathfrak{I}$ を定義する関数 $f''_1(x),\ldots,f''_r(x)$ が' 'P35-03'

$p06Old = @'
したがって $\Kfield^*_{\rho\rho}$ は、$\Omega(g_1^*,\ldots,g_\rho^*)$ に $\Kfield^*_{\rho\rho}$ からの有限個の元を添加することによって、または適当に選ばれた一つの関数を添加することによって得られる。すなわち有理基底が存在する。転移原理によって次を得る。

\emph{定理 II: 任意の体 $\Kfield_{n\rho}$ は有理基底をもつ。}
'@
$p06New = @'
したがって $\Kfield^*_{\rho\rho}$ は、$\Omega(g_1^*,\ldots,g_\rho^*)$ に $\Kfield^*_{\rho\rho}$ からの有限個の元を添加することによって、または適当に選ばれた一つの関数を添加することによって得られる。すなわち
\[
\Kfield^*_{\rho\rho}
=\Omega(g_1^*,\ldots,g_\rho^*,g_{\rho+1}^*,\ldots,g_k^*)
=\Omega(g_1^*,\ldots,g_\rho^*,g_0^*)
\]
が成り立つ。転移原理によって次を得る。

\emph{定理 II: 任意の体 $\Kfield_{n\rho}$ は代数階数 $\rho$ の有理基底をもち、その有理基底は高々 $\rho+1$ 個の関数からなるように選べる。}

$\Kfield_{n\rho}$ から任意に選んだ $\rho$ 個の代数的に独立な関数 $h_1(x),\ldots,h_\rho(x)$ は、上の方法によって有理基底
\[
h_1(x),\ldots,h_\rho(x);\ h_{\rho+1}(x),\ldots,h_\sigma(x)
\]
へ拡張できる。定義により関係式
\[
\begin{array}{ll}
h_i(x)=\chi_i\bigl(g_1(x),\ldots,g_k(x)\bigr)&(i=1,2,\ldots,\sigma),\\
g_j(x)=\psi_j\bigl(h_1(x),\ldots,h_\sigma(x)\bigr)&(j=1,2,\ldots,k)
\end{array}
\]
が存在する。ここで $\chi_i,\psi_j$ はそれぞれの引数の有理関数である。したがって、任意の一つの有理基底から、他のすべての有理基底が双有理変換によって得られる。また、$h_1(x),\ldots,h_\rho(x)$ が $\Kfield_{n\rho}$ の任意の $\rho$ 個の代数的に独立な関数であるなら、$\Kfield_{n\rho}$ は
\[
\Omega\bigl(h_1(x),\ldots,h_\rho(x)\bigr)
\]
上の有限代数拡大である。
'@
$reader = Replace-Exact $reader $p06Old.Trim("`r", "`n") $p06New.Trim("`r", "`n") 'P06-07'
$reader = Replace-Exact $reader 'H^*(x)=M^*(x)\pmod{x_0}' 'H^*(x)\equiv M^*(x)\pmod{x_0}' 'P06-08'
$reader = Replace-ExactInSpan $reader '{\Large\bfseries 6.' '\section*{7.' 'K_\nu^*(x)' 'K_i^*(x)' 'P06-09' 3

$p32NoteA = '\footnote{その後 R. Brauer'
$p32NoteB = '\subsection*{3. 四元数体の分解体の初等的取り扱い}'
$reader = Replace-ExactInSpan $reader $p32NoteA $p32NoteB 'P(\Theta)' 'P(\Xi)' 'P32-03a' 2
$reader = Replace-ExactInSpan $reader $p32NoteA $p32NoteB 'f(\Theta)' 'f(\Xi)' 'P32-03b'
$reader = Replace-ExactInSpan $reader $p32NoteA $p32NoteB '\Theta' '\Xi' 'P32-03c' 6
$reader = Replace-ExactInSpan $reader $p32NoteA $p32NoteB '\beta' '\ell' 'P32-03d' 4

$p35Final = @'
\noindent\textbf{系.}
\emph{$K$ の整数 $\alpha$ が有限個の例外素イデアルのいずれによっても割られないなら、$\alpha\cdot g(x)$ が $\mathfrak{I}$ に属し、$g(x)$ が $\mathfrak{Z}$ に属することから、常に $g(x)$ が $\mathfrak{I}$ に属することが従う。}

$K$ の整数 $\lambda_1,\ldots,\lambda_s$ を、それぞれ一つの例外素イデアルで割られるが、その平方でも他の例外素イデアルでも割られないように選べば、分母 $\alpha$ としてはこれらの $\lambda$ の冪積で十分である。

\noindent\emph{証明.}
$(\alpha)=\mathfrak{p}_1^{\varrho_1}\cdots\mathfrak{p}_g^{\varrho_g}$ を $\alpha$ の素イデアル分解とし、$\mathfrak{p}_1,\ldots,\mathfrak{p}_g$ は例外素イデアルではないとする。したがって各 $\mathfrak{p}_i$ について $\mathfrak{I}_{\mathfrak{p}_i}$ は $\mathfrak{o}_{\mathfrak{p}_i}/\mathfrak{a}_{\mathfrak{p}_i}$ と同型である。$K$ のすべての整数の環から、$(\alpha)$ によって定められる商環 $\mathfrak R$ へ移る。これは、$(\alpha)$ と素、すなわち $\mathfrak{p}_1,\ldots,\mathfrak{p}_g$ のいずれによっても割られない整数を、かつそれらだけを分母に加えることによって得られる。$\mathfrak R$ では $\mathfrak{p}_1,\ldots,\mathfrak{p}_g$ は素イデアルのままであるが主イデアルになり、他のすべての素イデアルは単位イデアルになる。また $(\alpha)$ の分解は同じまま残る。\footnote{例えば H. Grell, ``Zur Theorie der Ordnungen in algebraischen Zahl- und Funktionenkörpern'', Math. Ann. 97 (1927), pp. 524--558, \S\,2.1 を参照。} したがって、係数領域を $\mathfrak R$ に移しても、系とその証明は \S\,2.3 の形そのままで保たれる。

つまり、$\alpha\cdot g(x)$ が $\mathfrak{I}$ に属するなら、$g(x)=F(f_i(x))$ となり、ここで多項式 $F(u)$ の係数は $\mathfrak R$ に属する。これらの係数の共通分母を $\delta$ とすれば、$\delta$ は $\alpha$ と素である。したがって次の形にも言い換えられる。$\alpha\cdot g(x)$ が $\mathfrak{I}$ に属すれば、$\alpha$ と素な $\delta$ について $\delta\cdot g(x)$ が $\mathfrak{I}$ に属する。ゆえに $(\delta,\alpha)$ は単位イデアルであり、その結果、$\alpha\cdot g(x)$ が $\mathfrak{I}$ に属することから $g(x)$ が $\mathfrak{I}$ に属することが従う。これで上の系の第一主張が証明された。

第二主張を証明するため、$\mathfrak R^*$ を有限個の例外素イデアルによって $K$ 内に定められる商環とし、$\lambda_1,\ldots,\lambda_s$ を $\mathfrak R^*$ におけるこれらの素イデアルの基底元とする。これらは整数として取ってよい。$\mathfrak R^*$ では、$\alpha$ は $\mathfrak R^*$ の単元を除いて $\lambda$ の冪積になる。整数へ戻ると
\[
\gamma\alpha=\beta\lambda_1^{\varrho_1}\cdots\lambda_s^{\varrho_s}
\]
が得られる。ただし $\gamma$ と $\beta$ は、どの例外素イデアルによっても割られない。$\alpha\cdot g(x)$ が $\mathfrak{I}$ に属するなら、$\beta\lambda_1^{\varrho_1}\cdots\lambda_s^{\varrho_s}g(x)$ が $\mathfrak{I}$ に属し、さらに系の第一主張により $\lambda_1^{\varrho_1}\cdots\lambda_s^{\varrho_s}g(x)$ も $\mathfrak{I}$ に属する。

'@
$reader = Replace-RegexInSpan $reader $p35a $p35b '\\noindent\\textbf\{系\.\}\n\\emph\{\$K\$ の整数 \$a\$ が有限個の例外素イデアル.*?(?=\\begin\{center\}\n（1931年11月11日受理）)' $p35Final 'P35-02'

$p38a = '\section*{38.'
$p38b = '\section*{39.'
$p38BlockA = @'
\paragraph{3.}
第三の還元は、H. Hasse が――最初の二つの還元を得たのち――最終的な証明へ導くものと認識したものであり、H. Hasse の知らせを契機として E. Noether が与えた。その知らせでは、可換分解体という特別な場合の主定理が、一般的な還元 1 と、それに属する因子系の公式による還元とを用いて証明されていた。E. Noether はその核心として、まさに第三の還元を取り出した。なお R. Brauer も、E. Noether とは独立に、この第三の還元をすでに考えていた。

\paragraph{還元 3.}
定理 II は次を示せば証明される：
\[
\text{III. 素数次数の巡回分解体をもち、至る所分解する }\Omega\text{ 上の任意の代数は }\sim\Omega\text{ である。}
\]

\paragraph{証明.}
\(A\) を、\(\Omega\) 上で可解な分解体 \(K\) をもち、至る所分解する代数とする。
\[
K=\Lambda_0\supset\Lambda_1\supset\cdots\supset\Lambda_r=\Omega
\]
を、\(K\) と \(\Omega\) の間の体の鎖で、各 \(\Lambda_i/\Lambda_{i+1}\) が素数次数の巡回拡大であるものとする。まず \(A_{\Lambda_1}\) は \(\Lambda_1\) 上で同じく至る所分解し、素数次数の巡回分解体 \(K=\Lambda_0\) をもつ。III がすべての \(\Omega\) について既知であれば、\(A_{\Lambda_1}\sim\Lambda_1\) である。これは \(\Lambda_1\) が \(A\) の分解体であることを意味する。そこで \(\Lambda_0\) の代わりに \(\Lambda_1\) から出発して同じ議論を行えば \(A_{\Lambda_2}\sim\Lambda_2\) を得る。以下同様にして、最後には \(A_{\Lambda_r}\sim\Lambda_r\)、すなわち \(A\sim\Omega\) を得る。従って III を仮定すれば II が証明される。

\paragraph{4.}
ところが III は H. Hasse の結果 [H, 24] によって既に成り立っている。したがって、還元 3, 2, 1 を逆にたどれば主定理の正しさが従う。

E. Noether はさらに次の点を指摘している。III の正しさ――より一般には、任意次数の巡回分解体に対する正しさ――は Hasse のノルム定理\footnote{H, 3.11 に引用され、H. Hasse, \emph{Beweis eines Satzes und Widerlegung einer Vermutung über das allgemeine Normenrestsymbol}, Gött. Nachr. 1931 で証明されている。}に帰着する。しかし還元 3 に必要なのは素数次数の場合、すなわちもとの Hilbert--Furtwängler のノルム定理\footnote{H. Hasse, \emph{Bericht über neuere Untersuchungen und Probleme in der Theorie der algebraischen Zahlkörper II}, Jahresber. der D. M.-V., Erg.-Bd. 6 (1930), § 8、およびそこで引用される文献を参照。}だけである。従って還元 III は Hasse のノルム定理の新しい簡明な証明を与える。その証明は次のようになる。

\(Z\) を \(\Omega\) 上の巡回体、\(\alpha\) を \(\Omega\) の数とし、\(\Omega\) の各素点 \(\mathfrak p\) に対してノルム剰余記号が
\[
\left(\frac{\alpha,Z}{\mathfrak p}\right)=1
\]
であるとする。このとき巡回代数
\[
A=(\alpha,Z)
\]
\footnote{H, 1 の記法である。\(\alpha\) と結び付く \(Z\) の自己同型 \(S\) の指定は、ここでは本質的でないため省略した。}は至る所分解する [H, 17.7]。従って還元 3 により――Hilbert--Furtwängler のノルム定理だけを用いて――\(A\sim\Omega\) となる。ゆえに \(\alpha\) は \(Z\) の元のノルムである [H, 15.4]。

さらにノルム定理との関連で、定理 I は、高次の場合（非可換の場合をも含む）へのその正しい一般化とみなすべきである。一方、字義どおりの一般化は、H. Hasse が示したように、一般には正しくない。

'@
$reader = Replace-RegexInSpan $reader $p38a $p38b '\\paragraph\{3\.\}\n.*?(?=\\paragraph\{5\.\})' $p38BlockA 'P38-01'

$p38BlockB = @'
有限素点 \(\mathfrak p\) について、
\[
        A_{\mathfrak p}\sim(\pi,W_{\mathfrak p})
\]
を \(A_{\mathfrak p}\) の算術的に特別な巡回表示とする [H, 16; Hasse, loc. cit., Satz 38 も参照]。ここで \(W_{\mathfrak p}\) は \(\Omega_{\mathfrak p}\) 上次数 \(m_{\mathfrak p}\) の不分岐体、\(\pi\in\Omega_{\mathfrak p}\) はちょうど \(\mathfrak p^1\) で割り切れる数である。さらに \(K_{\mathfrak P_i}W_{\mathfrak p}\) を合成体とし、
\[
        \Delta_{\mathfrak P_i}=K_{\mathfrak P_i}\cap W_{\mathfrak p}
\]
を \(W_{\mathfrak p}\) と \(K_{\mathfrak P_i}\) の交わりとする。\(K_{\mathfrak P_i}\) に含まれる最大の不分岐部分体は \(\Omega_{\mathfrak p}\) 上次数 \(f_{\mathfrak P_i}\) であり、また \(\Omega_{\mathfrak p}\) 上では各次数について不分岐体が一意であるから、\(\Delta_{\mathfrak P_i}\) は
\[
        \text{\(\Omega_{\mathfrak p}\) 上次数 }d_{\mathfrak P_i}=(m_{\mathfrak p},f_{\mathfrak P_i})
\]
をもつ。従って \(K_{\mathfrak P_i}W_{\mathfrak p}\) は \(K_{\mathfrak P_i}\) 上次数 \(m_{\mathfrak p}/d_{\mathfrak P_i}\) の不分岐拡大である。

いま
\[
        A_{K_{\mathfrak P_i}}=(A_{\mathfrak p})_{K_{\mathfrak P_i}}
        \sim(\pi,K_{\mathfrak P_i}W_{\mathfrak p})
\]
である [H, 15.5]。従って \(A_{K_{\mathfrak P_i}}\sim K_{\mathfrak P_i}\) であることは、\(\pi\) が \(K_{\mathfrak P_i}W_{\mathfrak p}\) から \(K_{\mathfrak P_i}\) へのノルムであることと同値である。拡大 \(K_{\mathfrak P_i}W_{\mathfrak p}/K_{\mathfrak P_i}\) は不分岐であるから、これは \(\pi\) の \(\mathfrak P_i\) における位数 \(e_{\mathfrak P_i}\) が次数 \(m_{\mathfrak p}/d_{\mathfrak P_i}\) の倍数であることと同値である。また
\[
\left(\frac{m_{\mathfrak p}}{d_{\mathfrak P_i}},
      \frac{f_{\mathfrak P_i}}{d_{\mathfrak P_i}}\right)=1
\]
であるから、これはさらに
\[
\frac{f_{\mathfrak P_i}}{d_{\mathfrak P_i}}e_{\mathfrak P_i}
 =\frac{n_{\mathfrak P_i}}{d_{\mathfrak P_i}}
\]
が \(m_{\mathfrak p}/d_{\mathfrak P_i}\) の倍数であること、すなわち \(n_{\mathfrak P_i}\) が \(m_{\mathfrak p}\) の倍数であることと同値である。これが主張である。

\(\mathfrak p\) が無限素点で、自明な場合 \(m_{\mathfrak p}=1\) でないときには、\(m_{\mathfrak p}=2\) であり、\(A_{\mathfrak p}\) は実数体 \(\Omega_{\mathfrak p}\) 上の四元数代数である。このとき \(A_{K_{\mathfrak P_i}}=(A_{\mathfrak p})_{K_{\mathfrak P_i}}\sim K_{\mathfrak P_i}\) であることは、\(K_{\mathfrak P_i}\) が複素数体であること、すなわち
\[
        n_{\mathfrak P_i}=f_{\mathfrak P_i}=2=m_{\mathfrak p}
\]
であることと同値である（ここでは \(e_{\mathfrak P_i}\) は現れない）。従ってここでも同じ主張を得る（\(n_{\mathfrak P_i}\) は \(m_{\mathfrak p}\) と同様に 1 または 2 しか値をとらない）。

'@
$reader = Replace-RegexInSpan $reader $p38a $p38b '有限素点.*?について，\n.*?(?=\\paragraph\{7\.\})' $p38BlockB 'P38-02'
$reader = Replace-ExactInSpan $reader $p38a $p38b 'A^f\sim\Omega' 'A_{\mathfrak p}^{\,f}\sim\Omega_{\mathfrak p}' 'P38-03'
$reader = Replace-ExactInSpan $reader $p38a $p38b 'その判別式は \(n^h\) を割る。なぜなら \(n\) は \(G_i\) の非極大オーダーの判別式を割るからである。' 'その絶対判別式は \(n^n\) を割る。なぜなら \(n^n\) は群環 \(G\) の（非極大）オーダーの判別式だからである。' 'P38-04'

$p42Start = '\section*{42.'
$p42End = '\section*{43.'
$reader = Replace-ExactInSpan $reader $p42Start $p42End 'K=\Gg\times k' 'K=\Gg\ast k' 'P42-01'
$p42RelOld = @'
        E_\Gg u_S=u_S E_\Gg=E_\Gg,                            \tag{1}
\]
\[
'@
$p42RelNew = @'
        E_\Gg u_S=u_S E_\Gg=E_\Gg,                            \tag{1}
\]
ここで \(S\) は \(\Gg\) のすべての元を走る。すなわち \(E_\Gg\) によって \(\Gg\) の単位表現が生成される。\footnote{\(k\) の標数が \(n\) を割らない場合には、\(\frac1nE_\Gg\) が単位表現の冪等元となる。しかし標数が \(n\) を割る場合にも \(K\) の標準形は成り立ち、唯一の仮定は \(k/\Omega\) が分離的であることである。}
\[
'@
$reader = Replace-ExactInSpan $reader $p42Start $p42End $p42RelOld.Trim("`r", "`n") $p42RelNew.Trim("`r", "`n") 'P42-02'

$p42BlockA = @'
いま \(\Omega\) の標数が零であるとする。分裂代数の表示 \(K=kE_\Gg k\) は、\(k\) が \(K/\Omega\) の非ガロア分解体である場合にも有効なままである。これはガロア分解体へ移ることによって示される。\(\bar k\) を \(k\) に属するガロア体、\(\bar\Gg\) をその群、\(\bar u_S\) を対応する作用素、\(\bar K=\bar kE_{\bar\Gg}\bar k\) を分裂接合積とする。部分体 \(k\) は位数 \(h\) の部分群 \(\Hh\) に属するとする。次のようにおく。
\[
        \bar\Gg=\Hh S_1+\cdots+\Hh S_n
              =S_1^{-1}\Hh+\cdots+S_n^{-1}\Hh,
        \qquad
        E_\Hh=\frac1h\sum_{H\in\Hh}\bar u_H,
\]
および
\[
        E_\Gg=\frac1h E_{\bar\Gg}
              =\sum_i u_{S_i},\qquad
        u_{S_i}=E_\Hh\bar u_{S_i}.
\]
すると、とくに冪等元 \(E_\Hh\) は \(\Hh\) の単位表現を生成し、\(E_\Gg\) も \(E_{\bar\Gg}\) と同様に \(\bar\Gg\) の単位表現を生成する。このように定義された \(E_\Gg\) と \(u_{S_i}\) に対して、関係 (1) は一方の側について、関係 (2) は完全に成り立つ。ここで \(z\) は \(k\) のすべての元を走り、従って \(z^S\) は共役体 \(k^S\) のすべての元を走る。\(k^S\) は \(\bar k\) の部分体として \(\bar K\) の部分体でもある。まず
\[
        E_\Gg=E_\Gg E_\Hh=E_\Hh E_\Gg=E_\Hh E_\Gg E_\Hh,       \tag{3}
\]
\[
        zE_\Hh=E_\Hh z,                                      \tag{4}
\]
従って
\[
        z u_{S_i}=u_{S_i}z^{S_i}                               \tag{5}
\]
である。(3) は、\(E_{\bar\Gg}\) については \(E_\Hh\) の定義と (1) から成り立ち、従って \(E_\Gg\) についても成り立つ。一方 (4) は、\(z\) が \(k\) の元であるため \(\Hh\) の置換を許すこと、すなわち \(z\bar u_H=\bar u_Hz\) をいう。(4) の右から \(\bar u_{S_i}\) を掛ければ (5) を得る。さらに (1) は一方の側について
\[
        E_\Gg u_{S_i}=E_\Gg,
        \qquad
        E_\Gg u_{S_i}=E_\Gg E_\Hh\bar u_{S_i}
        =E_\Gg\bar u_{S_i}=E_\Gg                              \tag{1'}
\]
として成り立つ。(2a) は (5) を総和して得られ、そこから (1') により (2b) が従う。

\(K=kE_\Gg k\) の証明は今や 1 とまったく同じである。実際、\(\bar a_iE_\Gg a_k\) が行列単位であることの証明に用いたのは (2b) だけであった。\(\Omega\) 上の全行列環として、\(K\) は任意の \(n\) 次体を部分体として含み、とくに \(k\) を含む。

§3 のために、\(K\) が分裂しない場合にも \(K\) から \(\bar K\) への移行が可能であることを付け加える。\footnote{ここから非ガロアの場合の接合積表示の類似物が得られる。この点は、おそらくなお学位論文で詳述されるであろう。} \(k\) のほかに \(\bar k\) も分解体であるから、\(K\) は \(\bar\Gg\) と \(\bar k\) との接合積 \(\bar K\) に相似である。\(k\) は分解体であるため、\(k\) に対応する部分群 \(\Hh\) には因子系一が対応し、従って冪等元 \(E_\Hh\) は上と同じように定義される。逆にここから、\(K\) は \(E_\Hh\bar K E_\Hh\) と同型であることが従う。この代数は左イデアル \(\bar K E_\Hh\) の自己同型環と同型であり、従って \(\bar K\) と相似である。その階数は \(K\) の階数と一致する。実際、\(\bar K E_\Hh\) は \(\bar k\) 上階数 \(n\) であり（\(\bar u_{S_i}^{-1}E_\Hh\) は \(\bar k\) 上一次独立である）、\(\bar K\) は階数 \(nh\) である。すなわち \(\bar K\) は \(\bar K E_\Hh\) と同型な \(h\) 個のイデアルに分解し、自己同型環に対しては次数 \(h\) の全行列代数を掛けることになる。

\(K\)、従って \(\bar K\) が分裂する場合には、この方法で 2 の結果を再び得る。実際、
\[
\begin{aligned}
        E_\Hh\bar K E_\Hh
        &=E_\Hh\bar kE_{\bar\Gg}\bar kE_\Hh\\
        &=(E_\Hh\bar kE_\Hh)E_{\bar\Gg}(E_\Hh\bar kE_\Hh)\\
        &=\Sp(\bar k/k)E_\Hh E_{\bar\Gg}E_\Hh\Sp(\bar k/k)\\
        &=kE_\Gg k.
\end{aligned}
\]

'@
$reader = Replace-RegexInSpan $reader $p42Start $p42End 'いま .*?の標数が零であるとする。.*?(?=\\subsection\*\{§II\.)' $p42BlockA 'P42-03'

$p42BlockB = @'
\paragraph{定理 1.}
加群積
\[
        \mathcal O_a=\bar a E_\Gg a
\]
は \(K\) の極大オーダーである。とくに
\[
        \mathcal O=\mathcal O_o=\bar oE_\Gg o
\]
は極大オーダーである。

\paragraph{定理 2.}
\(\mathcal O\) から \(\mathcal O_a\) への変換は、\(\mathcal O\) に関する左イデアル
\[
        \mathcal L=\bar oE_\Gg a
\]
およびその逆右イデアル
\[
        \mathcal R=\bar aE_\Gg o
\]
によって行われる。

'@
$reader = Replace-RegexInSpan $reader $p42Start $p42End '\\paragraph\{定理 1\.\}\n.*?(?=\\paragraph\{注意。\})' $p42BlockB 'P42-04'
$reader = Replace-ExactInSpan $reader $p42Start $p42End '        aE_\Gg b' '        \bar aE_\Gg b' 'P42-05'

$p42Lemma = @'
\paragraph{補題。}
\(\mathcal C\) はすべての拡大加群 \(\mathcal C_p\) の交わりである。実際、\(w\) が \(\mathcal C_p\) に属するならば、\(p\) で割れない \(\sigma\in\oo\) があって \(\sigma w\in\mathcal C\) となる。\(w\) がすべての \(\mathcal C_p\) の交わりに属し、\(g\) を \(\sigma w\in\mathcal C\) を満たすすべての \(\sigma\in\oo\) からなるイデアルとすれば、いま示したように \(g\) はどの \(p\) でも割れない。従って \(g=\oo\) である。\footnote{素点を \(p\)-進拡大によって定義するならば、対応する補題は「すべての \(p\)-進成分 \(\mathcal C^{(p)}\) と \(K\) との交わりは \(\mathcal C\) に等しい」となる。これは \([\mathcal C^{(p)},K]=\mathcal C_p\) から従う。この等式は、\(\mathcal C_p\) の \(\oo_p\)-基底であって同時に \(\mathcal C^{(p)}\) の基底となるものを用いれば分かる。H, Satz 66 では、この補題は（最大階数の）イデアルについてのみ述べられている。} この補題は加群が最大階数をもつことを仮定しない。

'@
$reader = Replace-RegexInSpan $reader $p42Start $p42End '\\paragraph\{補題。\}\n.*?(?=\\paragraph\{系。\})' $p42Lemma 'P42-06'

$p42Proof1 = @'
\paragraph{定理 1 の証明。}
\(\mathcal O_a\) はオーダーである。実際、\(a\) と \(\bar a\) が有限 \(\oo\)-加群なので \(\mathcal O_a\) も有限 \(\oo\)-加群であり、しかも最大階数をもつ。さらに
\[
\begin{aligned}
        \mathcal O_a^2
        &=\bar aE_\Gg a\,\bar aE_\Gg a\\
        &=\bar aE_\Gg a\,\Sp(\bar a a)
        \subseteq \bar aE_\Gg a=\mathcal O_a.
\end{aligned}
\]
ここで \(\Sp(\mathfrak c)\) は一般に、\(\mathfrak c\) の全要素のトレースからなる \(\oo\) のイデアルを意味する。極大性を示すには、上の系により、各成分の極大性を示せば十分である。\(\oo_p\) は主イデアル環であるから、\(a_p\) と \(\bar a_p\) は互いに相補的な基底 \(a_1,\ldots,a_n\) と \(\bar a_1,\ldots,\bar a_n\) をもつ。§1 により、積 \(\bar a_iE_\Gg a_k\) は行列単位をなす。従って
\[
        \mathcal O_{a,p}=\sum_{i,k}(\bar a_iE_\Gg a_k)\oo_p
\]
は極大である。\(\mathcal O_a\) が極大であるから、\(\Sp(\bar a a)=\oo\) も従う。

'@
$reader = Replace-RegexInSpan $reader $p42Start $p42End '\\paragraph\{定理 1 の証明。\}\n.*?(?=\\paragraph\{定理 2 の証明。\})' $p42Proof1 'P42-07'

$p42Proof2 = @'
\paragraph{定理 2 の証明。}
トレース規則から次を得る。
\[
\begin{aligned}
 \mathcal O\mathcal L&=\bar oE_\Gg o\,\bar oE_\Gg a=\bar oE_\Gg a=\mathcal L,\\
 \mathcal R\mathcal O&=\bar aE_\Gg o\,\bar oE_\Gg o=\bar aE_\Gg o=\mathcal R,\\
 \mathcal L\mathcal R&=\bar oE_\Gg a\,\bar aE_\Gg o=\bar oE_\Gg o=\mathcal O,\\
 \mathcal R\mathcal L&=\bar aE_\Gg o\,\bar oE_\Gg a=\bar aE_\Gg a=\mathcal O_a.
\end{aligned}
\]

'@
$reader = Replace-RegexInSpan $reader $p42Start $p42End '\\paragraph\{定理 2 の証明。\}\n.*?(?=\\paragraph\{定理 3 の証明。\})' $p42Proof2 'P42-08'

$p42Proof3 = @'
\paragraph{定理 3 の証明。}
\(\mathcal L\) を \(\mathcal O\) に関する左イデアルとする。このとき、とくに
\[
        \mathcal L=\bar oE_\Gg\mathcal L
        =(\bar oE_\Gg l_1,\ldots,\bar oE_\Gg l_t)
\]
である。ただし \(l_1,\ldots,l_t\) は、たとえば \(\mathcal L\) の \(\oo\)-基底である。\(l_\mu=\sum_i u_{S_i}z_{\mu,i}\)、\(z_{\mu,i}\in k\) とおくと、\footnote{\(k\) が非ガロアならば、\(z\) を \(\bar zE_\Hh\) で、従って \(a\) を \(\bar aE_\Hh\) で置き換えなければならない。このとき \(a\in k\) に対して
\[
E_\Gg l=E_\Gg\bar aE_\Hh=E_\Gg a
\]
を得る。実際、(3), (4), (5) により
\[
kE_\Gg k=kE_\Gg kE_\Hh=\sum_i u_{S_i}\{k^{S_i},k\}E_\Hh
\]
である。}
\[
        E_\Gg l_\mu=E_\Gg\sum_i z_{\mu,i}=E_\Gg a_\mu
\]
となり、従って \(\mathcal L=\bar oE_\Gg a\) である。正則な \(\mathcal L\) では \(a\) は最大階数 \(n\) をもたなければならず、そのとき \(\bar aE_\Gg o\) が逆右イデアルである。合成により、\(\bar aE_\Gg b\) は \(\mathcal O_a\) に関する左イデアルを尽くし、\(\bar bE_\Gg a\) はそれらに逆な右イデアルを尽くす。

'@
$reader = Replace-RegexInSpan $reader $p42Start $p42End '\\paragraph\{定理 3 の証明。\}\n.*?(?=\\paragraph\{定理 4 の証明。\})' $p42Proof3 'P42-09'
$p42End4 = 'これで \(t\) は \(a\) のオーダーに等しい。'
$p42End4New = $p42End4 + '\(a\) がとくに \(k\) のすべてのオーダーを走ることから、各オーダーが交わりとして実際に現れることも従う。変換についての主張は、いまや定理 3 から直ちに従う。'
$reader = Replace-ExactInSpan $reader $p42Start $p42End $p42End4 $p42End4New 'P42-10'

$p42Proof4a = @'
\paragraph{定理 4a の証明。}
この定理は定理 4 の主領域への特殊化にすぎない。まず出発する極大オーダーを \(\mathcal O=\bar oE_\Gg o\) とする。\(o\) が \(\mathcal L=\bar oE_\Gg a\) の右オーダーにも含まれるならば、\(\bar aE_\Gg a\) も主領域に属する。従って \(a\) は \(k\) のイデアルであり、\(\mathcal L=\mathcal Oa\) となる。\(\mathcal O_a\) から出発すれば、対応して \(\mathcal L=\bar aE_\Gg b\) となり、\(b\)、従って \(a^{-1}b\) は \(k\) のイデアルである。ゆえに \(\mathcal L=\bar aE_\Gg aa^{-1}b=\mathcal O_a a^{-1}b\) となる。

'@
$reader = Replace-RegexInSpan $reader $p42Start $p42End '\\paragraph\{定理 4a の証明。\}\n.*?(?=\\subsection\*\{§III\.)' $p42Proof4a 'P42-11'

# Source-visible frontmatter, notes, and late invariant-paper symbol repairs.
$reader = Replace-Exact $reader '{\Large\bfseries 4. $n$ 変数形式の不変式論について}\par' "{\Large\bfseries 4. `$n`$ 変数形式の不変式論について}\footnotemark\par`n\footnotetext{ザルツブルク自然科学者集会への短報を参照。\emph{Jahresbericht der Deutschen Mathematiker-Vereinigung}, Bd. 19, S. 101.}" 'P04-note1'
$reader = Replace-Exact $reader '\section*{\S\ 9. 形式列. 還元定理.}' '\section*{\S\ 9. 形式列. 還元定理.\footnote{三元領域における対応する考察を参照。学位論文 §§1--3。}}' 'P04-note2'
$p05HeadOld = @'
{\Large\bfseries 5. 有理関数体}\par
\vspace{1.2em}
\emph{Jahresbericht der DMV} 22 (1913), pp. 316--319
'@
$p05HeadNew = @'
{\Large\bfseries 5. 有理関数体\footnote{1913年ウィーン自然科学者集会で行われた講演。}}\par
\vspace{0.8em}
\textsc{Emmy Noether}（Erlangen）\\[0.5em]
\emph{Jahresbericht der DMV} 22 (1913), pp. 316--319
'@
$reader = Replace-Exact $reader $p05HeadOld.Trim("`r", "`n") $p05HeadNew.Trim("`r", "`n") 'P05-head'
$reader = Replace-ExactInSpan $reader '{\Large\bfseries 6.' '\section*{7.' 'R_0=a_0\ne0.' 'R_0=a_0\ne0.\footnote{Mertens, 前掲書 §5。}' 'P06-note'

$p37Start = '\section*{37.'
$p37End = '\section*{38.'
$p37Journal = '\emph{Journal f. d. reine u. angew. Math. 167 (1932), pp. 147--152}'
$reader = Replace-ExactInSpan $reader $p37Start $p37End $p37Journal ($p37Journal + "`n`n\textsc{Emmy Noether}（Göttingen）") 'P37-head'
$reader = Replace-ExactInSpan $reader $p37Start $p37End '\(\frakO\) および \(\frako_\frakp\)' '\(\frako\) および \(\frako_\frakp\)' 'P37-01'
$reader = Replace-ExactInSpan $reader $p37Start $p37End 'v_1,\ldots,v_l' 'v_1,\ldots,v_t' 'P37-02'
$reader = Replace-ExactInSpan $reader $p37Start $p37End '(K_\frakp)_\mathfrak P' '(K_\frakp)_P' 'P37-03' 3
$reader = Replace-ExactInSpan $reader $p37Start $p37End '\(\frakp_i\) は \(k_\varepsilon\) に、\(\mathfrak P_i\) は \(K_\varepsilon\) にある。' '\(\frakp\) は \(k_\varepsilon\) に、\(\mathfrak P\) は \(K_\varepsilon\) にある。' 'P37-04'
$reader = Replace-ExactInSpan $reader $p37Start $p37End '2\sqrt[5]{2}/\sqrt[5]{2^4}' '2\sqrt[5]{2}\cdot\sqrt[5]{2^4}' 'P37-05a'
$reader = Replace-ExactInSpan $reader $p37Start $p37End '\sqrt[5]{2^2}/\sqrt[5]{2^3}' '\sqrt[5]{2^2}\cdot\sqrt[5]{2^3}' 'P37-05b'
$reader = Replace-ExactInSpan $reader $p37Start $p37End '\sqrt[5]{2^3}/\sqrt[5]{2^2}' '\sqrt[5]{2^3}\cdot\sqrt[5]{2^2}' 'P37-05c'
$reader = Replace-ExactInSpan $reader $p37Start $p37End '\sqrt[5]{2^4}/(2\sqrt[5]{2})' '\sqrt[5]{2^4}\cdot(2\sqrt[5]{2})' 'P37-05d'

$p38Journal = '\emph{Journal f. d. reine u. angew. Math. 167 (1932), pp. 399--404}'
$p38Head = @'
\begin{center}
\textbf{代数論における主定理の証明}\\
R. Brauer（Königsberg）、H. Hasse（Marburg）、E. Noether（Göttingen）\footnote{本ノートの執筆は H. Hasse が担当した。}
\end{center}
'@
$reader = Replace-ExactInSpan $reader $p38a $p38b $p38Journal ($p38Journal + "`n`n" + $p38Head.Trim("`r", "`n")) 'P38-head'
$reader = Replace-ExactInSpan $reader $p38a $p38b '\footnote{このノートの執筆は H. Hasse が引き受けた。}' '' 'P38-head-dedup'
$reader = Replace-ExactInSpan $reader $p38a $p38b '\paragraph{5.}' "\begin{center}`n\textbf{帰結（H. Hasse）}`n\end{center}`n`n\paragraph{5.}" 'P38-conclusion'
$reader = Replace-ExactInSpan $reader $p38a $p38b '主定理から，第二の還元の動機となった問題への答えが直ちに得られる。' '以上によって、H. Hasse が代数的数体上の巡回代数について展開した理論は、正規単純代数、ことに正規斜体の一般的な構造論および不変量論としての意義を得た。とくに、まず次の定理が一般に証明された。' 'P38-05'

$p39Start = '\section*{39.'
$p39End = '\section*{40.'
$p39Journal = '\emph{Verhandl. Intern. Math.-Kongreß Zürich 1 (1932), pp. 189--194}'
$reader = Replace-ExactInSpan $reader $p39Start $p39End $p39Journal ($p39Journal + "`n`n\textsc{Emmy Noether（Göttingen）}") 'P39-head'
$reader = Replace-ExactInSpan $reader $p39Start $p39End 'a_{S,T}a_{ST,U}=a_{S,TU}\,a_{T,U}^{\,S}' 'a_{ST,R}\,a_{S,T}^{\,R}=a_{S,TR}\,a_{T,R}' 'P39-01'
$reader = Replace-ExactInSpan $reader $p39Start $p39End "a'_{S,T}=a_{S,T}\,\frac{c_S^{\,T}c_T}{c_{ST}}" '\bar a_{S,T}=a_{S,T}\frac{c_S^{\,T}c_T}{c_{ST}}' 'P39-02'
$reader = Replace-ExactInSpan $reader $p39Start $p39End '\frac{(c_S)(c_T)^S}{(c_{ST})}' '\frac{(c_S^{\,T})(c_T)}{(c_{ST})}' 'P39-03'
$p39ParaA = '分解代数に関する定理からの第二の帰結は'
$p39ParaB = '因子系の単位類には'
$reader = Replace-ExactInSpan $reader $p39ParaA $p39ParaB '\mathfrak G' '\mathfrak J' 'P39-04' 5

$p02Start = '{\Large\bfseries 2.'
$p02End = '{\Large\bfseries 3.'
$p02Schema = @'
\begingroup\small
\[
\begin{array}{c|c|c|c|c}
s_x^m t_x^n u_\sigma^\mu u_\tau^\nu
& (stu)
& (stu)^2
& \cdots
& \bigstar\\[0.3em]
(\sigma\tau x)
& t_\sigma,\ s_\tau
& t_\sigma(stu),\ s_\tau(stu)
& \cdots
& \vdots\\[0.3em]
(\sigma\tau x)^2
& t_\sigma(\sigma\tau x),\ s_\tau(\sigma\tau x)
& t_\sigma^2,\ t_\sigma s_\tau,\ s_\tau^2
& \cdots
& \vdots\\[0.3em]
\vdots&\vdots&\vdots&\ddots&\vdots\\[0.3em]
(\sigma\tau x)^\nu
& t_\sigma(\sigma\tau x)^{\nu-1},\ s_\tau(\sigma\tau x)^{\nu-1}
& t_\sigma^2(\sigma\tau x)^{\nu-2},\ t_\sigma s_\tau(\sigma\tau x)^{\nu-2},\ s_\tau^2(\sigma\tau x)^{\nu-2}
& \cdots
& \vdots\\[0.3em]
\vdots
& t_\sigma(\sigma\tau x)^\nu
& t_\sigma^2(\sigma\tau x)^{\nu-1},\ t_\sigma s_\tau(\sigma\tau x)^{\nu-1}
& \cdots
& \vdots\\[0.3em]
\vdots
& \vdots
& t_\sigma^2(\sigma\tau x)^\nu
& \cdots
& \vdots
\end{array}
\]
\endgroup
\begingroup\small
\[
\begin{array}{r@{\quad}c}
\bigstar\srcfnmark{*)}
&
\begin{array}{c|c|c}
(stu)^n & \cdots & \cdots\\[0.3em]
t_\sigma(stu)^{n-1},\ s_\tau(stu)^{n-1}
& s_\tau(stu)^n & \cdots\\[0.3em]
t_\sigma^2(stu)^{n-2},\ t_\sigma s_\tau(stu)^{n-2},\ s_\tau^2(stu)^{n-2}
& t_\sigma s_\tau(stu)^{n-1},\ s_\tau^2(stu)^{n-1}
& s_\tau^2(stu)^n .
\end{array}
\end{array}
\]
\endgroup
\srcfntext{*)}{ここで、および以下でも同様に、星印で示された下部は、図式の右上に同じ印で示された場所に接続する。}
'@
$reader = Replace-RegexInSpan $reader $p02Start $p02End '\\begingroup\\small.*?\\endgroup(?=\n\nここで、)' $p02Schema 'P02-01'

$p02Diag = @'
\[
\begin{array}{c@{\qquad}c@{\qquad}c}
\begin{array}{ccccc}
s_x^m u_\tau^\nu &&&&\\
&s_\tau&&&\\
&&s_\tau^2&&\\
&&&\ddots&\\
&&&&s_\tau^\nu
\end{array}
&\text{それぞれ}&
\begin{array}{ccccc}
t_x^n u_\sigma^\mu &&&&\\
&t_\sigma&&&\\
&&t_\sigma^2&&\\
&&&\ddots&\\
&&&&t_\sigma^\mu
\end{array}
\end{array}
\]
'@
$reader = Replace-RegexInSpan $reader $p02Start $p02End '(?<=この場合には、図式の対角項を形式列と呼ぶ：\n)\\\[.*?\\\](?=\n折り畳み)' $p02Diag 'P02-02'
$p02Study = @'
\[
(stu)^\mu u_\tau^{\nu-\varkappa}v_\tau^\varkappa s_x^m t_x^{\,n-\lambda}(tuv)^\lambda
=\sum_{p,r,\varrho} C'_{pr\varrho}
\bigl[s_\tau^\varrho(stu)^{\mu+r-\varrho}\bigr]_{\widehat{uv}^{\lambda-r+\varrho}v^{\varkappa-\varrho},\,w^p,\,(w=\widehat{xw})},
\]
'@
$reader = Replace-RegexInSpan $reader $p02Start $p02End '\\\[\n\(stu\)\^\\mu u_\\tau\^\{\\nu-\\kappa\}.*?\\\]' $p02Study 'P02-03'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '形式 $a_\eta^4$ (§ 10)' '形式 $a_\eta^3$ (§ 10)' 'P02-04'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '\varphi_\lambda^{*}' '\varphi_\lambda' 'P02-05'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '(bc\widehat{x}u)(bc\widehat{y}z)(bc\widehat{z}x)' '(bc\widehat{xy})(bc\widehat{yz})(bc\widehat{zx})' 'P02-06'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '$((a\theta u)^2)^{*}$ については' '$(a\theta u)^2$ については\footnote{Gordan--Kerschensteiner, loc. cit. p. 92.}' 'P02-07a'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '((abu)(acu))b_x^3' '(abu)(acu)^3b_x^3' 'P02-07b'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '\widehat{a}ux' '\widehat{au}x' 'P02-07c' 2
$reader = Replace-ExactInSpan $reader $p02Start $p02End '(a\theta u)^2\theta_y^2\theta_x^2' '(a\theta u)^2a_y^2\theta_x^2' 'P02-08'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '$(\A\A'' u)^2=a_\vartheta^2((a\A u)^2$' '$(\A\A'' u)^2\equiv a_\vartheta^2(a\A u)^2$' 'P02-09'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '[a_\vartheta]_{b^2}b' '[a_\vartheta]_{\widehat{ub^2}}b' 'P02-10'
$reader = Replace-ExactInSpan $reader $p02Start $p02End 'a_\vartheta^2(b\theta u)^2&=[a_\vartheta^2]_{ub^2}' 'a_\vartheta^2(b\theta u)^2&=[a_\vartheta^2]_{\widehat{ub^2}}' 'P02-11'
$reader = Replace-ExactInSpan $reader $p02Start $p02End 's_\nu^3u_xs_\nu=\frac13u_xs_\nu^4=\frac13Ju_x.' 's_\nu^3u_\nu s_x=\frac13u_xs_\nu^4=\frac13J\cdot u_x.' 'P02-12'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '\modu{u_x(s,\R,t,i,J)}' '\modu{(s,\R,t,i,J)}' 'P02-13'

$p02C = @'
\end{array}
\]
\[
\begin{array}{r@{\quad}c}
\text{C)}&
\begin{array}{c|c|c|c}
\cdot&\cdot&((\theta Hu),s,u)^2,\ ((\theta Hu)^2,s,u)&\bigstar\\[0.35em]
\cdot&((\vartheta\eta x),s,u)^2,\ (\theta Hu)s_\eta,\ (\theta_\eta su)&((\vartheta\eta x),s,u)^3,\ (\theta_\eta su)^2&\\[0.35em]
((\vartheta\eta x)^2,s,u)&\cdot&(\theta_\eta^2su)&\\[0.35em]
\cdot&(\theta_\eta(\vartheta\eta x)^2,s,u)&\cdot&
\end{array}
\end{array}
\]
\[
\begin{array}{c@{\quad}|c|c}
\bigstar&((\theta Hu),s,u)^3,\ ((\theta Hu)^2,s,u)^2&((\theta Hu),s,u)^4\\[0.45em]
&(H_\vartheta(\theta Hu),s,u)^2,\ (\theta_\eta(\theta Hu),s,u)^2,\ (\theta_\eta(\theta Hu)^2,s,u)&(\theta_\eta su)^4,\ (\theta_\eta(\theta Hu),s,u)^3\\[0.45em]
&\cdot&(\theta_\eta^2(\theta Hu),s,u)^2
\end{array}
\]
'@
$reader = Replace-RegexInSpan $reader $p02Start $p02End '\\text\{C\)\}& \(\(\\vartheta\\eta x\)\^2,s,u\),.*?\\end\{array\}\n\\\]' $p02C 'P02-14'
$p02A24 = @'
\end{array}
\]
\[
\text{A)}\quad
\begin{array}{c|c|c|c|c}
\cdot&\cdot&\cdot&((KHu)^2su)^2&\bigstar\\[0.35em]
\cdot&\cdot&(K_\eta su)^2&\cdot&\\[0.35em]
\cdot&\cdot&\cdot&\cdot&\\[0.35em]
((k\eta x)^3,s,u)&\cdot&\cdot&\cdot&\\[0.35em]
\cdot&(K_\eta(k\eta x)^3,s,u)&\cdot&\cdot&
\end{array}
\]
\[
\begin{array}{c@{\quad}|c|c}
\bigstar&((KHu)^2,s,u)^3&((KHu)^2,s,u)^4\\[0.45em]
&\cdot&(K_\eta(KHu)^2,s,u)^3
\end{array}
\]
\[
\begin{array}{rl}
'@
$reader = Replace-RegexInSpan $reader $p02Start $p02End '\\text\{A\)\}& \(\(k\\eta x\)\^3,s,u\).*?\\\\\[0\.3em\]\n(?=\\text\{B\)\})' $p02A24 'P02-15'
$p02Table1 = Get-LineBlock $deLines 3491 3516
$p02Table2 = Get-LineBlock $deLines 3534 3562
$reader = Replace-RegexInSpan $reader '表 I（90頁参照）' '表 II（90頁参照）' '\\begin\{tabular\}.*?\\end\{tabular\}' $p02Table1 'P02-table1'
$reader = Replace-RegexInSpan $reader '表 II（90頁参照）' $p02End '\\begin\{tabular\}.*?\\end\{tabular\}' $p02Table2 'P02-table2'

$p08Start = '\section*{8.'
$p08End = '\section*{9.'
$p08PolyOld = "g(\lambda,xy)=\sum G_i\lambda_1^{\nu_1}\lambda_2^{\nu_2}`n  x_1^{\alpha_1}x_2^{\alpha_2}y_1^{\beta_1}y_2^{\beta_2}"
$p08PolyNew = "g(\lambda,xy)=\sum G_i\lambda_1^{\varkappa_1}\lambda_2^{\varkappa_2}`n  x_1^{\varkappa_3}x_2^{\varkappa_4}y_1^{\varkappa_5}y_2^{\varkappa_6}"
$reader = Replace-ExactInSpan $reader $p08Start $p08End $p08PolyOld $p08PolyNew 'P08-01'
$reader = Replace-ExactInSpan $reader $p08Start $p08End '\sum \nu_1!\nu_2!\alpha_1!\alpha_2!\beta_1!\beta_2!\,G_i^2=0,' '\sum \varkappa_1!\varkappa_2!\cdots\varkappa_6!\,G_i^2=0,' 'P08-02'
$reader = Replace-ExactInSpan $reader $p08Start $p08End 'Z=\sum PH \pmod{\Delta}' 'Z\equiv\sum PH \pmod{\Delta}' 'P08-03'
$p08Lemma = @'
$h(x,y,z)$ は極形式なので、既知の $\Omega$ 過程を適用すると消滅する。これは微分方程式
\[
  \Delta\!\left(\frac{\partial}{\partial x},\frac{\partial}{\partial y},\frac{\partial}{\partial z}\right)h(xyz)
  -\left(\frac{\partial}{\partial x}\frac{\partial}{\partial y}\frac{\partial}{\partial z}\right)h(x,y,z)=0.\footnotemark
\]
\footnotetext{3. により、
\[
 c\cdot\Omega(h)=-\left(
 \frac{\partial}{\partial \xi}\frac{\partial}{\partial \eta}
 \left(\frac{\partial}{\partial\lambda_1}\frac{\partial}{\partial \xi}
 +\frac{\partial}{\partial\lambda_2}\frac{\partial}{\partial \eta}\right)
 \right)
 \left(x\frac{\partial}{\partial \xi}\right)^{\alpha-1}
 \left(y\frac{\partial}{\partial \eta}\right)^{\beta-1}
 \left[
 z\left(\frac{\partial}{\partial\lambda_1}\frac{\partial}{\partial \xi}
 +\frac{\partial}{\partial\lambda_2}\frac{\partial}{\partial \eta}\right)
 \right]^{p-1}\cdot g(\lambda;\xi,\eta)
\]
である。従って \(\Omega(h)\) は行列式因子が消滅するために消滅する。}
'@
$reader = Replace-RegexInSpan $reader $p08Start $p08End 'すなわち、極化として.*?\\footnote\{3\. の後には、.*?\}(?=\n\n恒等式)' $p08Lemma 'P08-04'

$reader = Replace-ExactInSpan $reader $p02Start $p02End '4)\quad 0&=a_\nu^2b_{\nu_1}^2(j\nu_1x),' '4)\quad 0&=a_\nu^2b_{\nu_1}^2(j\nu_1x),\qquad\text{（3) から）}' 'P02-dep-A4'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '5)\quad L_\vartheta(\theta Lu)&=-a_\nu b_\eta(bHu)^2+\frac34a_\nu^2(bHu)^2+\frac34\theta_\nu^2H,' '5)\quad L_\vartheta(\theta Lu)&=-a_\nu b_\eta(bHu)^2+\frac34a_\nu^2(bHu)^2+\frac34\theta_\nu^2H,\qquad\text{（2) から）}' 'P02-dep-A5'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '6)\quad L_\vartheta(\theta Lu)&=-6a_\nu b_\eta(bHu)^2+2a_\nu^2(bHu)^2-\frac12\theta_\nu^2H,' '6)\quad L_\vartheta(\theta Lu)&=-6a_\nu b_\eta(bHu)^2+2a_\nu^2(bHu)^2-\frac12\theta_\nu^2H,\qquad\text{（1) から）}' 'P02-dep-A6'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '7)\quad 0&=a_\nu(bHu)^2+f(aLu)^3+\theta_\nu H,' '7)\quad 0&=a_\nu(bHu)^2+f(aLu)^3+\theta_\nu H,\qquad\text{（1) から）}' 'P02-dep-A7'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '9)\quad 0&=(aHu)^2(bHu)^2+2(\theta Hu)^2H,' '9)\quad 0&=(aHu)^2(bHu)^2+2(\theta Hu)^2H,\qquad\text{（7) から）}' 'P02-dep-A89'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '10)\quad 0&=a_\eta(aHu)^2b_\eta(bHu)^2,' '10)\quad 0&=a_\eta(aHu)^2b_\eta(bHu)^2,\qquad\text{（5) と 6) から）}' 'P02-dep-A10'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '11)\quad 0&\equiv [a_\nu^2b_\eta(bHu)]_{\widehat{su^4}}.' '11)\quad 0&\equiv [a_\nu^2b_\eta(bHu)]_{\widehat{su^4}}.\qquad\text{（式 (30.)b から）}' 'P02-dep-A11'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '2)\quad 0&=\theta_\nu\theta_{\nu_1}+\frac12\theta(\theta Hu)^2.' '2)\quad 0&=\theta_\nu\theta_{\nu_1}+\frac12\theta(\theta Hu)^2.\qquad\text{（A1 と同様の直接計算）}' 'P02-dep-B12'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '4)\quad 0&=3\theta_\nu(aHu)^2+f(\theta Lu)^3+2\theta(aLu)^3,' '4)\quad 0&=3\theta_\nu(aHu)^2+f(\theta Lu)^3+2\theta(aLu)^3,\qquad\text{（1) と A6 から）}' 'P02-dep-B34'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '&0&=(aHu)^2(\theta Hu)^2,\\' '&0&=(aHu)^2(\theta Hu)^2,\qquad\text{（3), 4), A8 から）}\\' 'P02-dep-B5'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '6)\quad 0&=a_\nu\theta_\nu^2+\theta_\nu a_\nu^2+f\theta_\eta(\theta Hu)^2+\theta a_\eta(aHu)^2,' '6)\quad 0&=a_\nu\theta_\nu^2+\theta_\nu a_\nu^2+f\theta_\eta(\theta Hu)^2+\theta a_\eta(aHu)^2,\qquad\text{（式 17）}' 'P02-dep-B6'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '7)\quad 0&=\theta_\nu\theta_\nu^2+\theta\theta_\eta(\theta Hu)^2+\frac16fH_j,' '7)\quad 0&=\theta_\nu\theta_\nu^2+\theta\theta_\eta(\theta Hu)^2+\frac16fH_j,\qquad\text{［6 の導出と同様］}' 'P02-dep-B7'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '8)\quad 0&=a_\nu(j\nu x)^2+fH_j,' '8)\quad 0&=a_\nu(j\nu x)^2+fH_j,\qquad\text{（6 から）}' 'P02-dep-B8'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '9)\quad 0&=(aHu)^2(j\nu x)^2-2a_\nu H_j,' '9)\quad 0&=(aHu)^2(j\nu x)^2-2a_\nu H_j,\qquad\text{（8 から）}' 'P02-dep-B9'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '&0&=\theta H_j,\\' '&0&=\theta H_j,\qquad\text{（7 と 8 から）}\\' 'P02-dep-B10'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '12)\quad 0&=a_\nu^2\theta_\nu^2-\frac13(j\eta x)^2-\frac13(\D Hu)^2,' '12)\quad 0&=a_\nu^2\theta_\nu^2-\frac13(j\eta x)^2-\frac13(\D Hu)^2,\qquad\text{（式 18）}' 'P02-dep-B1112'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '13)\quad 0&=a_\nu^2\theta_\nu^3-\frac12a_\sigma,' '13)\quad 0&=a_\nu^2\theta_\nu^3-\frac12a_\sigma,\qquad\text{（式 20）}' 'P02-dep-B13'
$reader = Replace-ExactInSpan $reader $p02Start $p02End '&0&=a_\eta H_j.' '&0&=a_\eta H_j.\qquad\text{（§13 C）}' 'P02-dep-B14'

$p04Title = "{\Large\bfseries 4. `$n`$ 変数形式の不変式論について}\footnotemark\par`n\footnotetext{ザルツブルク自然科学者集会への短報を参照。\emph{Jahresbericht der Deutschen Mathematiker-Vereinigung}, Bd. 19, S. 101.}"
$reader = Replace-Exact $reader $p04Title ($p04Title + "`nErlangen の Frl. Emmy Noether による。") 'P04-author'
$reader = Replace-ExactInSpan $reader '\section*{7.' '\section*{8.' 'Math. Ann. 77 (1916), pp. 89--92' "Math. Ann. 77 (1916), pp. 89--92`n`nEmmy Noether（Erlangen）" 'P07-author'
$reader = Replace-Exact $reader '\emph{Math. Ann.} 78 (1918), pp. 221--229' "\emph{Math. Ann.} 78 (1918), pp. 221--229`n`nEmmy Noether（Göttingen）" 'P11-author'
$reader = Replace-Exact $reader 'Nachr. v. d. Ges. d. Wiss. zu Göttingen 1918, pp. 37--44' "Nachr. v. d. Ges. d. Wiss. zu Göttingen 1918, pp. 37--44`n`nEmmy Noether（Göttingen）" 'P12-author'
$p16HeadOld = @'
{\Large\bfseries 16. 形式論における級数展開について}\par
\vspace{1em}
\emph{Math. Ann.} 81 (1920), pp. 25--30
'@
$p16HeadNew = @'
{\Large\bfseries 16. 形式論における級数展開について}\par
\emph{（\emph{Math. Ann.} 77, p. 93 掲載の第 III 項への補遺および訂正。）}\\[0.4em]
Emmy Noether（Göttingen）\\[0.5em]
\emph{Math. Ann.} 81 (1920), pp. 25--30
'@
$reader = Replace-Exact $reader $p16HeadOld.Trim("`r", "`n") $p16HeadNew.Trim("`r", "`n") 'P16-head'

$p19Start = '\section*{19.'
$p19End = '\section*{20.'
$p19ProofA = '実際、$\ideal M=[\ideal B_1\cdots\ideal B_k]$ を'
$p19ProofB = 'このような表示を逐次的に得るためには'
$reader = Replace-ExactInSpan $reader $p19ProofA $p19ProofB '\ideal U_i' '\ideal A_i' 'P19-01' 6
$reader = Replace-ExactInSpan $reader $p19Start $p19End '\bar{\ideal R}\bar{\ideal L}^{*}\equiv0(\ideal R)' '\bar{\ideal R}\cdot\bar{\ideal L}^{*}\equiv0(\ideal R)' 'P19-02'
$reader = Replace-ExactInSpan $reader $p19Start $p19End 'x^2y^2=(xy)^2' 'x^2\cdot y^2=(xy)^2' 'P19-03'
$p19LateA = 'したがって、初等因子 $a_i$'
$p19LateB = '要約すれば'
$reader = Replace-ExactInSpan $reader $p19LateA $p19LateB 'r_\rho' 'r_e' 'P19-04' 2
$reader = Replace-ExactInSpan $reader $p19LateA $p19LateB '\mathfrak B_{\rho+1}' '\mathfrak B_{e+1}' 'P19-05' 4
$reader = Replace-ExactInSpan $reader $p19LateA $p19LateB 'r_\nu=s_\nu\le s_{\nu+1}\le\cdots\le s_i\le r_\nu' 'r_\nu=s_1\leqq\cdots\leqq s_\lambda\leqq r_\nu' 'P19-06'
$reader = Replace-RegexInSpan $reader $p19LateA $p19LateB '\\le(?!qq)' '\leqq' 'P19-07' 3

# Final checker-confirmed source synchronizations for Papers 38, 39, and 42.
$p38PrimeOld = @'
\mathfrak p\mathcal O_K=\prod_i \mathfrak P_i^{\,e_{\mathfrak P_i}},
        \qquad N\mathfrak P_i=\mathfrak p^{\,f_{\mathfrak P_i}}
'@
$p38PrimeNew = @'
\mathfrak p=\prod_i \mathfrak P_i^{\,e_{\mathfrak P_i}},
        \qquad N_{K\Omega}(\mathfrak P_i)=\mathfrak p^{\,f_{\mathfrak P_i}}
'@
$reader = Replace-ExactInSpan $reader $p38a $p38b $p38PrimeOld.Trim("`r", "`n") $p38PrimeNew.Trim("`r", "`n") 'P38-06'
$reader = Replace-ExactInSpan $reader $p38a $p38b '\mathfrak U' '\mathfrak A' 'P38-07'
$reader = Replace-ExactInSpan $reader $p38a $p38b '\mathfrak R_K' '\mathfrak K' 'P38-08' 8
$reader = Replace-ExactInSpan $reader $p38a $p38b '\mathfrak R_{K''}' '\mathfrak K''' 'P38-09' 3
$reader = Replace-ExactInSpan $reader $p38a $p38b '\subseteq' '\leqq' 'P38-10' 6
$p38SymbolsOld = 'さらに，\(\mathfrak p\) と \(\mathfrak p''\) におけるノルム剰余記号が位数 \(f\) の互いに逆の値をとり，\(Z\) の導手の他のすべての因子 \(\mathfrak q\) では対応する記号が \(1\) となるような \(\alpha\in\Omega\) を選ぶ。'
$p38SymbolsNew = @'
さらに、\(\alpha\in\Omega\) を、ノルム剰余記号
\[
\left(\frac{\alpha,Z}{\mathfrak p}\right)\quad\text{および}\quad
\left(\frac{\alpha,Z}{\mathfrak p'}\right)
\]
が位数 \(f\) の互いに逆の値をとり、\(Z\) の導手の他のすべての因子 \(\mathfrak q\) について
\[
\left(\frac{\alpha,Z}{\mathfrak q}\right)=1
\]
となるように選ぶ。
'@
$reader = Replace-ExactInSpan $reader $p38a $p38b $p38SymbolsOld $p38SymbolsNew.Trim("`r", "`n") 'P38-11'
$p38Rold = 'この \(\mathfrak r\) では，ノルム剰余記号の積定理，すなわち相互法則 [H, 3.8--10] により，記号は再び \(1\) である。代数'
$p38Rnew = @'
この \(\mathfrak r\) では、ノルム剰余記号の積定理、すなわち相互法則により、同じく
\[
\left(\frac{\alpha,Z}{\mathfrak r}\right)=1
\]
である [H, 3.8--10]。代数
'@
$reader = Replace-ExactInSpan $reader $p38a $p38b $p38Rold $p38Rnew.Trim("`r", "`n") 'P38-12'
$p38Six = @'
\paragraph{定理 6.}
有限群 \(\mathfrak G\) の絶対既約表現はすべて円分体で可能である。たとえば \(n=|\mathfrak G|\) とし、\(h\) を十分大きく取れば、\(n^h\) 乗根の体で常に可能である。

\paragraph{証明.}
\(\mathfrak G\) の有理群環 \(G\) へ移ると、\(\mathfrak G\) の絶対既約表現 \(\Gamma_i\) は、半単純代数 \(G\) の単純成分 \(G_i\) の絶対既約表現となる。それらの中心は対応する指標の体 \(\Omega_i\) である。\footnote{a) R. Brauer and E. Noether, \emph{Über minimale Zerfällungskörper irreduzibler Darstellungen}, Berl. Akad.-Ber. 1927, § 1; b) R. Brauer, \emph{Über Systeme hyperkomplexer Zahlen}, Math. Z. 30 (1929), Satz 3; c) E. Noether, \emph{Hyperkomplexe Größen und Darstellungstheorie}, Math. Z. 30 (1929), §§ 21, 24, 26 を参照。} \(\mathfrak G\) は有限であるから、これらは円分体であり、少なくとも \(n\) 乗根の体の部分体である。

定理 3 により、指標体 \(\Omega_i\) 上の巡回体 \(Z_i\) は、各素点 \(\mathfrak p\) における \(\mathfrak p\)-次数 \(n_{i\mathfrak p}\) が \(G_i\) の \(\mathfrak p\)-指数 \(m_{i\mathfrak p}\) の倍数であれば、\(G_i\) の分解体である。\(m_{i\mathfrak p}\ne1\) となるのは \(G_i\) の基本イデアルの素因子、したがって \(G_i\) の絶対判別式の素因子に限られる。その絶対判別式は \(n^n\) を割る。なぜなら \(n^n\) は群環 \(G\) の非極大オーダーの判別式だからである。\footnote{E. Noether, 注 12c の文献, § 26 を参照。} 従って問題となるのは \(n\) の素因子 \(\mathfrak p\) だけである。これらについて \(n_{i\mathfrak p}\) を \(m_{i\mathfrak p}\) の倍数にするには、\(\mathfrak p\) が \(Z_i\) でそれぞれ \(m_{i\mathfrak p}\) で割り切れる位数だけ分岐するよう指定すればよい。これは \(h\) を十分大きく取った \(n^h\) 乗根の体によって達成される。

'@
$reader = Replace-RegexInSpan $reader $p38a $p38b '\\paragraph\{Satz 6\.\}\n.*?(?=引用された Schur)' $p38Six 'P38-13'

$reader = Replace-ExactInSpan $reader $p39Start $p39End '\(G\)' '\(\Gg\)' 'P39-05' 6
$reader = Replace-ExactInSpan $reader $p39Start $p39End 'G^\ast' '\Gg^\ast' 'P39-06' 2
$reader = Replace-ExactInSpan $reader $p39Start $p39End 'S\in G' 'S\in\Gg' 'P39-07'
$reader = Replace-ExactInSpan $reader $p39Start $p39End "(5')\qquad a'=a\,N(c)." "(5')\qquad \bar a=a\cdot N(c)." 'P39-08'
$p39AssocOld = @'
\[
(4)\qquad a_{ST,R}\,a_{S,T}^{\,R}=a_{S,TR}\,a_{T,R}
\]
'@
$p39AssocNew = @'
\[
\begin{gathered}
(4)\qquad a_{ST,R}\,a_{S,T}^{\,R}=a_{S,TR}\,a_{T,R},\\
\text{（結合法則 }[u_Su_T]u_R=u_S[u_Tu_R]\text{ から）}
\end{gathered}
\]
'@
$reader = Replace-ExactInSpan $reader $p39Start $p39End $p39AssocOld.Trim("`r", "`n") $p39AssocNew.Trim("`r", "`n") 'P39-09'
$p39StructOld = 'この \(A\) が，因子系 \(a_{S,T}\) に関する \(K\) と \(\Gg\) の接合積である。\(A\) は \(k\) 上の正規単純代数であり，\(K\) は極大可換部分体，従って分解体となる。'
$p39StructNew = 'この \(A\) が、因子系 \(a_{S,T}\) に関する \(K\) と \(\Gg\) の接合積である。\(A\) は \(k\) 上の正規単純代数、したがって随伴斜体 \(D\) 上の次数 \(r\) の行列環 \(D_r\) であり、\(K\) は極大可換部分体、従って分解体となる。'
$reader = Replace-ExactInSpan $reader $p39Start $p39End $p39StructOld $p39StructNew 'P39-10'
$p39ClassOld = 'なぜなら，\(u_S\) の乗法定数として絶対イデアル類を用いることが許されるかどうかは，因子系条件に関わるからである。'
$p39ClassNew = 'なぜなら、\(u_S\) に絶対イデアル類を掛けることの一意性から言えるのは、変換量 \(c_S^{\,T}c_T/c_{ST}\)、すなわち元の因子系の単位類が、イデアル因子系の単位類に属することだけだからである。しかし既知の場合への特殊化が示すように、実際にはやや粗い類分けで十分である。そこで次のように定義する。'
$reader = Replace-ExactInSpan $reader $p39Start $p39End $p39ClassOld $p39ClassNew 'P39-11'

$reader = Replace-ExactInSpan $reader $p42Start $p42End '\mathcal O' '\mathfrak O' 'P42-12' 34
$reader = Replace-ExactInSpan $reader $p42Start $p42End '\mathcal L' '\mathfrak L' 'P42-13' 21
$reader = Replace-ExactInSpan $reader $p42Start $p42End '\mathcal R' '\mathfrak R' 'P42-14' 8
$reader = Replace-ExactInSpan $reader $p42Start $p42End 'c_{ij}c_{hk}' 'c_{ij}c_{lk}' 'P42-15a'
$reader = Replace-ExactInSpan $reader $p42Start $p42End '\bar a_hE_\Gg a_k' '\bar a_lE_\Gg a_k' 'P42-15b'
$reader = Replace-ExactInSpan $reader $p42Start $p42End '\Sp(a_j\bar a_h)' '\Sp(a_j\bar a_l)' 'P42-15c' 3
$reader = Replace-ExactInSpan $reader $p42Start $p42End '\delta_{jh}' '\delta_{jl}' 'P42-15d'
$p42FnOld = '\footnote{接合積の理論は、私の講義に従って、H. Hasse, \emph{Theory of cyclic algebras over an algebraic number field}, Trans. Amer. Math. Soc. 34 (1932) の第 II 節に再録されている。ここでは最初の基礎概念だけを用いる。Brandt の基礎は Hasse および以下の枠組みの中で新たに基礎づけられている。}'
$p42FnNew = '\footnote{接合積の理論は、私の講義に従って、H. Hasse, \emph{Theory of cyclic algebras over an algebraic number field}, Trans. Amer. Math. Soc. 34 (1932) の第 II 節に再録されている。ここでは最初の基礎概念だけを用いる。Brandt の極大オーダー論は、H. Hasse, \emph{Über $p$-adische Schiefkörper und ihre Bedeutung für die Arithmetik hyperkomplexer Zahlsysteme}, Math. Ann. 104 (1931)（以下 H と略記）に、さらに広い結果の枠内で詳しく叙述され、新たに基礎づけられている。}'
$reader = Replace-ExactInSpan $reader $p42Start $p42End $p42FnOld $p42FnNew 'P42-16'
$reader = Replace-ExactInSpan $reader $p42Start $p42End '以後、\(\Omega\) は有限代数的数体、' '以後、\(\Omega\) は有限代数的数体\footnote{本節の考察は、\(\Omega\) が一不定元の関数体である場合にも保たれる。}、' 'P42-17'
$reader = Replace-ExactInSpan $reader $p42Start $p42End 'したがって、各そのような素点で、したがって全体として、拡大イデアルが問題となる。' 'したがって、各そのような素点で、したがって全体として\footnote{H, §8、または先行する Hasse の論文（注4）を参照。}、拡大イデアルが問題となる。' 'P42-18'
$reader = Replace-ExactInSpan $reader $p42Start $p42End '主領域は常に存在する。これは、因子系を整と仮定すると' '主領域は常に存在する。\footnote{別証明は Hasse および Chevalley（注4、注3）にある。}これは、因子系を整と仮定すると' 'P42-19'

$p11Start = '{\Large\bfseries 11.'
$p11End = '{\Large\bfseries 12.'
$reader = Replace-ExactInSpan $reader $p11Start $p11End '\sigma_k(x)=\frac{G''_k(x)}{H_k(x)}' '\sigma_k(x)=\frac{G_k(x)}{H_k(x)}' 'P11-01'

$p29Start = '\section*{29.'
$p29End = '\section*{30.'
$reader = Replace-ExactInSpan $reader $p29Start $p29End 'P(x_1,\ldots,x_t,x_{t+1},\ldots,x_n)' 'P(x_1,\ldots,x_t;\,x_{t+1},\ldots,x_n)' 'P29-01'
$reader = Replace-ExactInSpan $reader $p29Start $p29End 'f_{k-1}+t_{k-1}f_k' 'f_{k-1}+t_{k-1}f_k;' 'P29-02'
$p29Hilbert = '\footnote{Hilbert, Über die vollen Invariantensysteme, § 1. Math. Ann. 42 (1893), pp. 313--373 を参照。}'
$reader = Replace-ExactInSpan $reader $p29Start $p29End $p29Hilbert '' 'P29-03a'
$p29HilbertAnchor = '求める環 $\mathfrak T=P[g_1(x),\ldots,g_t(x)]$ に到達する。'
$p29HilbertNew = '求める環 $\mathfrak T=P[g_1(x),\ldots,g_t(x)]$' + $p29Hilbert + ' に到達する。'
$reader = Replace-ExactInSpan $reader $p29Start $p29End $p29HilbertAnchor $p29HilbertNew 'P29-03b'

$p40Start = '\section*{40.'
$p40End = '\section*{41.'
$reader = Replace-ExactInSpan $reader $p40Start $p40End '\sum_i' '\sum' 'P40-01' 13
$reader = Replace-ExactInSpan $reader $p40Start $p40End 'A_f\times_P B_g=C_h' 'A_r\times B_s=C_t' 'P40-02'
$p40RankOld = 'より一般に、\(A_Z\simeq D_l\)、\(L\) が \(A\) の \(A_r\) への既約埋め込み、\(d^2\) が中心 \(Z\) 上の除法代数 \(D\) の階数 \((D:L)\) なら、'
$p40RankNew = 'より一般に \(A_\Lambda\sim D\) であり、\(L\) が \(\Lambda\) の \(A_r\) への既約埋め込みで、\(d^2\) が中心 \(L\) 上の除法代数 \(D\) の階数 \((D:L)\) であるなら、\(l\cdot d=m\cdot r\) となる。'
$reader = Replace-ExactInSpan $reader $p40Start $p40End $p40RankOld $p40RankNew 'P40-03a'
$p40RankDisplay = @'
\[
        l\,d=mr .
\]
'@
$reader = Replace-ExactInSpan $reader $p40Start $p40End $p40RankDisplay.Trim("`r", "`n") '' 'P40-03b'
$reader = Replace-ExactInSpan $reader $p40Start $p40End 'Z^{(i)}\subseteq\Gamma' 'Z^{(i)}\leqq\Gamma' 'P40-04'
$reader = Replace-ExactInSpan $reader $p40Start $p40End 'a\in Z_\Omega' 'a\in Z_Z' 'P40-05'
$reader = Replace-ExactInSpan $reader $p40Start $p40End 'Z_{(i)}' 'Z_{Z^{(i)}}' 'P40-06'
$reader = Replace-ExactInSpan $reader $p40Start $p40End 'それらは \(n\) 個の共役な拡大系 \(Z\Omega\) に属する。' 'それらは \(n\) 個の共役な拡大系 \(Z_{Z^{(i)}}\) に属する。' 'P40-07'
$reader = Replace-ExactInSpan $reader $p40Start $p40End '\(e\) はすでに \(Z\Omega\) に属し、従って \(e^S\) は \(Z^S\Omega\) に属する。' '\(e\) はすでに \(Z_Z\) に属し、従って \(e^S\) は \(Z_{Z^{(i)}}\) に属する。' 'P40-08'
$reader = Replace-ExactInSpan $reader $p40Start $p40End '\sum_{H\in\mathfrak H} e^H' '\sum e^H' 'P40-09'

$p04FullEight = @'
展開すると (7.) は次を与える。
\begin{equation}
\begin{aligned}
&\pair{v^{(1)}\cdots v^{(n-\sigma-\lambda)}s^{(1)}\cdots s^{(\sigma)}}
       {\alpha^{(1)}\cdots\alpha^{(n-\tau)}y^{(1)}\cdots y^{(\tau-\lambda)}} \\
&=\sum
\left|\begin{array}{ccc}
 v_{i_1}^{(1)}&\cdots&v_{i_{n-\lambda}}^{(1)}\\
 \vdots&&\vdots\\
 v_{i_1}^{(n-\sigma-\lambda)}&\cdots&v_{i_{n-\lambda}}^{(n-\sigma-\lambda)}\\
 s_{i_1}^{(1)}&\cdots&s_{i_{n-\lambda}}^{(1)}\\
 \vdots&&\vdots\\
 s_{i_1}^{(\sigma)}&\cdots&s_{i_{n-\lambda}}^{(\sigma)}
\end{array}\right|
\left|\begin{array}{ccc}
 \alpha_{i_1}^{(1)}&\cdots&\alpha_{i_{n-\lambda}}^{(1)}\\
 \vdots&&\vdots\\
 \alpha_{i_1}^{(n-\tau)}&\cdots&\alpha_{i_{n-\lambda}}^{(n-\tau)}\\
 y_{i_1}^{(1)}&\cdots&y_{i_{n-\lambda}}^{(1)}\\
 \vdots&&\vdots\\
 y_{i_1}^{(\tau-\lambda)}&\cdots&y_{i_{n-\lambda}}^{(\tau-\lambda)}
\end{array}\right|\\
&=\sum_{i,k,l}\eps\,q_{k_1\ldots k_{n-\sigma-\lambda}}
 S^{k_{n-\sigma-\lambda+1}\ldots k_{n-\lambda}}
 T_{l_1\ldots l_{n-\tau}}
 p^{l_{n-\tau+1}\ldots l_{n-\lambda}},
\end{aligned}
\tag{8}
\end{equation}
'@
$reader = Replace-RegexInSpan $reader '{\Large\bfseries 4.' '{\Large\bfseries 5.' '展開すると \(7\.\) は次を与える。\n\\begin\{equation\}.*?\\end\{equation\}' $p04FullEight 'P04-18'

$p06Five = @'
§4 で構成した各有理基底には、任意に選んだ出発関数に依存するという欠点があったが、ここでは\emph{体によって一意に定まる有理基底}の存在を示す。

§4 により、$\Omega(x_1\cdots x_\rho)$ は $\Kfield^*_{\rho\rho}$ 上の代数体、例えば次数 $i$ の代数体であり、
\[
\Kfield^*_{\rho\rho}(x_1\cdots x_\rho)=\Omega(x_1\cdots x_\rho)
\]
であるから、$\Kfield^*_{\rho\rho}$ に関して代数的な元 $x_1\cdots x_\rho$ を添加することによって生じる。そこで、根
\[
z=u_1x_1+u_2x_2+\cdots+u_\rho x_\rho=u(x)
\]
をもつ、$\Kfield^*_{\rho\rho}$ に関して既約な整関数 $\Phi^*(z,u)$ を考える。これは $z$ について $i$ 次である。さらに $\Phi^*(z,u)$ は、$[z-u(x)]$ と共役な量の積として、$z,u_1\cdots u_\rho$ に関する次数 $i$ の斉次形式であり、したがって $z^i$ の係数として $u$ に依存しない $\Kfield^*_{\rho\rho}$ の関数を含む。この最高係数を除して $1$ にすれば、既約関数 $\Phi^*(z,u)$ は一意に定まる。このように定義された斉次形式
'@
$reader = Replace-RegexInSpan $reader '{\Large\bfseries 6.' '\section*{7.' '前の議論から、体そのものによって定まる有理基底をさらに得る。.*?(?=\\begin\{equation\})' $p06Five 'P06-10'

$p19QB = @'
したがって、初等因子 $a_i$ の素数冪の最小公倍数としての一意表示は、$\mathfrak A$ を、ただ一つの素数の冪によって与えられる初等因子をもつ類 $\mathfrak Q$ の最小公倍数として表すことに対応する。記号で書けば
\[
 \mathfrak Q\sim(p^{r_1}\mid p^{r_2}\mid\cdots\mid p^{r_e}\mid0\mid\cdots\mid0),
 \qquad r_1\leqq r_2\leqq\cdots\leqq r_e.
\]
とくに階数 $\varrho$ が $n$ に等しいなら、非可換領域であるにもかかわらず、互いに素で、かつ互いに素な意味で既約な類への一意分解が得られる。

類 $\mathfrak Q$ はさらに、次の初等因子系に対応する類へ分解できる。
\[
\begin{gathered}
 \mathfrak B_1\sim(p^{r_1}\mid\cdots\mid p^{r_1}),\quad
 \mathfrak B_2\sim(1\mid p^{r_2}\mid\cdots\mid p^{r_2}),\quad \ldots;\\
 \mathfrak B_e\sim(1\mid\cdots\mid1\mid p^{r_e}\mid\cdots\mid p^{r_e}),\quad
 \mathfrak B_{e+1}\sim(1\mid\cdots\mid1\mid0\mid\cdots\mid0).
\end{gathered}
\]
ここで $\mathfrak B_\nu$ では、そのつど数 $1$ が $(\nu-1)$ 回現れる。例えば $r_1=r_2=\cdots=r_\mu=0$ なら、$\mathfrak B_1,\ldots,\mathfrak B_\mu$ は単位類に等しいので、分解から省かなければならない。$\varrho=n$ のときの $\mathfrak B_{e+1}$ についても同じである。さらに、例えば $r_\nu=r_{\nu+1}=\cdots=r_{\nu+\lambda}$ なら、$\mathfrak B_{\nu+1},\ldots,\mathfrak B_{\nu+\lambda}$ は $\mathfrak B_\nu$ の真の約数となり、これらも除かなければならない。残るものを $\mathfrak B_{i_1},\ldots,\mathfrak B_{i_k}$ と記し、これらがいま最短表示を与えるものとすれば、
\[
 \mathfrak Q=[\mathfrak B_{i_1},\ldots,\mathfrak B_{i_k}]
\]
は $\mathfrak Q$ の既約類への一意分解である。実際、
\[
 \mathfrak B_\nu\sim(1\mid\cdots\mid1\mid p^{r_\nu}\mid\cdots\mid p^{r_\nu})
\]
が
\[
 \mathfrak C\sim(1\mid\cdots\mid1\mid p^{s_1}\mid\cdots\mid p^{s_\lambda})
 \quad\text{と}\quad
 \mathfrak D\sim(1\mid\cdots\mid1\mid p^{t_1}\mid\cdots\mid p^{t_\mu})
\]
の最小公倍数として表されるとする。このとき $\mathfrak C$ と $\mathfrak D$ の初等因子系では、最初の $(\nu-1)$ 箇所に数 $1$ がなければならず、$\nu$ 番目の箇所では指数 $s_1$ または $t_1$、例えば $s_1$ が $r_\nu$ に等しくなければならない。しかし
\[
 r_\nu=s_1\leqq s_2\leqq\cdots\leqq s_\lambda\leqq r_\nu
\]
となるので、$\mathfrak C=\mathfrak B_\nu$ であり、したがって $\mathfrak B_\nu$ は\emph{既約である}。
'@
$reader = Replace-RegexInSpan $reader $p19Start $p19End 'したがって、初等因子 \$a_i\$ の素数冪の最小公倍数としての一意表示は.*?(?=\\footnote\{\$\\mathfrak B\$ は片側類にはなお可約である。)' $p19QB 'P19-08'

$p30Start = '\section*{30.'
$p30End = '\section*{31.'
$p30Sec3 = @'
3. $\mT$ の元 $\alpha$ は、$\alpha$ から導かれるオーダー $\mR_\alpha$ が有限であるとき、$\mR$ に関して整、略して整と呼ばれる。同値に、加群鎖
\[
        \mA_\mu=(\alpha^0,\alpha,\ldots,\alpha^{\mu-1})
\]
が有限段階の後に停止し、
\[
        \mA_n=\mA_{n+1}=\cdots=\mA_{n+\nu}=\cdots
\]
となるときである。

この定義には、4. で用いる第二の定式化もある。$\mT$ の元 $\alpha$ は、零加群と異なる主加群 $\mC$、すなわちある $\gamma\ne0$ から導かれる $\mC$ が少なくとも一つ存在し、オーダー $\mR_\alpha$ と $\mC$ の積 $\mC\mR_\alpha$ が有限加群になるとき、整と呼ばれる。言い換えれば、加群鎖 $\mC\mA_\mu$ が有限段階の後に停止することである。\footnote{$\mR$ に零因子を許す場合には、正則な主加群の存在を要求しなければならない。すなわち $\gamma$ は零因子でない正則元であると仮定しなければならず、零因子のない環ではこれは単に $\gamma\ne0$ である。}

最後に、この定義は通常の定式化とも同一である。$\mT$ の元 $\alpha$ は、$\mR$ の元 $r_i$ を用いて少なくとも一つの方程式
\[
        \alpha^n+r_1\alpha^{n-1}+\cdots+r_n=0
\]
を満たすとき整と呼ばれる。

これらの定義は実際に同一である。$\mR_\alpha$ は $\alpha$ のすべての冪から導かれる加群と一致するから、$\mR_\alpha$ が有限であるとき、その冪の中から常に加群基底を選ぶことができる。そのような基底が、例えば $e=\alpha^0,\alpha,\ldots,\alpha^{n-1}$ で与えられるなら、これは $\mA_\mu$ の鎖が $\mA_n$ で停止することを意味する。逆に $\mA_n=\mA_{n+\nu}$ はこの基底を与える。さらに $\mA_\mu$ の鎖の停止は、上の方程式の存在とも同一である。$\mR_\alpha$ が有限であれば $\mC\mR_\alpha$ も有限であり、従って鎖 $\mC\mA_\mu$ は停止する。逆に $\mC\mR_\alpha$ の有限性、したがって $\mC\mA_\mu$ の停止から、$\mA_\mu$ も停止し、従って $\mR_\alpha$ が有限であることが従う。実際、$\mC$ は零加群と異なる主加群であると仮定されているので、
\[
        \mC\mA_n=\mC\mA_{n+\nu}
\]
は $\mA_n=\mA_{n+\nu}$ も与える。

整量の環性と整依存の推移律は、次の補題に基づく。

\medskip
\noindent\textbf{補題。} $\mS$ を $\mT$ の有限オーダーとし、$\alpha$ を $\mS$ の任意の元とする。このとき $\alpha$ から導かれるオーダー $\mR_\alpha$ は有限である。言い換えれば、有限オーダーのすべての元は整である。

証明は通常の議論による。$\sigma_1,\ldots,\sigma_n$ を $\mS$ の加群基底とする。$\mS$ は環であるから、$\alpha\sigma_i$ は $\mS$ に属する。従って
\[
        \alpha\sigma_i=r_{i1}\sigma_1+\cdots+r_{in}\sigma_n,
\]
したがって
\[
        \left|r_{ik}-\alpha e_{ik}\right|=0
\]
である。ただし $i\ne k$ なら $e_{ik}=0$、$e_{ii}=e$ である。これにより $\alpha$ が整であることが示される。行列式の消滅には、$\mT$、従って $\mS$ が零因子をもたないという仮定を用いる。\footnote{$\mR$ に約イデアル鎖条件を仮定しつつ零因子を許す場合、この補題は §2 の加群定理から直ちに従う。その定理によれば鎖条件は $\mS$ からなる加群へ移る。この証明も、数体については Dedekind（第4版, §173, II）に由来し、文献における鎖条件の最初の応用である。4. の下で与える帰結では、Dedekind は代数的数体におけるイデアルを法とする剰余類の数が有限であるという、より特殊な事実を用いている。}

$\mT$ におけるすべての整量からなる系 $\mS$ はオーダーをなす。$\mR$ の元は、単位元を基底とする有限 $\mR$-加群として $\mR$ が有限であるため整であり、したがって $\mS$ は $\mR$ を含む。また $\mS$ は環性ももつ。任意の二つの整量 $\alpha,\beta$ から導かれるオーダー
\[
        \mR_{\alpha,\beta}=\mR_\alpha\cdot\mR_\beta
\]
は有限である。ゆえに補題により、$\alpha+\beta$ と $\alpha\beta$ は有限オーダーの元として整である。

\medskip
\noindent\textbf{整依存の推移律。} $\mS$ が整量からなるオーダーであるなら、$\mS$ に関して整な $\mT$ のすべての元は $\mR$ に関しても整である。定義により $\alpha$ は方程式
\[
        \alpha^m+\sigma_1\alpha^{m-1}+\cdots+\sigma_m=0
\]
を満たし、従って $\sigma_1,\ldots,\sigma_m$ から導かれるオーダー
\[
        \overline{\mS}=\mR_{\sigma_1,\ldots,\sigma_m}
        =\mR_{\sigma_1}\cdot\mR_{\sigma_2}\cdots\mR_{\sigma_m}
\]
に関しても整である。このオーダーは有限である。2. で与えた推移律により、$\alpha$ から導かれる有限 $\overline{\mS}$-オーダー $\overline{\mS}_\alpha$ は従って有限 $\mR$-オーダーでもあり、$\alpha$ は有限オーダーの元として補題により整である。

'@
$reader = Replace-RegexInSpan $reader $p30Start $p30End '3\. \$T\$ の元 \$\\alpha\$ は.*?(?=4\. 環 \$R\$ は)' $p30Sec3 'P30-01'

$p30Dedekind = @'
\noindent\textbf{Dedekind の帰結 I。} $\mR$ が $\mT$ において整閉であり、さらに $\mR$ でイデアルの約イデアル鎖条件（公理 I）が成り立つとする。$\beta$ が $\mT$ の非整元で、$c\ne0$ が $\mR$ の元なら、指数 $\sigma\ge0$ が存在し、元の列
\[
 c,\;c\beta,\ldots,c\beta^r,\ldots
\]
において $c,\ldots,c\beta^\sigma$ は整であり、残りはすべて非整である。

もしすべての元 $c\beta^r$ が整であれば、$\mR$ の整閉性によりそれらは $\mR$ に属する。$\mC$ を $c$ から導かれる加群、$\mB_r$ を $\beta^0,\ldots,\beta^{r-1}$ から導かれる加群とすると、加群鎖
\[
        \mC\mB_1,\mC\mB_2,\ldots,\mC\mB_r,\ldots
\]
はイデアル鎖 $\mc_1,\ldots,\mc_r,\ldots$ となる。ただし
\[
        \mc_r=(c,c\beta,\ldots,c\beta^{r-1}).
\]
これは仮定により停止するが、そのとき仮定に反して $\mR_\beta$ は有限となり、$\beta$ は整となる。従って、元 $c\beta^r$ のいくつかは非整である。さらに、一つの非整元があれば、それ以後のすべての元は非整である。実際、$c\beta^\tau$ が整、従って $\mR$ に属するなら、$\rho<\tau$ に対して元 $c\beta^\rho$ は
\[
(c\beta^\rho)^\tau-c^{\,\tau-\rho}(c\beta^\tau)^\rho=0
\]
を満たし、従って整である。ゆえに最初の非整元が $c\beta^{\sigma+1}$ であるような $\sigma\ge0$ が存在し、これが求める指数である。

'@
$reader = Replace-RegexInSpan $reader $p30Start $p30End '\\noindent\\textbf\{Dedekind の帰結 I。\}.*?(?=拡大環 \$T\$ を)' $p30Dedekind 'P30-02'
$p30CorTwoOld = @'
$\beta=b/c$ と置き、$c\ne0$ とする。このとき列 $c,c\beta=b,c\beta^2,\ldots$ の最初の二つの元は確かに整であるから、帰結 I の指数を $\rho$ とすれば $\rho>1$ である。そこで
\[
        m=c\beta^\rho,\qquad n=c\beta^{\rho-1}
\]
と置けば、$m/n=\beta$ であり、$m^2/n=c\beta^{\rho+1}$ は非整である。
'@
$p30CorTwoNew = @'
$\beta=b/c$ と置き、$c\ne0$ とする。このとき列 $c,c\beta=b,c\beta^2,\ldots$ の最初の二つの元は確かに整であるから、帰結 I の指数を $\sigma$ とすれば $\sigma\ge1$ である。そこで
\[
        m=c\beta^\sigma,\qquad n=c\beta^{\sigma-1}
\]
と置けば、$m/n=\beta$ であり、$m^2/n=c\beta^{\sigma+1}$ は非整である。
'@
$reader = Replace-ExactInSpan $reader $p30Start $p30End $p30CorTwoOld.Trim("`r", "`n") $p30CorTwoNew.Trim("`r", "`n") 'P30-03'

$reader = Replace-ExactInSpan $reader $p30Start $p30End 'a_1\xi_1+\cdots+a_k\xi_k+n_1\xi_1+\cdots+n_k\xi_k' 'a_1\xi_1+\cdots+a_k\xi_k+n_1\xi_{k+1}+\cdots+n_k\xi_{2k}' 'P30-04'
$p30Chain = @'
いま約鎖または倍鎖
\[
        \mA_1,\mA_2,\ldots,\mA_r,\ldots
\]
が与えられ、対応する鎖条件が $\mR$ で成り立つと仮定する。$\mA_r$ に割り当てられたイデアルを $\mathfrak a_{r1},\ldots,\mathfrak a_{rk}$ とすれば、各 $\lambda=1,\ldots,k$ について列
\[
        \mathfrak a_{1\lambda},\mathfrak a_{2\lambda},\ldots,
        \mathfrak a_{r\lambda},\ldots
\]
は約イデアル鎖または倍イデアル鎖である。したがって仮定により、すべての $\lambda$ について $\mathfrak a_{\mu\lambda}$ が以後のすべてのイデアルと等しくなる添字 $\mu$ が存在する。すると、いま証明したことにより、加群 $\mA_\mu$ は以後のすべての加群と等しい。こうして鎖条件は移される。
'@
$reader = Replace-RegexInSpan $reader $p30Start $p30End 'いま約鎖または倍鎖\n.*?こうして鎖条件は移される。' $p30Chain 'P30-05'
$p30IsoA = '$M$ と $\overline M$ の元の対応が可逆的一対一であるなら'
$p30IsoB = '4. ここで、5 の直和に関する定理が従う'
$reader = Replace-ExactInSpan $reader $p30IsoA $p30IsoB '\cong' '\simeq' 'P30-06' 6
$reader = Replace-ExactInSpan $reader $p30Start $p30End 'すべての $x$ について' 'すべての $\varkappa$ について' 'P30-07a' 5
$reader = Replace-ExactInSpan $reader $p30Start $p30End 'b^x' 'b^\varkappa' 'P30-07b' 7
$reader = Replace-ExactInSpan $reader $p30Start $p30End 'a^x' 'a^\varkappa' 'P30-07c' 2
$reader = Replace-ExactInSpan $reader $p30Start $p30End '(a-b)^{x+\lambda}' '(a-b)^{\varkappa+\lambda}' 'P30-07d'
$reader = Replace-ExactInSpan $reader $p30Start $p30End 'a^\varkappa b^\lambda=(ab)^x' 'a^\varkappa b^\varkappa=(ab)^\varkappa' 'P30-07e'

$p30LemmaTwo = @'
示すべきことは、
\[
 \mpideal^2\equiv0\pmod{\mq},
 \qquad \mq\equiv0\pmod{\mpideal},
 \qquad \mq\not\equiv0\pmod{\mpideal^2}
\]
から必ず $\mq=\mpideal$ が従うことを示す。そこで
\[
 c\equiv0\pmod{\mq},
 \qquad c\equiv0\pmod{\mpideal},
 \qquad c\not\equiv0\pmod{\mpideal^2}
\]
とする。
'@
$reader = Replace-RegexInSpan $reader $p30Start $p30End '示すべきことは、\n\\\[\n\s*\\mpideal\^2\\equiv0\\pmod\{\\mq\}.*?\n\\\]\n(?=補助結果 §7, 3)' $p30LemmaTwo 'P30-08'

$p30Fraction = @'
残るのは、方程式
\[
        \mathfrak A\mX=\mo
\]
が有限 $\mR$-加群の系において常に解をもつことを示すだけである。

予備的注意。方程式 $\mathfrak A\mT=\mathfrak B$ がただ一つの解をもつなら、$\mT$ は加群商 $\mathfrak B:\mathfrak A$（§5, 4）である。なぜなら
\[
\mT\equiv0\pmod{\mathfrak B:\mathfrak A},\quad
\mathfrak B=\mathfrak A\mT\equiv0\pmod{\mathfrak A\cdot(\mathfrak B:\mathfrak A)}\equiv0\pmod{\mathfrak B}
\quad\text{または}\quad
\mathfrak A\cdot(\mathfrak B:\mathfrak A)=\mathfrak B.
\]

まず $\mathfrak A$ が主加群で、$\mathfrak A=(\alpha)$ であるなら、$\mX=(e/\alpha)$ は $\mathfrak A\mX=\mo$ の解であり、$\mX$ もまた有限 $\mR$-加群である。従って任意の有限 $\mR$-加群は、$\mR$ の二つのイデアルの加群商であり、このことが分数イデアルという名称を正当化する。実際、$\tau_1,\ldots,\tau_r$ が $\mT$ の加群基底であるなら、$\tau_i=t_i/a$ と置き、$\mt$ を $\mR$ において $t_i$ によって生成されるイデアルとする。このとき
\[
        \mo a\cdot\mT=\mt,
        \qquad \mT=(\mt:\mo a)
\]
である。ここで商は $\mK$ の中で取られる。

方程式 $\mathfrak A\mX=\mo$ の解は一般に次のように与えられる。
\[
        \mathfrak A c=\ma,
        \qquad \mathfrak A\mb c=\mo a,
        \qquad \mathfrak A\cdot(\mb c:\mo a)=\mo.
\]
ここで $\mX=(\mb c:\mo a)$ は、イデアルを主イデアルで割った商として、再び有限 $\mR$-加群である。群性が証明された。また任意の二つのイデアルの加群商 $\ma:\mb$ も、方程式 $\mb\mX=\ma$ の解として有限 $\mR$-加群であることが従う。

'@
$reader = Replace-RegexInSpan $reader $p30Start $p30End '残るのは、方程式\n.*?(?=6\. 群性から)' $p30Fraction 'P30-09'

$p34Start = '\section*{34.'
$p34End = '\section*{35.'
$p34Rep = @'
具体的に、$\ml_1$ について行列単位からなる基底
\[
        \ml_1=(c_{11},\ldots,c_{n1})
\]
を基礎に置き、自己同型斜体 $\Lambda$ の実現として、以前（§14）$K$ と記した $\mo$ の部分斜体を取る（その際、先の考察では右イデアルを左イデアルで置き換え、それに応じて自己同型を右に書かなければならない）。
\[
        a=\sum c_{ik}\alpha_{ik}
\]
と表せば、
\[
        a\longmapsto(\alpha_{ik})
\]
が $\ml_1$ によって媒介される $K$ における表現である。実際、
\[
\begin{aligned}
        a\cdot c_{k1}
        &=\left(\sum\sum c_{ij}\alpha_{ij}\right)\cdot c_{k1}\\
        &=\sum c_{ik}\alpha_{ik}c_{k1}\\
        &=\sum c_{i1}\alpha_{ik},
\end{aligned}
\]
すなわち
\[
        a(c_{11},\ldots,c_{n1})
        =(c_{11},\ldots,c_{n1})(\alpha_{ik})
\]
である。

\[
\left\{
\begin{aligned}
&\text{$\Gamma$ を $K$ の部分斜体で、$K$ が $\Gamma$ 上有限階数 $t$ をもつものとする：}\\
&\qquad K=z_1\Gamma+\cdots+z_t\Gamma.\\
&\text{このとき $K$ は $\Gamma$ に関する自分自身の表現加群となる。$K$ の元 $\beta$ は、}\\
&\text{次のように得られる $\Gamma$ 上の行列 $B$ によって表される：}\\
&\qquad \beta z_j=\sum z_i\beta_{ij};\quad B=(\beta_{ij}).
\end{aligned}
\right.
\]
いま $\ml_1$ を部分斜体 $\Gamma$ に関する表現加群とみなすと、次を得る。

\emph{$\ml_1$ によって媒介される $\mo$ の $\Gamma$ における表現は、上に与えた $\mo$ の $K$ における表現
\[
        a\longmapsto(\alpha_{ik})
\]
において、各元 $\alpha_{ik}$ を、$K$ の $\Gamma$ における表現でそれに対応する行列 $A_{ik}$ に置き換えることによって得られる。}

証明。
\[
        \ml_1=\sum c_{i1}K=\sum\sum c_{i1}z_j\Gamma.
\]
基底 $(\ldots,c_{i1}z_j,\ldots)$ によって、
\[
c_{ik}\longmapsto
\begin{array}{c@{\quad}c}
 & \begin{array}{ccc} \boxed{\scriptstyle 1} & \boxed{\scriptstyle k} & \boxed{\scriptstyle n} \end{array}\\[-.2em]
\begin{array}{c}\boxed{\scriptstyle 1}\\ \boxed{\scriptstyle i}\\ \boxed{\scriptstyle n}\end{array}
&
\begin{pmatrix}
0&\cdots&0&\cdots&0\\
\vdots&&\vdots&&\vdots\\
0&\cdots&E_t&\cdots&0\\
\vdots&&\vdots&&\vdots\\
0&\cdots&0&\cdots&0
\end{pmatrix}
\end{array},
\]
となる。ここで $E_t$ は単位行列、$0$ は $t$ 次零行列であり、
\[
        \alpha\longmapsto
        \begin{pmatrix}
        A& &0\\
         &\ddots&\\
        0& &A
        \end{pmatrix},
\]
したがって
\[
        a=\sum c_{ik}\alpha_{ik}\longmapsto
        \begin{pmatrix}
        A_{11}&\cdots&A_{1n}\\
        \vdots&&\vdots\\
        A_{n1}&\cdots&A_{nn}
        \end{pmatrix}.
\]
任意の $\mM$ への移行は、表現について再び環同型を意味する。$\mo$ が両側単純な環の直和であるなら、これらの環は順次同型的に表現され、残りは零によって表現される。

\textbf{注意。} ここで研究した、左イデアルの自己同型斜体およびその有限次数部分斜体における表現は、同型を除けば、単純 $\mo$-加群（または左イデアル）によって媒介され得る表現のすべてである。実際、先の注意（§2）によれば、$\mo$-加群 $\mM$ を任意の斜体 $K$ に関する双加群とみなすとき、$K$ の元は加群準同型を生成する。したがって斜体 $K$ は、この $\mo$-加群の自己同型斜体の部分斜体と準同型に対応していなければならない。単位元が恒等作用素であるから、この準同型は同型である。また自己同型斜体全体は、その部分斜体上有限次数でなければならない。さもなければ表現加群も無限階数となり、これは不可能だからである。

最後に、ここで調べた既約表現はまだすべてではなく、単純 $\mo$-加群によって媒介されるものだけであることを注意しておく。一般にはほかにも表現加群がある（例えば、斜体 $\Omega$ を、部分斜体 $\Sigma$ を左側領域、自身を右側領域とする双加群とみなしたもの）。それらは $\mo$-加群としては可約であるが、双加群としては既約であり、そのためやはり既約表現を与える。
'@
$reader = Replace-RegexInSpan $reader $p34Start $p34End '具体的には、\$\\ml_1\$ の行列単位の基底を.*?\$\\mo\$ が両側単純な成分の直和であるなら、これらの成分は順に同型的に表現され、残りの成分は零として作用する。' $p34Rep 'P34-01'

$p34Nineteen = @'
\subsection*{§ 19. 加群および表現加群における単純組成因子}

$\mo$ を左イデアルについて極大条件と極小条件を満たす環、$\mc$ をその極大冪零イデアルとする。このとき次が成り立つ。

\emph{任意の単純 $\mo$-加群 $\mM$ は、$\mo$ によって零化されるか、または根基をもたない環 $\mo/\mc$ の単純左イデアル $\ml$ と同型である。後者の場合、この加群は $\mo/\mc$ の両側イデアルのうち $\ml$ を含まないものすべてによって零化され、絶対乗数環（§1）は $\ml$ を含む両側単純環と同型である。}

\textbf{証明。} $\mc^e=0$ とする。$\mc\mM=0$ でなければならない。さもなければ $\mc\mM=\mM$ であり、したがって
\[
        \mM=\mc\mM=\mc^2\mM=\cdots=0
\]
となるからである。ゆえに $\mM$ は $\mo/\mc$-加群ともみなせる（$\mc$ を法とする一つの剰余類のすべての元は、$\mM$ の元に掛けたとき同じ結果を与える）。根基をもたない環として $\mo/\mc$ は単位元をもち、したがって $\mM$ は、$\mo/\mc$ によって零化される加群と、単位元が恒等作用素となる加群との直和である（§17）。$\mM$ は単純なので、この二つの和因子の一方だけが現れ得る。単位元が恒等作用素である場合、§18 と同じく単純左イデアルとの同型が従う。実際、$m\ne0$ を $\mM$ の元とすれば $(\mo/\mc)m\ne0$ であり、したがって $\mo/\mc$ の少なくとも一つの単純左イデアル $\ml$ について $\ml m\ne0$ となり、ゆえに $\ml m$ は $\mM$ を尽くさなければならない。そのほかの主張はこのような左イデアルについて明らかであり、それと同型なすべての加群へただちに移る。

\textbf{帰結。} \emph{$\mM$ が組成列をもつ $\mo$-加群なら、その単純組成因子は $\mo$ によって零化されるか、または $\mo/\mc$ の単純左イデアルと同型である。}

$P$ が $\mo$ と可換的に結びついた環である場合も、すべての結果は保たれる。その場合には、加群の代わりに、右側の $P$ と左側の $\mo$ に関する双加群であって、条件
\[
        am\cdot\rho=a\cdot m\rho=a\rho\cdot m\qquad(\S~15)
\]
を満たすものを考えればよい。さらに $P$ の単位元も恒等作用素であるとする。部分加群としては、常に $P$ による乗法を許すものだけを考える（イデアルの場合と同様である）。われわれの証明で構成された部分加群 $\mc\mM,\mc^2\mM,\ldots$ はこの条件を満たす。

とくに $P$ が体で、$\mM$ が有限階数の $P$-加群なら、$\mM$ は同時に表現加群である。$\mM$ によって媒介される表現は環準同型であるだけでなく、$P$ に関して作用素準同型でもある（§15）。この性質をもつ $P$ におけるすべての表現は、このような加群によって与えられる。既約表現は単純加群に属し、逆も成り立つ。したがってこの節の定理は、ただちに $\mo$ の $P$ における表現についての定理として解釈できる。\emph{すべての既約表現（零表現を除く）は $\mo/\mc$ の単純左イデアルによって媒介される。したがって、任意の表現を §16 に従って組成列により簡約すると、その主対角線上には（零を除き）$\mo/\mc$ の単純左イデアルによって媒介される表現と同値な表現だけが現れる。}

\textbf{注意。} $\mo$ と $P$ について以上の仮定の下では、$\mo$ に有限性条件を仮定する必要はない。すべての表現は同時に絶対乗数環の同型表現であり、この絶対乗数環は有限次数行列環の同型逆像として、それ自身が有限階数の $P$-加群となる。また定義により許されるイデアルとして $P$-加群だけを考えるので、この絶対乗数環について極大条件と極小条件が満たされる。

$P$ を可換体と仮定すれば、この絶対乗数環は $P$ に関する超複素系となる。主対角線上に零だけでないものが現れるなら、この仮定は常に満たされる。実際、そのとき §18 の注意により、$P$ は $\ml$ の自己同型斜体の部分斜体と同型であり、$\mo/\mc$ の部分斜体 $K$ による実現（§14）では、可換的結合のために $K$ の中心に含まれなければならない。

'@
$reader = Replace-RegexInSpan $reader $p34Start $p34End '\\subsection\*\{§ 19\. 加群および表現加群における単純組成因子\}\n.*?(?=\\subsection\*\{第IV章)' $p34Nineteen 'P34-02'
$reader = Replace-ExactInSpan $reader $p34Start $p34End "\mr_1\cong \mo/(\mr_2+\cdots+\mr_n)=\mr_1'+\mr_1''" "\mr_1\simeq \mo/(\mr_2+\cdots+\mr_n)=\mr_1'+\mr_2'" 'P34-03'
$p34IdealNew = @'
\mr\mo=\mr(\ma_i+\mb_i)=(\mr\ma_i,\mr\mb_i)
 \subseteq(\mr,\ma_i\mb_i)=(\mr,0)=\mr.
'@
$reader = Replace-ExactInSpan $reader $p34Start $p34End '\mr\mo=\mr(\ma_i+\mb_i)=(\mr\ma_i,\mr\mb_i)=(\mr,0)=\mr.' $p34IdealNew.Trim("`r", "`n") 'P34-04'
$reader = Replace-ExactInSpan $reader $p34Start $p34End 'n\,\operatorname{Sp}_{\rm red}' 'n\cdot\operatorname{Sp}_{\rm red}' 'P34-05a'
$reader = Replace-ExactInSpan $reader $p34Start $p34End 'n\sum_i' 'n\cdot\sum_i' 'P34-05b'
$reader = Replace-ExactInSpan $reader $p34Start $p34End 'n e' 'n\cdot e' 'P34-05c'

$reader = Replace-RegexInSpan $reader $p38a $p38b 'Satz (?=[I0-9])' '定理 ' 'P38-14' 22
$reader = Replace-ExactInSpan $reader $p38a $p38b '代数的数体上の正規単純代数の指数（exponent）はその指数（index）に等しい。' '代数的数体上の正規単純代数のブラウア類の位数（exponent）は、その指数（index）に等しい。' 'P38-15a'
$reader = Replace-ExactInSpan $reader $p38a $p38b 'すなわち指数 \(=\) 指数（index）' 'すなわちブラウア類の位数（exponent）\(=\)指数（index）' 'P38-15b'
$reader = Replace-ExactInSpan $reader $p38a $p38b '\(A\) の \(\mathfrak p\)-指数は \(A_{\mathfrak p}\) の指数であり，定理 1 によりその exponent である。' '\(A\) の \(\mathfrak p\)-指数は \(A_{\mathfrak p}\) の指数（index）であり、定理 1 によりその冪指数（exponent）でもある。' 'P38-15c'
$reader = Replace-Exact $reader ' ガロア' 'ガロア' 'JA-space-galois' 26

$p02QaA = '{\Large\bfseries 2.'
$p02QaB = '{\Large\bfseries 3.'
$p02Notes = @(
    '（A1 と同様の直接計算）',
    '（1) と A6 から）',
    '（3), 4), A8 から）',
    '（式 17）',
    '［6 の導出と同様］',
    '（6 から）',
    '（8 から）',
    '（7 と 8 から）',
    '（式 18）',
    '（式 20）',
    '（§13 C）'
)
$p02NoteNo = 0
foreach ($p02Note in $p02Notes) {
    $p02NoteNo++
    $reader = Replace-ExactInSpan $reader $p02QaA $p02QaB ("\qquad\text{" + $p02Note + "}") ("\\`n&\quad\text{" + $p02Note + "}") ("P02-layout-{0:D2}" -f $p02NoteNo)
}

if ($reader.Contains('\mpideal_1^{\varrho_1}`n &= (\mpideal_1^{\varrho_1}')) { throw 'P30 stale Axiom IV display survived' }
[System.IO.File]::WriteAllText((Join-Path $out 'reader.tex'), $reader, $utf8)

Write-Output ("reader_bytes={0}" -f ([System.IO.FileInfo](Join-Path $out 'reader.tex')).Length)
Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $out 'reader.tex'), (Join-Path $out 'p31.tex') | ForEach-Object { "{0} {1}" -f $_.Hash,$_.Path }
