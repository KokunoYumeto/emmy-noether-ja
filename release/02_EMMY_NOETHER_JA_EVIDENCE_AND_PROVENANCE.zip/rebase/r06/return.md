# JA-NOETH-R06-ED10-20260808 — static producer return

Successor root: reader.tex / ED18512FA4E52612E6C8E467E9051FC9F35AD1C1BFCF3C043D303F78A07FD9FA.

Inherited base: r05/reader.tex / 9B3C37E0C91E7BF924B5F6738BF97CDD4AA62DC806DD5BCE0D8904931E3E6F87; inherited editable set E4BB1BE344A7A6FA2D4515959A01F5D462ACB330E82390B6ABABA57E9B7D51BA; inherited freeze CCE6286F517CC59C8189D87AEB801E29D66C8B39466B049EF060B9A57098A1A0.

Authority: pointer v046 / A6BBCB8FF09FB3E2FCA8DD717E44BB6AECF93680D5819C2F00954E41EBE0AF7D; ED0010 / 1AF3252486AC99399F95E21E4447D79C1D1206A050D26A91FE068499EE0D4563.

Resolved batch:

- JA-R05-COV-001: the complete ED0010:19867 theorem is restored as a separate paragraph on reader.tex:18868, preserving \(a_{S,T}\), uniqueness, irreducibility, degree \(m\), Schur index, and associated-division-algebra degree. Note 10 remains exactly once at reader.tex:20115 through notes.csv row 33.
- JA-R05-BIB-001: only t7.tex:80 and t7.tex:94 changed from 不同イデアル to 共役差積; surrounding bibliography fields are byte-identical.
- terms.csv:T018 explicitly records the P36/P43 scope of Differente=共役差積.
- ED0010 rebase: reader.tex:13504 and :13532 already realize the accepted P30 readings; reader.tex:13634 changes the coefficient glyph to ordinary \(b_\ell\); t6.tex:77--78 mirror the accepted recursive \(xK_2,xK_3\) right sides; t7.tex:157 mirrors the accepted Dedekind bibliography correction.
- notes.csv retains all 73 note mappings and relabels only their authority prefix from ED0008 to ED0010.

Every changed locus and the exact inherited identity are frozen in chg.csv. Four unresolved authority-owner observations remain explicit in adv.csv; the resolved Kapferer and bibliography rows moved to the change ledger.

Editable-set SHA-256: 83E007650DF313CE0BE9E62EC06541C2ED47B1C49704B61FA000AEA3FC88451B. Mechanical PDF: 419 pages / 1985EBEAE818D6DE2C20069B03BC0FD5272A2C263D901BF9B15A41C4D304F08F. Build and byte checks are mechanical only. Clean-day count is 0 after the 2026-08-08 authority/target reset. SGA remains held; nothing is publishable.
