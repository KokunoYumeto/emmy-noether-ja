# JA-NOETH-CUM-20260805-003 — independent checker handoff

This producer successor invalidates `handoff2.md` because both the German authority and editable target changed. It is not approval or certification. The multi-day producer gate is 0/3 after the 2026-08-05 reset; SGA remains held.

## Frozen authority

Reopen the then-newest pointer/body at intake. This package binds `NOETH-DE-AUTH-v033-20260805`: pointer 58,695 bytes / `816BE0E4F5821C5AFDFF744AFF98898C12D4EB3782A42900DA0C3BBE4C418BE0`; exact ED0005 body 2,153,575 bytes, 24,146 physical LF lines / `1A44F967B29972E8F99E5C323A479162AD82A23FC457395915A4BB9DDF51AD41`. The v032→v033 pointer diff is metadata/preservation state only and does not change the German body.

ED0004→ED0005 is exactly one replaced physical line (`source5.csv`): P06 source line 5383 changes `x_1^2u_1^2` to `x_1^4u_1^2` and `2x_1^2x_2u_1u_2` to `2x_1^3x_2u_1u_2`. The target rebase restores the inherited baseline reading at `reader.tex` line 5203; exact ancestry and hashes are in `chg3.csv`.

## Editable target and mechanical output

Root directory: `C:/Users/Floris/Documents/interlanguage/03_projects/language_management/cjk/03_working_translations/japanese/rebase`

- `reader.tex`: 1,926,162 bytes / `6D8A36F22F44052C7209DA9414EFFF31C78F7B6E29A11733D403776BBA5D4130`.
- `t0.tex`--`t7.tex`: unchanged identities enumerated in `freeze3.csv`.
- Domain-separated editable-set SHA-256: `AC0ABE6B7DB5989ED156AA7902096511A350DC0C47ACB4A37B06A225382D9FB7`.
- `reader.pdf`: 2,933,906 bytes, 420 pages by the final log / `19E7C42FF11ECF32B6753812E3F279262A4AACC321BF78B40F6CB92F99861B53`.
- `build/reader.log`: 30,239 bytes / `130A52B8B7289961EE7A1C2A37EE6581F871FDE0A94AF61B439292D3CE74C7CC`.

Two serial XeLaTeX passes exited zero. The final log has zero fatal/error/undefined/missing-character/overfull/underfull matches; font substitution warnings remain. A raw root-plus-component scan has zero disallowed controls, tabs, or UTF-8 replacement characters. The producer did not inspect rendered pages.

## Exact producer delta from the proven candidate

`delta.csv` contains five root hunks:

1. P06 source lines 5101 and 5105 / target lines 4900 and 4907: the two inherited `H(\xi)`→`H^*(\xi)` corrections.
2. P06 source line 5383 / target line 5203: the ED0005 exponent rebase recorded in `chg3.csv`.
3. P31 source line 16017 / target line 14972: the predecessor repair of inherited `0x0C + ootnote` to `\footnote`, recorded in `fix.csv`.
4. Root lines 20077--20086 bind the eight translated post-P43 components covering source lines 20988--24145.

All 43 numbered-paper source and target spans are enumerated in `manifest.csv`; cumulative semantic boundaries are in `cursor3.csv`; raw post-P43 source blocks are in `tail.csv`. Numbered Paper 43 ends at source line 20984, the Deuring wrapper is 20988--21004, the title begins at 21005, and the source closes at line 24146. `adv3.csv` carries five observations only, with no German defect claim.

## Independent checker requirements

- Verify exact custody against `freeze3.csv` and the then-current German pointer/body.
- Collate every bound span: front matter, Papers 1--43, wrapper, Deuring lecture §§1--31, Kapferer paper and Noether supplement, bibliography/terminal lists, document close, all component boundaries, and inherited RA10 apparatus.
- Independently assess semantic completeness, formulas/indices/environments, notes/apparatus/bibliography, `adv3.csv`, `JA-FIX-001`, and `JA-REB-003`.
- Independently review Japanese language, terminology, and historical register.
- Compile independently, validate PDF text/metadata, freshly render, and visually inspect every page.
- Return stable finding IDs and exact loci or a sealed disposition. Producer compilation and records are not approval.

Any German authority/body or editable-target change invalidates this freeze and resets the producer gate to zero. The producer must separately record three clean audits on three later Europe/Berlin calendar days inside the same session.
