# Japanese Noether cumulative rebase provenance

Status at 2026-08-04: producer translation package frozen and mechanically compiled; independent checking and the producer's three-distinct-day gate remain open. Clean-day count: **0/3**. SGA is held and was not touched.

## Current German authority

- Current pointer: `NOETH-DE-AUTH-v019-20260804`, `CURRENT_GERMAN_AUTHORITY_POINTER.json`, 39,367 bytes, SHA-256 `FDBE531AA5F2175AD23363FB4F05B357A5ECD8A72B022D7ED644E39DF0B3CA79`.
- Versioned pointer: `pointers/v019.json`, byte-identical to the current pointer and read completely.
- Resolved body: `candidates/ED0004/noether.tex`, 2,153,575 bytes, 24,146 lines, SHA-256 `0CB422ECD397DD392A8625297A508DAEE3A5A934EA19EEEF49B47B319EA4F2BB`.
- Pointers v015 through v019 are metadata-only successors. Their pointer hashes differ, but every one resolves to the exact ED0004 body above. Therefore every German byte and every bound source span remained invariant across those pointer transitions.

## Inherited Japanese lineage

- Baseline: `Noether_Japanese_Cumulative_SourceFidelity_v001.tex`, 1,794,641 bytes, SHA-256 `4A284DF3FAC4D53D305659B539AF2FEB17902BFB4C254A7DF62A155C6BC23131`.
- Candidate witness: `noether_ja/reader.tex`, 1,925,975 bytes, SHA-256 `47F8150D6750A02FF939C0E6CF4F07909858AB6DFEC8E511B047D4640BCFB235`.
- Published-copy witness: `03_projects/noether/08_zenodo/r6/20-ja.tex`, byte-identical to the candidate.
- Independent assembly replay: `replay/reader.tex`, byte-identical to the candidate; replay script SHA-256 `75F8239629FCD625385D945D3E828248ABAB18FA8E861FB49E766F4B6C4155AC`.
- Baseline-to-candidate intake: 1,286 diff hunks, 1,834 old lines and 2,944 new lines, sequence ratio `0.8781619747042023`. Exact hunks are retained in `diff.csv`; per-paper identities are in `papers.csv` and `manifest.csv`.
- These facts establish ancestry and changed loci only. They do not inherit or create source-fidelity, Japanese-language, formula, apparatus, render, approval, archive, or certification claims.

## Producer rebase delta

Relative to the proven candidate witness, the root TeX has only three logical hunks:

1. ED0004 source line 5101 / Japanese root line 4900: `H(\xi)\ne0` to `H^*(\xi)\ne0`.
2. ED0004 source line 5105 / Japanese root line 4907: the same correction.
3. Root lines 20078--20085 include eight newly translated post-P43 components. They bind ED0004 lines 20988--24145: Deuring's lecture §§1--31, the Kapferer paper and Noether supplement, bibliography, and terminal lists.

The final editable set is `reader.tex` plus `t0.tex` through `t7.tex`. Its domain-separated identity is SHA-256 `CD941B8AEAAA1DC78F7107BE2A484E7908C60D75D5B2E45B70555344586B74E5`, computed from UTF-8 lines `filename|file_sha256\n` in that order. Exact source and target cursors are in `manifest.csv`, `tail.csv`, and `cursor.csv`.

## Mechanical build only

Two serial XeLaTeX passes exited zero. The copied PDF has 420 pages by `mutool info`. The final log has zero matches for LaTeX error, undefined control sequence, emergency stop, fatal error, missing character, overfull, or underfull diagnostics. Font substitution warnings remain. No page was rendered or visually opened by the producer.

## Open gates

- Independent source, Japanese, formula, apparatus, PDF-text, rendered-page, and certification review is required; see `handoff.md`.
- The producer must personally reopen the newest pointer/body and compare all bound spans on three later, distinct calendar days. Any authority pointer/body or editable-target change resets the counter to zero. Events are append-only in `gate.csv`.
