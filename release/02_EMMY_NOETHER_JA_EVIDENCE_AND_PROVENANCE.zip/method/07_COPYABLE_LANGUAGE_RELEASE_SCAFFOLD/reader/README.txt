Replace this file with:
00_REPLACE_PROJECT_REPLACE_BCP47_COMPLETE_LINKED_READER.pdf

The reader must be the complete, immediately previewable object for the exact declared scope. Its opening pages identify language, edition, scope, source authority, concept DOI, exact release DOI, version, repository, and license.
