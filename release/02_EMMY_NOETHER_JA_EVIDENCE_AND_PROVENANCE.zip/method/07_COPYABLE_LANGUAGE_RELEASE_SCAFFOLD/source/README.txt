Place the editable language source and deterministic build inputs here.

Record the frozen original/source authority in ../evidence/SOURCE_AUTHORITY.json. Do not silently copy caches, generated temporaries, credentials, unrelated languages, or another maintainer's workspace into this repository.
