# REPLACE_WORK - Complete REPLACE_LANGUAGE Edition

[Open the complete linked reader](reader/00_REPLACE_PROJECT_REPLACE_BCP47_COMPLETE_LINKED_READER.pdf)

- Stable language concept DOI: `REPLACE_LANGUAGE_CONCEPT_DOI`
- Exact release DOI: `REPLACE_EXACT_VERSION_DOI`
- Declared object scope: `REPLACE_EXACT_WORK_VOLUME_OR_CORPUS`
- Language: `REPLACE_LANGUAGE_NAME` (`REPLACE_BCP47`)
- Original/source authority: `REPLACE_ORIGINAL_SOURCE_IDENTIFIER`
- Global multilingual directory: `REPLACE_GLOBAL_CONCEPT_DOI`
- Release: `REPLACE_VERSION`, commit `REPLACE_GIT_COMMIT`

This repository publishes one independently maintained language edition. The target language is on the default `main` branch. It does not claim a larger series, volume set, or author corpus than the declared scope above.

## Public artifacts

- `reader/00_...pdf`: complete linked reader.
- `source/`: editable source and deterministic build inputs.
- `evidence/SOURCE_AUTHORITY.json`: exact source identity and scope.
- `evidence/QA_STATE.json`: build, render, replay, and release closure.
- `evidence/UNRESOLVED_ITEMS.tsv`: honest unresolved-item ledger.
- `evidence/ARTIFACT_SHA256.tsv`: bytes and SHA-256 hashes.
- `evidence/DATACITE_RELATIONS.json`: intended DOI relation graph.

Source/canonical defects are reported with exact evidence to the central maintainer. This language repository does not modify sibling language editions.

Completion and publication are closed by direct source replay, model/agent checking, deterministic builds, rendered inspection, hashes, evidence, and disclosed unresolved items. Human review or waiting is never a release gate.
