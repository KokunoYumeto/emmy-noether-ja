# エミー・ネーター — 数学著作集・日本語版

論文1–43、M. Deuringが筆記した1929/30年の講義、KapfererとNoetherの論文および補遺、書誌と巻末一覧を収録します。

直接入手できる累積LaTeXには、各本文とプリアンブルが編集可能なコードとして収録されています。付属のPythonプログラムで元のファイル構成を展開し、XeLaTeXで組版した各PDFを読む順序で結合します。画像やPDFページを翻刻の代わりには用いません。ZIPには元の構成、同じ累積LaTeX、組版プログラムを収録しています。Python 3、pypdf、および各プリアンブルに指定されたTeXパッケージとフォントが必要です。TeXとフォントの版によってPDFのバイト列は変わる場合があります。固定された内部組版日は刊行日ではありません。

```text
python -m pip install pypdf
python build.py 02-noether-ja-base.tex --output 01-noether-ja-base.pdf
```

組版プログラムはAI作成：OpenAI Codex — GPT-6 Astra、Ultra、2026年10月24日。

AIによる日本語訳。修正と組版はOpenAI Codex — GPT-6 Astra、Ultraの推論設定によるものです。Emmy Noether、M. Deuringおよび各作品に記載された共著者の著者表示を保持します。発行者が人間として翻訳または独立した学術査読を行ったとは表示しません。

継承した翻訳の正確なモデルと推論設定は、現存する制作記録からは確定していません。 AIによる訂正・組版：2026年10月23–24日；Claude Opus 5.5（Anthropic）、2026年10月26日。刊行日：2026年10月26日。
