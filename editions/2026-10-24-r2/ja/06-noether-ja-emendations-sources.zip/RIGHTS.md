# 著者・来歴・権利

AIによる日本語訳。修正と組版はOpenAI Codex — GPT-6 Astra、Ultraの推論設定によるものです。Emmy Noether、M. Deuringおよび各作品に記載された共著者の著者表示を保持します。発行者が人間として翻訳または独立した学術査読を行ったとは表示しません。

継承した翻訳の正確なモデルと推論設定は、現存する制作記録からは確定していません。 AIによる訂正・組版：2026年10月23–24日；Claude Opus 5.5（Anthropic）、2026年10月26日（数式は Noether の印刷ページから読んだドイツ語本文と照合）。刊行日：2026年10月26日。

Emmy Noether の著作はパブリックドメインです。AIによる翻訳・訂正・組版について発行者が権利を有する範囲で、それらの権利は [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/deed.ja) によりパブリックドメインに提供されます。M. Deuring が記録した講義、H. Kapferer の論文、および明記された共著者の寄与は、それぞれの法的地位を保ちます。

[権利者からの申し立て](https://github.com/KokunoYumeto/emmy-noether-ja/issues/new).
