# エミー・ネーター数学論文集 — 日本語訳

論文1–43、M. Deuring筆録の1929/30年冬学期講義、KapfererとNoetherによる論文・補遺、文献目録を収録する。

[全文のLaTeX](02-noether-ja.tex)は本文を一つにまとめた編集用ファイルである。元の分割構造は`ja/reader.tex`および`ja/t0.tex`–`ja/t7.tex`に保持される。

## 組版

XeLaTeXを使用する。Noto Serif、Yu Gothic、およびFreeSerif（またはLatin Modern Roman）がインストールされている必要がある。TeX配布にはfontspec、xeCJK、AMS、mathtools、TikZ、adjustbox、diagboxなど、ソースに記載するパッケージが必要である。フォントは同梱していない。

アーカイブのルートで次のコマンドを2回実行する。参照の再処理が指示される場合は、指示が消えるまで繰り返す。

```sh
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error 02-noether-ja.tex
```

分割ソースを使う場合は`ja`ディレクトリ内で同じコマンドのファイル名を`reader.tex`にする。

日本語訳はAIによる翻訳。初版の制作主体：Manuscript Typesetting Project / OpenAI Codex（当時の正確なモデルは未確定）。本版のAIによる訂正・組版：OpenAI Codex — GPT-6 Astra、Ultra。

[著者・来歴・権利](RIGHTS.md) · [旧版の権利表示](NOTICE_HISTORIQUE.md)

組版スクリプトは`python build.py`で実行できる。提供するPDFと同じ組版時刻設定を用い、2回のXeLaTeX処理を行う。PDF内部の固定組版日は公開日を意味しない。公開用の直接ダウンロードLaTeXと、このアーカイブ内の`02-noether-ja.tex`は同一内容である。
